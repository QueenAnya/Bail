export declare class TTLCache {
    #private;
    constructor({ stdTTL, maxKeys, max, ttl }?: {
        stdTTL?: number;
        maxKeys?: number;
        max?: number;
        ttl?: number;
    });
    get(key: string | number): {} | undefined;
    set(key: string | number, value: any, ttl?: number): boolean;
    has(key: string | number): boolean;
    del(keys: string | number | Array<string | number>): number;
    take(key: string | number): {} | undefined;
    mget(keys: string | number | Array<string | number>): Record<string, any>;
    mset(list?: Array<{
        key: string | number;
        value?: any;
        val?: any;
        ttl?: number;
    }>): boolean;
    keys(): {}[];
    flushAll(): void;
    getStats(): {
        hits: number;
        misses: number;
        keys: number;
        ksize: number;
        vsize: number;
    };
    close(): void;
    on(): this;
    off(): this;
    removeAllListeners(): this;
    get size(): number;
}
export default TTLCache;
//# sourceMappingURL=ttl-cache.d.ts.map