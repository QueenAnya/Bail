import type { AuthenticationStateWithListing } from '../Types/index.js';
export interface NedbAuthState {
    state: AuthenticationStateWithListing;
    saveCreds: () => Promise<void>;
    /** deletes this session's documents (the whole store when no session is used) */
    clearAuth: () => Promise<void>;
    /** closes nothing (NeDB has no connection) — present so the return shape matches the other adapters */
    close: () => Promise<void>;
}
export interface NedbAuthStateOptions {
    /** an existing `@seald-io/nedb` Datastore (it is used as-is) */
    datastore?: any;
    /** file to persist to — the adapter opens a Datastore for you */
    filename?: string;
    /** an alias of `filename` */
    path?: string;
    /** keep everything in memory (no file) */
    inMemory?: boolean;
    /** namespace this session inside the store: keys become `<session>:<type>-<id>` */
    session?: string;
}
export declare function useNedbAuthState(
/**
 * Accepted shapes: `(datastore)`, `(filename)`, `({ filename })`, `(datastore, { session })`,
 * `({ filename, session })` — and the other mixes every adapter accepts.
 */
a: any, b?: string | NedbAuthStateOptions, c?: string | NedbAuthStateOptions): Promise<NedbAuthState>;
//# sourceMappingURL=use-nedb-auth-state.d.ts.map