import { extractNewsletterMessageMeta } from '../Utils/newsletter-meta.js';
import type { BinaryNode } from '../WABinary/index.js';
export declare const PortedNewsletterQueryIds: {
    readonly UPDATE_USER_SETTING: "31938993655691868";
    readonly ENFORCEMENTS: "27835373536068060";
    readonly CHANNEL_REPORTS: "35936238352686172";
    readonly CREATE_REPORT_APPEAL: "27103316329328467";
    readonly ADMIN_CAPABILITIES: "9801384413216421";
    readonly ADMIN_INFO: "26278439461859188";
    readonly POLL_VOTERS: "9407762219322536";
    readonly REACTION_SENDER_LIST: "29575462448733991";
    readonly PIN_MESSAGES: "27165709459706559";
    readonly UNPIN_MESSAGES: "28007176042216937";
    readonly LABEL_AI_CONTENT: "27909718265289596";
    readonly PAID_PARTNERSHIP_LABEL: "26102375079404865";
    readonly CREATE_ADMIN_INVITE: "9387141988078609";
    readonly REVOKE_ADMIN_INVITE: "9656078347839416";
    readonly ACCEPT_ADMIN_INVITE: "9580828702035549";
    readonly RECOMMENDED: "25806748772361516";
    readonly SIMILAR: "26217043484590756";
    readonly INSIGHTS: "9853618868050977";
    readonly FOLLOWERS: "27472091235714801";
    readonly PENDING_ADMIN_INVITES: "28049623068067370";
    readonly QUESTION_RESPONSE_STATE: "24636260219323456";
    readonly DIRECTORY_LIST: "26125047313831973";
    readonly DIRECTORY_SEARCH: "26301059626252132";
    readonly DIRECTORY_CATEGORIES: "35266481849605779";
};
export declare const PortedNewsletterPaths: {
    readonly xwa2_newsletter_update_user_setting: "xwa2_newsletter_update_user_setting";
    readonly xwa2_channel_enforcements: "xwa2_channel_enforcements";
    readonly xwa2_channels_reports: "xwa2_channels_reports";
    readonly xwa2_create_channel_report_appeal_v2: "xwa2_create_channel_report_appeal_v2";
    readonly xwa2_newsletter_admin_capabilities: "xwa2_newsletter_admin";
    readonly xwa2_newsletter_admin_info: "xwa2_newsletter_admin";
    readonly voter_list: "voter_list";
    readonly xwa2_newsletters_reaction_sender_list: "xwa2_newsletters_reaction_sender_list";
    readonly xwa2_newsletter_pin_messages: "xwa2_newsletter_pin_messages";
    readonly xwa2_newsletter_unpin_messages: "xwa2_newsletter_unpin_messages";
    readonly xwa2_newsletter_label_ai_content: "xwa2_newsletter_label_ai_content";
    readonly xwa2_newsletter_label_paid_partnership: "xwa2_newsletter_label_paid_partnership";
    readonly xwa2_newsletter_admin_invite_create: "xwa2_newsletter_admin_invite_create";
    readonly xwa2_newsletter_admin_invite_revoke: "xwa2_newsletter_admin_invite_revoke";
    readonly xwa2_newsletter_admin_invite_accept: "xwa2_newsletter_admin_invite_accept";
    readonly xwa2_newsletters_recommended: "xwa2_newsletters_recommended";
    readonly xwa2_newsletters_similar: "xwa2_newsletters_similar";
    readonly xwa2_newsletter_admin_insights: "xwa2_newsletter_admin_insights";
    readonly xwa2_newsletter_followers: "xwa2_newsletter_followers";
    readonly pending_admin_invites: "xwa2_newsletter_admin";
    readonly xwa2_newsletter_question_response_state_update: "xwa2_newsletter_question_response_state_update";
    readonly xwa2_newsletters_directory_list: "xwa2_newsletters_directory_list";
    readonly xwa2_newsletters_directory_search: "xwa2_newsletters_directory_search";
    readonly xwa2_newsletters_directory_category_preview: "xwa2_newsletters_directory_category_preview";
};
/** The server only accepts newsletter message server ids in this range. */
export declare const toNewsletterServerIds: (serverIds: unknown) => string[];
export type NewsletterUserSettingType = 'ADMIN_NOTIFICATIONS' | 'FOLLOWER_NOTIFICATIONS';
export declare const toNewsletterUserSettingInput: (jid: string, type: NewsletterUserSettingType, muted: boolean) => {
    input: {
        newsletter_id: string;
        type: string;
        value: string;
    };
};
export type { NewsletterMessageMeta } from '../Utils/newsletter-meta.js';
export { extractNewsletterMessageMeta };
export declare const decodeNewsletterPlaintext: (plaintextNode?: BinaryNode) => {
    [k: string]: any;
} | undefined;
export declare const decodeNewsletterMessageNodes: (parentNode: BinaryNode, newsletterJid: string, logger?: any) => any[];
type QueryFn = (node: BinaryNode) => Promise<BinaryNode>;
export interface NewsletterExtrasDeps {
    query: QueryFn;
    generateMessageTag: () => string;
    logger?: any;
}
/** Builds the extra newsletter methods on top of `query` + `generateMessageTag` (both come from the base socket). */
export declare const makeNewsletterExtras: ({ query, generateMessageTag, logger }: NewsletterExtrasDeps) => {
    /** mute / unmute notifications (`ADMIN_NOTIFICATIONS` or `FOLLOWER_NOTIFICATIONS`) of a channel */
    newsletterUpdateUserSetting: (jid: string, type: NewsletterUserSettingType, muted: boolean) => Promise<{
        id: any;
        state: any;
    }>;
    /** reaction setting of an owned channel: `ALL` | `BASIC` | `NONE` | `BLOCKLIST` */
    newsletterUpdateReactions: (jid: string, setting: string) => Promise<any>;
    newsletterFetchMessageUpdates: (jid: string, options?: {
        count?: number;
        since?: number;
        before?: number;
        after?: number;
    }) => Promise<{
        jid: string;
        messages: any[];
    }>;
    newsletterQuestionResponses: (jid: string, serverId: string | number, options?: {
        count?: number;
        before?: number;
        filter?: string;
        searchText?: string;
    }) => Promise<{
        jid: string;
        serverId: number;
        responses: {
            id: string | undefined;
            t: number | undefined;
            isSender: boolean;
            responseServerId: string | undefined;
            sender: {
                lid: string | undefined;
                notifyName: string | undefined;
                pictureDirectPath: string | undefined;
            };
            replied: boolean;
            starred: boolean;
            message: {
                [k: string]: any;
            } | undefined;
        }[];
    }>;
    /** your own reactions / poll votes in channels */
    newsletterMyAddOns: (options?: {
        limit?: number;
        jid?: string;
    }) => Promise<{
        jid: string | undefined;
        messages: {
            serverId: number | undefined;
            reaction: {
                code: string | undefined;
                t: number | undefined;
            } | undefined;
            pollVote: {
                t: number | undefined;
                hashes: string[];
            } | undefined;
        }[];
    }[]>;
    /** your own reactions / poll votes on channel statuses */
    newsletterStatusMyAddOns: (options?: {
        limit?: number;
        jid?: string;
    }) => Promise<{
        jid: string | undefined;
        messages: {
            serverId: number | undefined;
            reaction: {
                code: string | undefined;
                t: number | undefined;
            } | undefined;
            pollVote: {
                t: number | undefined;
                hashes: string[];
            } | undefined;
        }[];
    }[]>;
    newsletterAdminCapabilities: (jid: string) => Promise<string[]>;
    newsletterEnforcements: (jid: string, locale?: string) => Promise<{
        adminProfiles: any;
        profilePictureDeletions: any;
        suspensions: any;
        violatingMessages: {
            enforcementId: any;
            createdAt: number | undefined;
            violationCategory: any;
            source: any;
            appealState: any;
            appealCreatedAt: number | undefined;
            appealReasonOptions: any;
            appealFormUrl: any;
            policy: {
                headline: any;
                subtitle: any;
                overview: any;
                explanation: any;
                adminDisclaimer: any;
            } | undefined;
        }[];
        geoSuspensions: {
            enforcementId: any;
            createdAt: number | undefined;
            violationCategory: any;
            source: any;
            appealState: any;
            appealCreatedAt: number | undefined;
            appealReasonOptions: any;
            appealFormUrl: any;
            policy: {
                headline: any;
                subtitle: any;
                overview: any;
                explanation: any;
                adminDisclaimer: any;
            } | undefined;
        }[];
    }>;
    newsletterReports: (locale?: string) => Promise<any>;
    newsletterAppealReport: (reportId: string | number, reason: string) => Promise<any>;
    /** can this account post channel statuses (and music statuses) in `jid`? */
    newsletterCanPostStatus: (jid: string) => Promise<{
        canPost: boolean;
        canPostMusic: boolean;
        capabilities: string[];
    }>;
    newsletterAdminInfo: (jid: string) => Promise<{
        id: any;
        adminCount: any;
        adminProfile: {
            id: any;
            name: any;
            picture: {
                id: any;
                directPath: any;
            } | undefined;
        } | undefined;
        adminProfilesEnabled: any;
    }>;
    newsletterPollVoters: (jid: string, serverId: string | number, options?: {
        limit?: number;
        voteHash?: string;
    }) => Promise<any>;
    newsletterReactionSenders: (jid: string, serverId: string | number) => Promise<any>;
    newsletterPinMessages: (jid: string, serverIds: string | number | (string | number)[]) => Promise<any>;
    newsletterUnpinMessages: (jid: string, serverIds: string | number | (string | number)[]) => Promise<any>;
    newsletterLabelAiContent: (jid: string, serverId: string | number, messageType?: string) => Promise<any>;
    newsletterLabelPaidPartnership: (jid: string, serverId: string | number, messageType?: string) => Promise<any>;
    newsletterCreateAdminInvite: (jid: string, userJid: string) => Promise<any>;
    newsletterRevokeAdminInvite: (jid: string, userJid: string) => Promise<any>;
    newsletterAcceptAdminInvite: (jid: string) => Promise<any>;
    newsletterDirectoryList: (options?: {
        fetchStatusMetadata?: boolean;
        view?: string;
        countryCodes?: string[];
        categories?: string[];
        limit?: number;
        cursorToken?: string;
    }) => Promise<any>;
    newsletterDirectorySearch: (searchText: string, options?: {
        fetchStatusMetadata?: boolean;
        categories?: string[];
        limit?: number;
        cursorToken?: string;
    }) => Promise<any>;
    newsletterDirectoryCategories: (options?: {
        fetchStatusMetadata?: boolean;
        categories?: string[];
        countryCode?: string;
        perCategoryLimit?: number;
    }) => Promise<any>;
    /** vote on a channel poll (`options` are the option names; they are hashed with SHA-256) */
    newsletterSendPollVote: (jid: string, parentServerId: string | number, options: string | string[]) => Promise<{
        id: string;
    }>;
    newsletterInsights: (jid: string, options?: {
        metrics?: string[];
    }) => Promise<any>;
    newsletterFollowers: (jid: string, options?: {
        count?: number;
    }) => Promise<any>;
    newsletterPendingAdminInvites: (jid: string) => Promise<any>;
    newsletterQuestionResponseState: (jid: string, serverId: string | number, responseServerId: string | number, state: string) => Promise<any>;
    newsletterRecommended: (options?: {
        fetchStatusMetadata?: boolean;
        limit?: number;
        countryCodes?: string[];
    }) => Promise<any>;
    newsletterSimilar: (jid: string, options?: {
        fetchStatusMetadata?: boolean;
        limit?: number;
        countryCodes?: string[];
    }) => Promise<any>;
};
//# sourceMappingURL=newsletter-extras.d.ts.map