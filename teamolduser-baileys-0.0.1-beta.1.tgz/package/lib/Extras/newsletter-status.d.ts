/**
 * Ported from @rexxhayanasi/elaina-baileys (MIT, Copyright (c) 2025 Rajeh Taher/WhiskeySockets,
 * (c) 2026 rexxhayanasi) - Utils/newsletter-status.js, rewritten in TypeScript as an add-on socket layer.
 *
 * Channel (newsletter) STATUS posts: `sendNewsletterStatus` (text / image / video / gif / audio, questions, AI label),
 * `sendNewsletterStatusReaction`, `revokeNewsletterStatus`, `getNewsletterStatuses`, `getNewsletterStatusUpdates`.
 * The `<status>` stanza format comes from elaina-baileys and was NOT re-verified against a live WhatsApp server here.
 *
 * NOTE for anyone porting Elaina code against this file: `toNewsletterServerId`, `NEWSLETTER_SERVER_ID_MIN` and
 * `NEWSLETTER_SERVER_ID_MAX` are exported from `./newsletter-extras`, not from here, even though Elaina exports them
 * from `Utils/newsletter-status.js`. They are re-exported from the package root as usual, so only deep imports of
 * this module see the difference.
 */
import { proto } from '../../WAProto/index.js';
import type { BinaryNode } from '../WABinary/index.js';
declare const NEWSLETTER_STATUS_MEDIA_TYPES: Set<string>;
declare const NEWSLETTER_STATUS_WEB_MEDIA_TYPES: Set<string>;
declare const NEWSLETTER_STATUS_CONTENT_TYPES: Set<string>;
export declare const getNewsletterStatusMediaType: (message: any) => string | undefined;
export declare const NEWSLETTER_SERVER_ID_MIN = 99;
export declare const NEWSLETTER_SERVER_ID_MAX = 2147476647;
export declare const toNewsletterServerId: (value: unknown, label?: string) => string;
export declare const withNewsletterStatusAttribution: (content: any) => any;
export declare const parseNewsletterStatusAck: (node: any, { jid, messageId }?: {
    jid?: string;
    messageId?: string;
}) => {
    class: string | undefined;
    from: string | undefined;
    id: string | undefined;
    t: number | undefined;
    serverId: number | undefined;
    edit: string | undefined;
    error: string | undefined;
    applicationError: number | undefined;
    backoff: number | undefined;
    node: any;
};
export interface NewsletterStatusConfig {
    logger?: any;
    mediaCache?: any;
    options?: any;
}
export interface NewsletterStatusSocket {
    ws: {
        on: (event: string, listener: (node: any) => void) => any;
        off: (event: string, listener: (node: any) => void) => any;
    };
    query: (node: BinaryNode) => Promise<BinaryNode>;
    sendNode: (node: BinaryNode) => Promise<void>;
    waitForMessage: (messageId: string, timeoutMs?: number) => Promise<any>;
    waUploadToServer: (...args: any[]) => Promise<any>;
    authState: {
        creds: {
            me?: {
                id: string;
            };
        };
    };
    logger?: any;
}
/**
 * The ack carries from, class, id and t, and nothing else. The server id lands separately, in the `<status>` stanza the
 * server sends back to the publisher. Reacting to or revoking your own status needs that id, so wait a moment for the echo.
 */
export declare const waitForNewsletterStatusServerId: (sock: NewsletterStatusSocket, { jid, messageId, timeoutMs }: {
    jid?: string;
    messageId?: string;
    timeoutMs?: number;
}) => Promise<{
    serverId: number;
    node: any;
} | undefined> & {
    cancel?: () => void;
};
export declare const buildNewsletterAdminProfileStatusMessage: (message: any) => proto.Message & proto.Message.$Shape;
export declare const buildNewsletterStatusNode: ({ jid, message, payload, messageId, mediaType, mediaId, mediaHandle, parentServerId, responseServerId, interactionType, aiContent }: {
    jid: string;
    message?: any;
    payload?: Uint8Array;
    messageId: string;
    mediaType?: string;
    mediaId?: string | number;
    mediaHandle?: string | number;
    parentServerId?: string | number;
    responseServerId?: string | number;
    interactionType?: string;
    aiContent?: boolean;
}) => BinaryNode;
export declare const buildNewsletterStatusReactionNode: ({ jid, messageId, parentServerId, reaction }: {
    jid: string;
    messageId: string;
    parentServerId: string | number;
    reaction?: string | null;
}) => BinaryNode;
export declare const buildNewsletterStatusRevokeNode: ({ jid, statusId }: {
    jid: string;
    statusId: string;
}) => BinaryNode;
/**
 * Posts a channel status. `content` is any content `sock.sendMessage` understands (text / image / video / gif /
 * audio, `question`, ...). Options: `aiContent`, `interactionType`, `parentServerId`, `responseServerId`,
 * `statusAttribution` (default true), `messageId`, `ackTimeoutMs`, `resolveServerId`, `serverIdTimeoutMs`.
 * Returns the message with `newsletterStatusServerId` (needed for reactions / revoke).
 */
export declare const makeNewsletterStatusSender: (sock: NewsletterStatusSocket, config: NewsletterStatusConfig) => (jid: string, content: any, options?: Record<string, any>) => Promise<any>;
/** react to a channel status; `reaction: null` removes your reaction */
export declare const makeNewsletterStatusReactionSender: (sock: NewsletterStatusSocket) => (jid: string, parentServerId: string | number, reaction?: string | null, options?: {
    messageId?: string;
    ackTimeoutMs?: number;
}) => Promise<{
    key: {
        remoteJid: string;
        fromMe: boolean;
        id: string;
    };
    status: proto.WebMessageInfo.Status;
    newsletterStatusServerId: number | undefined;
    newsletterStatusAck: {
        class: string | undefined;
        from: string | undefined;
        id: string | undefined;
        t: number | undefined;
        serverId: number | undefined;
        edit: string | undefined;
        error: string | undefined;
        applicationError: number | undefined;
        backoff: number | undefined;
        node: any;
    };
    newsletterStatusResponse: any;
}>;
/** delete one of your channel statuses (`statusId` is the message id of the status you sent) */
export declare const makeNewsletterStatusRevokeSender: (sock: NewsletterStatusSocket) => (jid: string, statusId: string, options?: {
    ackTimeoutMs?: number;
}) => Promise<{
    key: {
        remoteJid: string;
        fromMe: boolean;
        id: string;
    };
    status: proto.WebMessageInfo.Status;
    newsletterStatusAck: {
        class: string | undefined;
        from: string | undefined;
        id: string | undefined;
        t: number | undefined;
        serverId: number | undefined;
        edit: string | undefined;
        error: string | undefined;
        applicationError: number | undefined;
        backoff: number | undefined;
        node: any;
    };
    newsletterStatusResponse: any;
}>;
export declare const parseNewsletterStatusUpdatesResponse: (node: BinaryNode) => {
    jid: string | undefined;
    t: number | undefined;
    statuses: {
        id: string | undefined;
        serverId: number | undefined;
        t: number | undefined;
        isSender: boolean;
        type: string | undefined;
        edit: string | undefined;
        mediaType: string | undefined;
        interactionType: string | undefined;
        reaction: string | undefined;
        adminProfile: {
            id: string | undefined;
            name: string | undefined;
            pictureId: string | undefined;
            pictureDirectPath: string | undefined;
        } | undefined;
        paidPartnership: boolean;
        aiContent: boolean;
        editTimestamp: number | undefined;
        originalTimestamp: number | undefined;
        reactionCounts: {
            code: string | undefined;
            count: number | undefined;
        }[] | undefined;
        viewsCount: number | undefined;
        responsesCount: number | undefined;
        message: (proto.Message & proto.Message.$Shape) | undefined;
        node: BinaryNode;
    }[];
};
/** status updates (reactions / views counters) of a channel since a timestamp */
export declare const makeNewsletterStatusUpdatesFetcher: (sock: NewsletterStatusSocket) => (jid: string, options?: Record<string, any>) => Promise<{
    jid: string | undefined;
    t: number | undefined;
    statuses: {
        id: string | undefined;
        serverId: number | undefined;
        t: number | undefined;
        isSender: boolean;
        type: string | undefined;
        edit: string | undefined;
        mediaType: string | undefined;
        interactionType: string | undefined;
        reaction: string | undefined;
        adminProfile: {
            id: string | undefined;
            name: string | undefined;
            pictureId: string | undefined;
            pictureDirectPath: string | undefined;
        } | undefined;
        paidPartnership: boolean;
        aiContent: boolean;
        editTimestamp: number | undefined;
        originalTimestamp: number | undefined;
        reactionCounts: {
            code: string | undefined;
            count: number | undefined;
        }[] | undefined;
        viewsCount: number | undefined;
        responsesCount: number | undefined;
        message: (proto.Message & proto.Message.$Shape) | undefined;
        node: BinaryNode;
    }[];
}>;
export declare const parseNewsletterStatusesResponse: (node: BinaryNode) => {
    jid: string | undefined;
    t: number | undefined;
    statuses: {
        id: string | undefined;
        serverId: number | undefined;
        t: number | undefined;
        isSender: boolean;
        type: string | undefined;
        edit: string | undefined;
        mediaType: string | undefined;
        interactionType: string | undefined;
        reaction: string | undefined;
        adminProfile: {
            id: string | undefined;
            name: string | undefined;
            pictureId: string | undefined;
            pictureDirectPath: string | undefined;
        } | undefined;
        paidPartnership: boolean;
        aiContent: boolean;
        editTimestamp: number | undefined;
        originalTimestamp: number | undefined;
        reactionCounts: {
            code: string | undefined;
            count: number | undefined;
        }[] | undefined;
        viewsCount: number | undefined;
        responsesCount: number | undefined;
        message: (proto.Message & proto.Message.$Shape) | undefined;
        node: BinaryNode;
    }[];
};
/** statuses of a channel: `{ jid, t, statuses: [...] }` */
export declare const makeNewsletterStatusFetcher: (sock: NewsletterStatusSocket) => (jid: string, options?: Record<string, any>) => Promise<{
    jid: string | undefined;
    t: number | undefined;
    statuses: {
        id: string | undefined;
        serverId: number | undefined;
        t: number | undefined;
        isSender: boolean;
        type: string | undefined;
        edit: string | undefined;
        mediaType: string | undefined;
        interactionType: string | undefined;
        reaction: string | undefined;
        adminProfile: {
            id: string | undefined;
            name: string | undefined;
            pictureId: string | undefined;
            pictureDirectPath: string | undefined;
        } | undefined;
        paidPartnership: boolean;
        aiContent: boolean;
        editTimestamp: number | undefined;
        originalTimestamp: number | undefined;
        reactionCounts: {
            code: string | undefined;
            count: number | undefined;
        }[] | undefined;
        viewsCount: number | undefined;
        responsesCount: number | undefined;
        message: (proto.Message & proto.Message.$Shape) | undefined;
        node: BinaryNode;
    }[];
}>;
export { NEWSLETTER_STATUS_CONTENT_TYPES, NEWSLETTER_STATUS_MEDIA_TYPES, NEWSLETTER_STATUS_WEB_MEDIA_TYPES };
//# sourceMappingURL=newsletter-status.d.ts.map