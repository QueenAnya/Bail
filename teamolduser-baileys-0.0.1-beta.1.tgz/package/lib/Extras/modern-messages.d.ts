/**
 * Ported from @rexxhayanasi/elaina-baileys (MIT) - Utils/modern-messages.js, rewritten in TypeScript.
 *
 * Content keys for the newer WhatsApp message types, converted into raw `proto.Message` content:
 *   question, questionReply, questionResponse, statusQuestionAnswer, statusQuoted, statusStickerInteraction,
 *   statusNotification, newsletterAdminInvite, newsletterFollowerInvite, pollAddOption, comment, eventInvite,
 *   scheduledCall, scheduledCallEdit, groupStatusReaction, statusMention
 * plus the helper keys newsletterStatus / groupStatusAttribution / statusAttributions / statusAudience / addYours /
 * messageAssociation that decorate any other content.
 *
 * `prepareModernMessageContent` runs in front of `sock.sendMessage` (see Extras/socket.ts), so
 *   sock.sendMessage(jid, { question: { text: 'Favourite colour?' } })
 * just works.
 *
 * `PollAddOptionMessage` / `EventInviteMessage` are attached under `proto.Message` by Utils/proto-compat.ts
 * (this WAProto keeps them flat); `pollAddOption` and `eventInvite` throw a clear error only if neither exists. `NEWSLETTER_STATUS` (attribution type 9) is sent as its number.
 */
import { proto } from '../../WAProto/index.js';
/** `StatusAttribution.Type.NEWSLETTER_STATUS` (not named in this WAProto) */
export declare const STATUS_NOTIFICATION_TYPES: Readonly<Record<string, number>>;
export declare const makeQuestionMessage: (input: any) => {
    questionMessage: proto.Message.FutureProofMessage & proto.Message.FutureProofMessage.$Shape;
};
export declare const makeQuestionResponseMessage: (input: any) => {
    questionResponseMessage: proto.Message.QuestionResponseMessage & proto.Message.QuestionResponseMessage.$Properties;
};
export declare const makeQuestionReplyMessage: (input: any) => {
    questionReplyMessage: proto.Message.FutureProofMessage & proto.Message.FutureProofMessage.$Shape;
};
export declare const makeStatusQuestionAnswerMessage: (input: any) => {
    statusQuestionAnswerMessage: proto.Message.StatusQuestionAnswerMessage & proto.Message.StatusQuestionAnswerMessage.$Properties;
};
export declare const makeStatusQuotedMessage: (input: any) => {
    statusQuotedMessage: proto.Message.StatusQuotedMessage & proto.Message.StatusQuotedMessage.$Properties;
};
export declare const makeStatusStickerInteractionMessage: (input: any) => {
    statusStickerInteractionMessage: proto.Message.StatusStickerInteractionMessage & proto.Message.StatusStickerInteractionMessage.$Properties;
};
export declare const makeStatusNotificationMessage: (input: any) => {
    statusNotificationMessage: proto.Message.StatusNotificationMessage & proto.Message.StatusNotificationMessage.$Properties;
};
export declare const makeNewsletterAdminInviteMessage: (input: any) => {
    newsletterAdminInviteMessage: proto.Message.NewsletterAdminInviteMessage & proto.Message.NewsletterAdminInviteMessage.$Shape;
};
export declare const makeNewsletterFollowerInviteMessage: (input: any) => {
    newsletterFollowerInviteMessageV2: proto.Message.NewsletterFollowerInviteMessage & proto.Message.NewsletterFollowerInviteMessage.$Shape;
};
export declare const makePollAddOptionMessage: (input: any) => {
    pollAddOptionMessage: any;
};
export declare const makeCommentMessage: (input: any) => {
    commentMessage: proto.Message.CommentMessage & proto.Message.CommentMessage.$Shape;
};
export declare const makeEventInviteMessage: (input: any) => {
    eventInviteMessage: any;
};
export declare const makeScheduledCallCreationMessage: (input: any) => {
    scheduledCallCreationMessage: proto.Message.ScheduledCallCreationMessage & proto.Message.ScheduledCallCreationMessage.$Properties;
};
export declare const makeScheduledCallEditMessage: (input: any) => {
    scheduledCallEditMessage: proto.Message.ScheduledCallEditMessage & proto.Message.ScheduledCallEditMessage.$Properties;
};
export declare const makeGroupStatusReactionMessage: (input: any) => {
    groupStatusMessageV2: proto.Message.FutureProofMessage & proto.Message.FutureProofMessage.$Shape;
};
export declare const makeNewsletterStatusAttribution: (input: any) => proto.StatusAttribution & proto.StatusAttribution.$Shape;
export declare const makeGroupStatusAttribution: (input: any) => proto.StatusAttribution & proto.StatusAttribution.$Shape;
export declare const STATUS_AUDIENCE_DEFAULT_LIST_NAME = "Close friends";
export declare const STATUS_AUDIENCE_DEFAULT_EMOJI = "\u2B50";
export declare const makeStatusAudienceMetadata: (input: any) => proto.ContextInfo.StatusAudienceMetadata & proto.ContextInfo.StatusAudienceMetadata.$Properties;
export declare const makeMessageAssociation: (input: any) => proto.MessageAssociation & proto.MessageAssociation.$Properties;
export declare const makeStatusAddYoursAssociation: (input: any) => proto.MessageAssociation & proto.MessageAssociation.$Properties;
export declare const makeStatusMentionMessage: (input: any) => {
    [x: string]: proto.Message.FutureProofMessage & proto.Message.FutureProofMessage.$Shape;
};
/** Turns the modern content keys above into `{ raw: true, ...protoFields }`; every other content passes through untouched. */
export declare const prepareModernMessageContent: (content: any) => any;
//# sourceMappingURL=modern-messages.d.ts.map