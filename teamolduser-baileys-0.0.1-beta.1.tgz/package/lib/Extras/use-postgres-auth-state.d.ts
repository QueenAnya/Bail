import { type DatabaseAuthState } from './auth-store.js';
export interface PostgresAuthStateOptions {
    /** an existing `pg` Pool (it is NOT closed by `close()`) */
    pool?: any;
    /** connection string, used when no pool is given */
    connectionString?: string;
    /** Alias for `connectionString` — every adapter accepts the same key. */
    url?: string;
    /** `pg` Pool config, used when no pool is given */
    config?: any;
    /** table name (plain identifier), default `baileys_auth` */
    table?: string;
    /** session name, lets several bots share one table, default `default` */
    session?: string;
}
export declare function usePostgresAuthState(
/** `(connectionString)`, `(connectionString, table, session)`, `({ connectionString, table, session })`, `({ pool })`. */
a?: string | PostgresAuthStateOptions, b?: string | PostgresAuthStateOptions, c?: string): Promise<DatabaseAuthState>;
//# sourceMappingURL=use-postgres-auth-state.d.ts.map