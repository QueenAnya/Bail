import '../Utils/proto-compat.js';
/** The elaina-baileys release this layer was ported from, and the release it was last checked against. */
export declare const PORTED_FROM: Readonly<{
    portedFrom: "elaina-baileys 1.4.x (forked upstream at 1.4.5)";
    recheckedAgainst: "elaina-baileys 1.4.7";
    recheckedOn: "2026-10-28";
    /** every export of the 1.4.7 source tree resolves somewhere in this repo (712/712 names) */
    exportSurfaceMatches: true;
    /** `node scripts/audit-elaina-parity.mjs` compares the ported modules after type-stripping */
    byteIdenticalModules: "15/15";
}>;
/**
 * src/Extras
 *
 * Features ported from other Baileys forks (each file names its source and license in its header).
 * Same idea as `src/Addons`, kept separate so it is clear where the code came from.
 *
 *   Database auth states   -> usePostgresAuthState, useMySQLAuthState, useRedisAuthState, useRedisAuthState2,
 *                             useNekoDBAuth,
 *                             useMongoAuthState2, useSqliteAuthState2, useTursoAuthState,
 *                             makeAuthStateFromStore (source: @rexxhayanasi/elaina-baileys)
 *   Newsletter extras      -> makeNewsletterExtras (admin invites / info, followers, insights, directory, recommended,
 *                             enforcements, reports, pin, labels, poll votes ...)
 *   Chats extras           -> getUsername / removeUsername / checkUsernameAvailability / getUsernames / removeUsernamePin,
 *                             fetchAbout, updateTextStatus, notices, opt-out list, push settings, server link preview,
 *                             reportSpam, fetchProps / getServerProps, checkAccountHealth
 *   Messages extras        -> sendHD, sendImgVid (motion photo), removeMemberLabel, resetGroupSenderKey,
 *                             groupQuery, communityQuery, executeWMexQuery
 *   Newsletter status      -> sendNewsletterStatus, sendNewsletterStatusReaction, revokeNewsletterStatus,
 *                             getNewsletterStatuses, getNewsletterStatusUpdates
 *   Modern messages        -> question / comment / statusMention / statusQuoted ... content keys (modern-messages.ts),
 *                             split payment + payment reminder (payment-messages.ts), music + status stickers
 *                             (status-stickers.ts), scheduled message helpers (scheduled-message.ts)
 *   Elaina-only modules    -> group-metadata-cache, ttl-cache, sender-key-memory, optional-media, native-flow,
 *                             html-app, html-multiplayer, link-preview-metadata, voice-recognition and the
 *                             MessageBuilder/ folder (AIRich / A2UI / Bloks / Meta AI sections / bot signature)
 */
export * from './auth-store.js';
export * from './store-exports.js';
export * from './use-postgres-auth-state.js';
export * from './use-mysql-auth-state.js';
export * from './use-redis-auth-state.js';
export * from './use-redis-auth-state2.js';
export * from './use-nekodb-auth-state.js';
export * from './use-nedb-auth-state.js';
export * from './use-turso-auth-state.js';
export * from './use-mongo-auth-state2.js';
export * from './use-sqlite-auth-state2.js';
export * from './newsletter-extras.js';
export * from './chats-extras.js';
export * from './messages-extras.js';
export * from './newsletter-status.js';
export * from './newsletter-status-socket.js';
export * from './modern-messages.js';
export * from './payment-messages.js';
export * from './scheduled-message.js';
export * from './status-stickers.js';
export * from './socket.js';
export * from './group-metadata-cache.js';
export * from './ttl-cache.js';
export * from './sender-key-memory.js';
export * from './optional-media.js';
export * from './native-flow.js';
export * from './html-app.js';
export * from './html-multiplayer.js';
export * from './link-preview-metadata.js';
export * from './voice-recognition.js';
import './MessageBuilder/attach-static-helpers.js';
export * from './MessageBuilder/index.js';
export * from './MessageBuilder/extras.js';
export * from './MessageBuilder/metaai.js';
export * from './MessageBuilder/bot-signature.js';
export * from './messages-helpers.js';
export * from './v2.js';
//# sourceMappingURL=index.d.ts.map