/**
 * Ported from @rexxhayanasi/elaina-baileys 1.4.x (MIT) - Utils/native-flow.js
 * Copied as-is (JS -> TS); only import paths and parameter types were adapted for tb2.
 * Re-checked against elaina-baileys 1.4.7: the exported surface matches; see PORTED_FROM below.
 */
export declare const NATIVE_FLOW_NAMES: readonly string[];
export declare const WEB_SUPPORTED_INTERACTIVE_FLOWS: readonly string[];
export declare const NATIVE_FLOW_BUTTON_LIMIT: Readonly<{
    quickReply: 10;
    other: 3;
}>;
export declare const getNativeFlowNameByButtonName: (name: string) => string | undefined;
export declare const isWebSupportedButtonName: (name: string) => boolean;
export declare const checkNativeFlowButtons: (buttons?: any[] | any) => {
    ok: boolean;
    limit: 10 | 3;
    problems: string[];
    unsupported: any[];
};
//# sourceMappingURL=native-flow.d.ts.map