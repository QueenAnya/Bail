import type { AuthenticationCreds, AuthenticationStateWithListing } from '../Types/index.js';
export declare const CREDS_KEY = "creds";
export interface AuthStoreEntry {
    type: string;
    id: string;
    value: string;
}
export interface AuthStore {
    /** returns the stored JSON string, or null */
    read: (type: string, id: string) => Promise<string | null | undefined>;
    readMany: (type: string, ids: string[]) => Promise<Record<string, string>>;
    write: (type: string, id: string, value: string) => Promise<void>;
    /** applies all writes and removals (transactionally where the backend supports it) */
    apply: (writes: AuthStoreEntry[], removals: Omit<AuthStoreEntry, 'value'>[]) => Promise<void>;
    /**
     * Enumerate every `(id, value)` pair for a type.
     *
     * Required: every backend behind this helper (SQL, Redis, Mongo, NekoDB) can enumerate its rows, and
     * `migrateAuthState` needs it. Requiring it here is what lets these adapters return a provably migratable state.
     */
    list: (type: string) => AsyncIterable<readonly [string, string]>;
    /** ids-only fast path, for adapters that can answer without reading the values */
    listIds?: (type: string) => AsyncIterable<string>;
    /** removes every row of this session */
    clear: () => Promise<void>;
    close?: () => Promise<void>;
}
export interface DatabaseAuthState {
    state: AuthenticationStateWithListing;
    saveCreds: () => Promise<void>;
    /** deletes the whole session from the backend */
    clearAuth: () => Promise<void>;
    /** closes the connection / pool when this auth state created it */
    close: () => Promise<void>;
}
export declare const encodeAuthValue: (value: unknown) => string;
export declare const decodeAuthValue: (type: string, raw: unknown) => any;
/** Loads a ported auth adapter's runtime database driver with a helpful error if installation is incomplete. */
export declare const loadOptionalModule: (name: string, usedBy: string) => Promise<any>;
/**
 * Reset a creds object in place. `clearAuth()` empties the store, but the creds object is handed to the socket by
 * reference — if it is not reset too, the next `saveCreds()` writes the old credentials straight back into the store
 * that was just emptied, and the account silently comes back. Mutating in place keeps the identity the socket holds.
 */
export declare const resetCredsInPlace: (creds: AuthenticationCreds) => void;
export declare const makeAuthStateFromStore: (store: AuthStore) => Promise<DatabaseAuthState>;
//# sourceMappingURL=auth-store.d.ts.map