export declare const normalizeVoiceText: (value: any) => string;
export declare const matchVoiceWakePhrase: (transcript: string, phrases?: string[]) => {
    phrase: string;
    normalizedPhrase: string;
    normalizedTranscript: string;
} | null;
export declare const removeVoiceWakePhrase: (transcript: string, wakePhrase: string) => string;
export declare const bindVoiceRecognition: (sock: any, config?: any, dependencies?: any) => () => any;
//# sourceMappingURL=voice-recognition.d.ts.map