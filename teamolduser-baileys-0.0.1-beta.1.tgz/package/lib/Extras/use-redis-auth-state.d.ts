import { type DatabaseAuthState } from './auth-store.js';
export interface RedisAuthStateOptions {
    /** an existing ioredis / node-redis client (it is NOT closed by `close()`) */
    client?: any;
    /** connection string, used when no client is given, e.g. `redis://localhost:6379` */
    uri?: string;
    /** alias of `uri` — the same connection string, for callers who read `REDIS_URL` */
    url?: string;
    /** ioredis options, used together with `uri` */
    config?: any;
    /** session name, lets several bots share one Redis, default `default` */
    session?: string;
    /** key prefix, default `baileys_auth` */
    prefix?: string;
}
/**
 * Opens a connection from a URI using whichever Redis package is installed, preferring `ioredis` (a dependency) and
 * falling back to node-redis (`redis` v4+), which the caller installs.
 */
export declare const connectFromUri: (uri: string, config?: any) => Promise<any>;
export declare function useRedisAuthState(
/** `(uri)`, `(uri, session)`, `({ uri, session })`, `({ client })`. */
a?: string | RedisAuthStateOptions, b?: string | RedisAuthStateOptions, c?: string): Promise<DatabaseAuthState>;
//# sourceMappingURL=use-redis-auth-state.d.ts.map