export declare const trimEmptyValues: (object: Record<string, any>) => Record<string, any>;
export declare const songThumbnail: (artwork: any, width: number, logger?: any) => Promise<any>;
export declare const prepareLinkThumbnail: (image: any, options: any, { thumbnailWidth, upload }?: {
    thumbnailWidth?: number;
    upload?: boolean;
}) => Promise<{
    jpegThumbnail: any;
    highQualityThumbnail?: undefined;
} | {
    jpegThumbnail: any;
    highQualityThumbnail: {
        directPath: any;
        mediaKey: Buffer<ArrayBuffer>;
        mediaKeyTimestamp: number;
        fileSha256: NonSharedBuffer;
        fileEncSha256: NonSharedBuffer;
        width: number;
        height: number;
    };
}>;
export declare const prepareProductMessage: (message: any, options: any) => Promise<any>;
export declare const buttonLimitFor: (buttons?: any[]) => 10 | 3;
export declare const nativeFlowButtonsViolateConstraints: (buttons?: any[]) => boolean;
export declare const warnOnNativeFlowConstraints: (buttons: any[], logger?: any) => void;
/**
 * The list under the spelling Elaina ships, where the constant carries a doubled `E`.
 *
 * Kept as a comment because it is the literal Elaina source: the array below is the same data, and the export under
 * it is what actually runs. Re-exporting the canonical constant (rather than re-declaring the array) keeps one source
 * of truth and avoids the circular import that a `const X = importedX` copy hits at module load.
 */
export { FUTURE_PROOF_MESSAGE_KEYS as FUTURE_PROOF_MESSAGEE_KEYS } from '../Utils/messages.js';
export { FUTURE_PROOF_MESSAGE_KEYS } from '../Utils/messages.js';
//# sourceMappingURL=messages-helpers.d.ts.map