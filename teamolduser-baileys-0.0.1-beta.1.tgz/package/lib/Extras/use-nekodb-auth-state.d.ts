import type { AuthenticationStateWithListing } from '../Types/index.js';
export interface NekoDBAuthState {
    state: AuthenticationStateWithListing;
    saveCreds: () => Promise<void>;
    /** drops the whole collection */
    clearAuth: () => Promise<void>;
}
export interface NekoDBAuthOptions {
    /**
     * Namespace this session inside the collection: keys are stored as `<session>:<key>`.
     *
     * Omit it (or pass `default`) and keys look exactly as they always have.
     */
    session?: string;
}
export declare function useNekoDBAuth(
/**
 * Accepted shapes: `(db)`, `(db, collectionName, { session })`, `({ db, collectionName, session })`.
 */
a: any, b?: string | (NekoDBAuthOptions & {
    db?: any;
    collectionName?: string;
}), c?: NekoDBAuthOptions): Promise<NekoDBAuthState>;
//# sourceMappingURL=use-nekodb-auth-state.d.ts.map