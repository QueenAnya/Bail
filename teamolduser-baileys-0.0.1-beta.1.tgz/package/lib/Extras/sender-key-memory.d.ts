/**
 * Ported from @rexxhayanasi/elaina-baileys 1.4.x (MIT) - Utils/sender-key-memory.js
 * Copied as-is (JS -> TS); only import paths and parameter types were adapted for tb2.
 * Re-checked against elaina-baileys 1.4.7: the exported surface matches; see PORTED_FROM below.
 */
export declare const pickSenderKeyRecipients: (devices: any[], senderKeyMap: Record<string, any>, { force, skip }?: {
    force?: boolean;
    skip?: (device: any) => boolean;
}) => any[];
export declare const deliveredSenderKeyJids: (nodes?: any[]) => Set<unknown>;
export declare const senderKeyResetSummary: (stored: Record<string, any> | undefined, jid: string) => {
    jid: string;
    cleared: number;
    devices: string[];
};
export declare const commitSenderKeyDelivery: (senderKeyMap: Record<string, any>, recipients: string[], nodes?: any[]) => {
    marked: string[];
    skipped: string[];
};
//# sourceMappingURL=sender-key-memory.d.ts.map