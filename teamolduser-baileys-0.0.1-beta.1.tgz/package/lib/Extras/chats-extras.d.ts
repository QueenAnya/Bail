import type { BinaryNode } from '../WABinary/index.js';
export declare const PortedChatQueryIds: {
    readonly ABOUT_STATUS: "24535500086059408";
    readonly PLAINTEXT_LINK_PREVIEW: "9101130456653613";
};
export declare const PortedChatPaths: {
    readonly xwa2_users_updates_since: "xwa2_users_updates_since";
    readonly xwa2_newsletter_link_preview: "xwa2_newsletter_link_preview";
};
export declare const SPAM_FLOWS: Readonly<{
    Block: "block_dialog";
    OverflowMenuBlock: "overflow_menu_block";
    OverflowMenuReport: "overflow_menu_report";
    MediaViewer: "media_viewer";
    MessageMenu: "message_menu";
    CommunityHome: "community_home";
    AccountInfoReport: "account_info_report";
    GroupInfoReport: "group_info_report";
    GroupSpamBannerReport: "group_spam_banner_report";
    OneToOneChatSpamBannerReport: "1_1_spam_banner_report";
    BizSpamBannerBlock: "biz_spam_banner_block";
    ChatListBlock: "chat_list_block";
    NotificationBlock: "notification_block";
    StatusPostReport: "status_post_report";
    NewsletterInfoReport: "newsletter_info_report";
}>;
export interface SpamReportOptions {
    /** one of `SPAM_FLOWS`, default `overflow_menu_report` */
    flow?: string;
    source?: string;
    subject?: string;
    isKnownChat?: boolean;
}
export declare const buildSpamListNode: (jid: string, options?: SpamReportOptions) => BinaryNode;
export declare const readSpamReportResult: (sent: BinaryNode, result: BinaryNode) => {
    jid: string | undefined;
    flow: string | undefined;
    reported: boolean;
    node: BinaryNode;
};
export interface AccountHealth {
    jid: string;
    exists: boolean;
    isBusiness: boolean;
    verifiedName: string | null;
    about: string | null;
    hasProfilePhoto: boolean;
    self: {
        capped?: boolean;
        warned?: boolean;
        unlimited?: boolean;
        remaining?: number;
    } | null;
    notes: string[];
}
export interface ChatsExtrasSocket {
    query: (node: BinaryNode) => Promise<BinaryNode>;
    generateMessageTag: () => string;
    logger?: any;
    ev: {
        emit: (event: any, data: any) => any;
    };
    authState?: {
        creds: any;
    };
    serverProps?: Record<string, any>;
    deleteUsername: () => Promise<any>;
    checkUsername: (username: string, includeSuggestions?: boolean) => Promise<any>;
    fetchContactUsernames: (...jids: string[]) => Promise<any[]>;
    onWhatsApp: (...jids: string[]) => Promise<any>;
    getBusinessProfile: (jid: string) => Promise<any>;
    fetchStatus: (...jids: string[]) => Promise<any>;
    profilePictureUrl: (jid: string, type?: 'preview' | 'image') => Promise<string | undefined>;
    fetchNewChatMessageCap: () => Promise<any>;
}
export declare const makeChatsExtras: (sock: ChatsExtrasSocket) => {
    /** own username info: `{ username, state, pin }` (built on tb2's username query) */
    getUsername: () => Promise<{
        username: any;
        state: any;
        pin: any;
    }>;
    /** same as `deleteUsername()` */
    removeUsername: () => Promise<any>;
    /** like `checkUsername`, with `{ available, suggestions, response }` as the result */
    checkUsernameAvailability: (username: string, options?: {
        includeSuggestions?: boolean;
    }) => Promise<{
        available: boolean;
        suggestions: any;
        response: any;
    }>;
    /** usernames of known contacts: `[{ jid, username }]` (like `fetchContactUsernames`, only with a username) */
    getUsernames: (...jids: (string | string[])[]) => Promise<{
        jid: any;
        username: any;
    }[]>;
    /** removes the username pin */
    removeUsernamePin: () => Promise<boolean>;
    /** the "About" text of a user: `{ jid, status, response }` */
    fetchAbout: (jid: string) => Promise<{
        jid: string;
        status: any;
        response: any;
    }>;
    /** sets the text status; `text: ''` / `null` clears it */
    updateTextStatus: (text: string | null, options?: {
        ephemeralDurationSec?: number;
        emoji?: string;
    }) => Promise<any>;
    fetchUserNotices: (since?: number) => Promise<{
        id: string | undefined;
        stage: string | undefined;
        t: string | undefined;
        version: string | undefined;
        type: string | undefined;
    }[]>;
    updateUserNoticeStage: (noticeId: string | number, stage: string | number) => Promise<void>;
    fetchOptOutList: (options?: {
        category?: string;
        dhash?: string;
    }) => Promise<{
        [key: string]: string;
    }[]>;
    updateOptOut: ({ jid, category, action, dhash, reason, entryPoint, signupId, duration }: {
        jid: string;
        category: string;
        action: string;
        dhash?: string;
        reason?: string;
        entryPoint?: string;
        signupId?: string;
        duration?: number | string | null;
    }) => Promise<void>;
    fetchPushSettings: () => Promise<{
        [key: string]: string;
    }>;
    /** link preview from the WhatsApp server (the same thing the app uses for channel posts) */
    fetchServerLinkPreview: (url: string) => Promise<any>;
    /** report a user / group / newsletter as spam: `{ jid, flow, reported, node }` */
    reportSpam: (jid: string, options?: SpamReportOptions) => Promise<{
        jid: string | undefined;
        flow: string | undefined;
        reported: boolean;
        node: BinaryNode;
    }>;
    fetchProps: ({ full }?: {
        full?: boolean;
    }) => Promise<Record<string, string>>;
    /** the server AB props (cached; `refresh: true` fetches the full list again) */
    getServerProps: ({ refresh }?: {
        refresh?: boolean;
    }) => Promise<Record<string, string>>;
    /** quick health report of a number: registered?, business?, about, profile photo and the new-chat cap of YOUR account */
    checkAccountHealth: (jid: string) => Promise<AccountHealth>;
};
//# sourceMappingURL=chats-extras.d.ts.map