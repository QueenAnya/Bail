import { type DatabaseAuthState } from './auth-store.js';
export interface TursoAuthStateOptions {
    /** local database file, e.g. `./auth.db` — turned into `file:./auth.db` */
    path?: string;
    /** `libsql://…turso.io` for cloud, or `file:…` / `http(s)://…` — wins over `path` when both are given */
    url?: string;
    /** Turso database token; only needed for a remote database */
    authToken?: string;
    /** an existing `@libsql/client` client (it is NOT closed by `close()`) */
    client?: any;
    /** session name, lets several bots share one database, default `default` */
    session?: string;
    /** table name, default `baileys_auth` */
    table?: string;
}
/** `./auth.db` → `file:./auth.db`; anything already carrying a scheme is left alone */
export declare const toLibsqlUrl: (opts: Pick<TursoAuthStateOptions, "path" | "url">) => string;
export declare function useTursoAuthState(
/** `(url)`, `(url, token, session)`, `({ url, authToken, session })`, `({ path })`. */
a?: string | TursoAuthStateOptions, b?: string | TursoAuthStateOptions, c?: string): Promise<DatabaseAuthState>;
//# sourceMappingURL=use-turso-auth-state.d.ts.map