/**
 * Socket layer for everything under `src/Extras`: takes the finished tb2 socket and adds the ported methods on top.
 * It is the last layer in `Socket/index.ts`, so the ported methods can use anything the socket already offers.
 *
 * It also wraps `sendMessage`, so the content keys ported from elaina-baileys work in the usual call:
 *   question, questionReply, comment, statusMention, statusQuoted, ...  (see modern-messages.ts)
 *   music, splitPayment, splitPaymentUpdate, paymentReminder            (see payment-messages.ts / status-stickers.ts)
 *   newsletterStatus, statusAudience, addYours, messageAssociation      (decorate other content)
 */
import './MessageBuilder/attach-static-helpers.js';
import { AIRich, AIRichCarousel, Button, ButtonV2, MB } from './MessageBuilder/index.js';
import { makeChatsExtras } from './chats-extras.js';
import { makeMessagesExtras, type MessagesExtrasConfig, type MessagesExtrasSocket } from './messages-extras.js';
import { makeNewsletterExtras } from './newsletter-extras.js';
import { type NewsletterStatusSocket } from './newsletter-status.js';
import { makeNewsletterStatusExtras } from './newsletter-status-socket.js';
type BaseSocket = Parameters<typeof makeChatsExtras>[0] & MessagesExtrasSocket & NewsletterStatusSocket & {
    sendMessage: (jid: string, content: any, options?: any) => Promise<any>;
};
type PortedSocket<T extends BaseSocket> = T & ReturnType<typeof makeNewsletterExtras> & ReturnType<typeof makeChatsExtras> & ReturnType<typeof makeMessagesExtras> & ReturnType<typeof makeNewsletterStatusExtras> & {
    sendMessage: T['sendMessage'];
    /** MessageBuilder bound to this socket: `new sock.MB.AIRich()`, `sock.MB.sendA2UI(jid, ...)`, ... (no socket argument). */
    MB: BoundMessageBuilder;
    /** AIRich class bound to this socket: `new sock.AIRich()` (no socket argument). */
    AIRich: BoundBuilderClass<typeof AIRich>;
};
/**
 * `MB` bound to one socket: the builder classes get the socket as their first constructor argument and the
 * `send*` helpers (`sendA2UI`, `sendAIRichMessage`, ...) as their first call argument, so none of them need it.
 * Everything else on `MB` is passed through unchanged.
 */
export declare const bindMessageBuilder: (sock: object) => BoundMessageBuilder;
/** A builder class whose constructor no longer takes the socket as first argument. */
type BoundBuilderClass<C extends abstract new (client: any, ...args: any[]) => any> = (new (...args: ConstructorParameters<C> extends [any, ...infer Rest] ? Rest : never) => InstanceType<C>) & Omit<C, 'prototype'>;
type BoundMessageBuilder = Omit<typeof MB, 'AIRich' | 'Button' | 'ButtonV2' | 'Carousel' | 'AIRichCarousel'> & {
    AIRich: BoundBuilderClass<typeof AIRich>;
    Button: BoundBuilderClass<typeof Button>;
    ButtonV2: BoundBuilderClass<typeof ButtonV2>;
    Carousel: BoundBuilderClass<typeof AIRichCarousel>;
    AIRichCarousel: BoundBuilderClass<typeof AIRichCarousel>;
    [name: string]: any;
};
export declare const preparePortedMessageContent: (content: any) => any;
export declare const makePortedSocket: <T extends BaseSocket>(sock: T, config?: MessagesExtrasConfig) => PortedSocket<T>;
export {};
//# sourceMappingURL=socket.d.ts.map