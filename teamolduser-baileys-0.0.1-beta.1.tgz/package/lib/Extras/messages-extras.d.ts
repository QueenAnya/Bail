import { proto } from '../../WAProto/index.js';
import type { BinaryNode } from '../WABinary/index.js';
export declare const AssociationType: typeof proto.MessageAssociation.AssociationType;
/**
 * Anya-specific alias for `senderKeyResetSummary` (Elaina's name, which is the canonical export in
 * `./sender-key-memory`). This used to be a second, separately ported copy of the same logic; there is
 * now one implementation and both names point at it.
 */
export declare const senderKeyMemoryResetSummary: (stored: Record<string, any> | undefined, jid: string) => {
    jid: string;
    cleared: number;
    devices: string[];
};
export interface MessagesExtrasSocket {
    query: (node: BinaryNode) => Promise<BinaryNode>;
    generateMessageTag: () => string;
    logger: any;
    authState: {
        creds: {
            me?: {
                id: string;
            };
        };
        keys: {
            get: (type: any, ids: string[]) => any;
            set: (data: any) => any;
        };
    };
    relayMessage: (jid: string, message: any, options: any) => Promise<string>;
    waUploadToServer: any;
    upsertMessage: (message: any, type: 'append' | 'notify') => Promise<void>;
    messageMutex: {
        mutex: <T>(fn: () => Promise<T> | T) => Promise<T>;
    };
    updateMemberLabel: (jid: string, memberLabel: string) => Promise<any>;
}
export interface MessagesExtrasConfig {
    mediaCache?: any;
    options?: any;
    emitOwnEvents?: boolean;
}
type SendOptions = Record<string, any> & {
    useCachedGroupMetadata?: boolean;
    statusJidList?: string[];
    additionalAttributes?: Record<string, string>;
    additionalNodes?: BinaryNode[];
};
export declare const makeMessagesExtras: (sock: MessagesExtrasSocket, config?: MessagesExtrasConfig) => {
    /**
     * Sends a photo / video the way WhatsApp's "HD" quality does: a normal (SD) message followed by an HD child that is
     * linked to it. `content.hd` can be a separate HD source; by default the same media is sent as the HD child.
     *   sock.sendHD(jid, { image: buffer, caption: 'hi' })
     *   sock.sendHD(jid, { video: { url }, hd: { url: hdUrl } })
     */
    sendHD: (jid: string, content: Record<string, any>, options?: SendOptions) => Promise<any>;
    /** motion photo: `{ image, video, caption? }` - an image with a paired short video. */
    sendImgVid: (jid: string, content: {
        image: any;
        video: any;
        caption?: string;
    }, options?: SendOptions) => Promise<any>;
    /** removes your member label in a group (same as `updateMemberLabel(jid, '')`) */
    removeMemberLabel: (jid: string) => Promise<any>;
    /**
     * Forgets which devices already got your sender key in a group, so the next send redistributes it
     * (useful when members cannot decrypt your group messages). Returns `{ jid, cleared, devices }`.
     */
    resetGroupSenderKey: (jid: string) => Promise<{
        jid: string;
        cleared: number;
        devices: string[];
    }>;
    /** raw `w:g2` group IQ: `groupQuery(jid, 'get', [{ tag: 'query', attrs: { request: 'interactive' } }])` */
    groupQuery: (jid: string, type: "get" | "set", content: BinaryNode[]) => Promise<BinaryNode>;
    /** raw `w:g2` community IQ (same wire format as `groupQuery`) */
    communityQuery: (jid: string, type: "get" | "set", content: BinaryNode[]) => Promise<BinaryNode>;
    /** raw WMex (GraphQL) query: `executeWMexQuery(variables, queryId, dataPath)` */
    executeWMexQuery: <T = any>(variables: Record<string, unknown>, queryId: string, dataPath: string) => Promise<T>;
};
export {};
//# sourceMappingURL=messages-extras.d.ts.map