/**
 * Ported from @rexxhayanasi/elaina-baileys 1.4.x (MIT) - Utils/group-metadata-cache.js
 * Copied as-is (JS -> TS); only import paths and parameter types were adapted for tb2.
 * Re-checked against elaina-baileys 1.4.7: the exported surface matches; see PORTED_FROM below.
 */
export declare const GROUP_ADDRESSING_MODES: readonly string[];
type GroupMetadataLike = {
    participants?: unknown;
    addressingMode?: string;
} | null | undefined;
export declare const isUsableGroupMetadata: (metadata: GroupMetadataLike) => boolean;
export declare const describeUnusableGroupMetadata: (metadata: GroupMetadataLike) => string;
export {};
//# sourceMappingURL=group-metadata-cache.d.ts.map