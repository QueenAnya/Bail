export declare const loadSharp: () => Promise<any> | undefined;
export declare const loadFfmpeg: () => Promise<any> | undefined;
export declare const hasOptionalMedia: (name: string) => Promise<boolean>;
//# sourceMappingURL=optional-media.d.ts.map