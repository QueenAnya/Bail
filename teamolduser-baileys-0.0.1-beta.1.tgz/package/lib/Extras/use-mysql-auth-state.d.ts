import { type DatabaseAuthState } from './auth-store.js';
export interface MySQLAuthStateOptions {
    /** an existing `mysql2/promise` pool (it is NOT closed by `close()`) */
    pool?: any;
    /** connection URI, used when no pool is given */
    uri?: string;
    /** Alias for `uri` — every adapter accepts the same key. */
    url?: string;
    /** `mysql2` pool config, used when no pool is given */
    config?: any;
    /** table name (plain identifier), default `baileys_auth` */
    table?: string;
    /** session name, lets several bots share one table, default `default` */
    session?: string;
}
export declare function useMySQLAuthState(
/** `(uri)`, `(uri, table, session)`, `({ uri, table, session })`, `({ pool })`. */
a?: string | MySQLAuthStateOptions, b?: string | MySQLAuthStateOptions, c?: string): Promise<DatabaseAuthState>;
//# sourceMappingURL=use-mysql-auth-state.d.ts.map