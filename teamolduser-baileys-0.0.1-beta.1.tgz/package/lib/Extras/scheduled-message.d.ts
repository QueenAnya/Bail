import { proto } from '../../WAProto/index.js';
import type { BinaryNode } from '../WABinary/index.js';
export declare const SCHEDULED_MSG_META_TYPE = "scheduled_message";
export declare const SCHEDULED_MSG_MAX_PER_CHAT = 30;
export declare const SCHEDULED_MSG_MAX_MEDIA = 1;
export declare const SCHEDULED_MSG_RESOURCE_LIMIT_NACK_CODE = 419;
export declare const SCHEDULED_MSG_REVEAL_KEY_BYTES = 32;
export declare const SCHEDULED_MSG_REVEAL_KEY_IV_BYTES = 12;
export declare const SCHEDULED_MSG_REVEAL_KEY_RETENTION_DAYS = 30;
export declare const SCHEDULED_MSG_TAG_BYTES = 16;
export declare const SCHEDULED_MSG_WINDOW: Readonly<{
    chat: {
        minSeconds: number;
        maxSeconds: number;
    };
    newsletter: {
        minSeconds: number;
        maxSeconds: number;
    };
}>;
export declare const generateRevealKey: () => NonSharedBuffer;
export declare const generateRevealKeyId: () => `${string}-${string}-${string}-${string}-${string}`;
export declare const encryptWithRevealKey: (plaintext: Uint8Array, revealKey: Uint8Array) => {
    encIv: NonSharedBuffer;
    encPayload: Buffer<ArrayBuffer>;
};
export declare const decryptWithRevealKey: (encPayload: Uint8Array, encIv: Uint8Array, revealKey: Uint8Array) => Buffer<ArrayBuffer>;
export declare const buildConditionalRevealMessage: ({ encPayload, encIv, revealKeyId }: {
    encPayload: Uint8Array;
    encIv: Uint8Array;
    revealKeyId: string;
}) => {
    conditionalRevealMessage: {
        conditionalRevealMessageType: any;
        encPayload: Buffer<ArrayBuffer>;
        encIv: Buffer<ArrayBuffer>;
        revealKeyId: string;
    };
};
/** Encrypts a `proto.Message` object; send `.message` and keep `revealKey` / `revealKeyId` for the `<meta>` node. */
export declare const encodeScheduledMessage: (message: Record<string, any>, revealKey?: Uint8Array) => {
    revealKey: Uint8Array<ArrayBufferLike>;
    revealKeyId: `${string}-${string}-${string}-${string}-${string}`;
    encIv: NonSharedBuffer;
    encPayload: Buffer<ArrayBuffer>;
    message: {
        conditionalRevealMessage: {
            conditionalRevealMessageType: any;
            encPayload: Buffer<ArrayBuffer>;
            encIv: Buffer<ArrayBuffer>;
            revealKeyId: string;
        };
    };
};
export declare const decodeScheduledMessage: (conditionalRevealMessage: any, revealKey: Uint8Array) => proto.Message & proto.Message.$Shape;
export declare const buildScheduledMsgMetaNode: ({ kind, scheduledTimestampS, revealKeyId, revealKey }: {
    kind?: "schedule" | "unschedule";
    scheduledTimestampS?: number;
    revealKeyId: string;
    revealKey?: Uint8Array;
}) => BinaryNode;
export declare const buildUnscheduleProtocolMessage: (key: Record<string, any>) => {
    protocolMessage: {
        key: Record<string, any>;
        type: proto.Message.ProtocolMessage.Type;
    };
};
export declare const isScheduledTimeValid: (scheduledTimestampS: number, nowSeconds?: number, window?: {
    minSeconds: number;
    maxSeconds: number;
}) => boolean;
//# sourceMappingURL=scheduled-message.d.ts.map