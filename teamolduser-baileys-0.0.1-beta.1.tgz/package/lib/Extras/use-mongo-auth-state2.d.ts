import { type DatabaseAuthState } from './auth-store.js';
export interface MongoAuthState2Options {
    /** Existing MongoDB collection (native driver or a compatible collection implementation). */
    collection?: any;
    /** Existing MongoDB Db instance. The supplied db is never closed by this function. */
    db?: any;
    /** Existing MongoClient instance. It is never closed by this function. */
    client?: any;
    /** MongoDB connection URI. A client is created and owned by this function when used. */
    uri?: string;
    /** Alias for `uri` — every adapter accepts the same key. */
    url?: string;
    /** Options forwarded to `new MongoClient(uri, clientOptions)`. */
    clientOptions?: Record<string, unknown>;
    /** Database name used with `uri` or `client`; defaults to the driver's default database. */
    dbName?: string;
    /** Collection name when `collection` is not supplied. Defaults to `baileys_auth`. */
    collectionName?: string;
    /** Session namespace, allowing multiple bots to share one collection. Defaults to `default`. */
    session?: string;
}
/**
 * MongoDB-backed auth state with session isolation, batch key operations, `clearAuth()` and `close()`.
 * Existing `useMongoAuthState` / `useMongoFileAuthState` functions are intentionally untouched.
 */
export declare function useMongoAuthState2(
/** `(uri)`, `(uri, collectionName, session)`, `({ uri, collectionName, session })`, `({ collection })`. */
a?: string | MongoAuthState2Options, b?: string | MongoAuthState2Options, c?: string): Promise<DatabaseAuthState>;
/** Elaina's export name for this adapter — see `useSqliteAuthState` for the naming rule. */
export declare const useMongoAuthState: typeof useMongoAuthState2;
//# sourceMappingURL=use-mongo-auth-state2.d.ts.map