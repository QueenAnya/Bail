/**
 * Ported from @rexxhayanasi/elaina-baileys 1.4.x (MIT) - MessageBuilder/extras.js
 * Copied as-is (JS -> TS, type-checking disabled); only import paths were adapted for tb2.
 * Re-checked against elaina-baileys 1.4.7: the exported surface matches; see PORTED_FROM below.
 */
export declare const AI_RICH_LAYOUTS: readonly string[];
export declare const AI_RICH_PRIMITIVES: readonly string[];
export declare const AI_RICH_PRIMITIVE_INTERFACE = "GenAIUXPrimitive";
export declare const AI_RICH_PRIMITIVES_WITHOUT_SCHEMA: readonly string[];
export declare const AI_RICH_ITEMS: readonly string[];
export declare const AI_RICH_HTML_PRIMITIVE = "GenAIaeacdsnwHtmlPrimitive";
export declare const AI_RICH_HTML_PRIMITIVE_CLASS = "FOAHtmlPrimitive";
export declare const AI_RICH_INLINE_ENTITIES: readonly string[];
export declare const AI_RICH_PRIMITIVES_WEB_RENDERED: readonly string[];
export declare const DividerType: Readonly<{
    DOT: "DOT";
    HORIZONTAL_LINE: "HORIZONTAL_LINE";
}>;
export declare const ImagineType: Readonly<{
    IMAGINE: "IMAGINE";
    ANIMATE: "ANIMATE";
    MEMU: "MEMU";
}>;
export declare const ImagineStatus: Readonly<{
    GENERATING: "GENERATING";
    READY: "READY";
    FAILED: "FAILED";
}>;
export declare const ThinkingIcon: Readonly<{
    THINKING: "THINKING";
    WEB_SEARCH: "WEB_SEARCH";
    META_SEARCH: "META_SEARCH";
}>;
export declare const TaskStatus: Readonly<{
    PENDING: "PENDING";
    RUNNING: "RUNNING";
    DONE: "DONE";
}>;
export declare const FooterActionType: Readonly<{
    OPEN_FULL_VIEW: "OPEN_FULL_VIEW";
    DOWNLOAD_MEDIA: "DOWNLOAD_MEDIA";
    GENERATE_IMAGE: "GENERATE_IMAGE";
    CANCEL_REASONING: "CANCEL_REASONING";
    UPGRADE_TO_SUBS: "UPGRADE_TO_SUBS";
    COPY_LINK: "COPY_LINK";
    REMIX_MEDIA: "REMIX_MEDIA";
    USE_TEMPLATE: "USE_TEMPLATE";
}>;
export declare const AddonActionType: Readonly<{
    COPY_TO_CLIPBOARD: "COPY_TO_CLIPBOARD";
    SEND_TO_CHAT: "SEND_TO_CHAT";
    FOLLOW_UP_PROMPT: "FOLLOW_UP_PROMPT";
}>;
export declare const dividerSection: ({ dividerType }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const spacerSection: ({ spacing }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const imageSection: (url: any, { fallbackUrl, previewUrl, previewFallbackUrl }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const taskSection: ({ taskId, title, subtitle, status }: {
    taskId: any;
    title?: string | undefined;
    subtitle?: string | undefined;
    status?: "PENDING" | undefined;
}) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const latexSection: (expression: any, { image, width, height, fontHeight, padding }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const thinkingSection: (title: any, { icon, inProgress, metaSearchApps, thoughtDurationSec }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const progressSection: (title: any, { icon, inProgress, metaSearchApps, thoughtDurationSec }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const lockHeight: (height: any) => string;
export declare const HTML_APP_BRIDGE = "AndroidBridge";
export declare const dataUri: (bytes: any, mimetype: any) => string;
export declare const htmlMedia: (bytes: any, { mimetype, tag, label, poster, id, attributes }?: {
    tag?: string | undefined;
    label?: string | undefined;
    id?: string | undefined;
    attributes?: string | undefined;
}) => string;
export declare const scrollControls: ({ target, step, holdMs, size, side, inset }?: any) => string;
export declare const autoHeight: ({ min, max, settleMs, maxReports }?: any) => string;
export declare const htmlSection: (html: any, { trustedSources, height, typename }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const sendHtmlApp: (sock: any, jid: any, html: any, { title, label, trustedSources, height, autoHeight: auto, scrollButtons, typename, id, bypassDownload, guard, ...options }?: any) => Promise<import("../../index.js").WAMessage>;
export declare const HTML_MIME_TYPE = "text/html";
export declare const sendHtmlDocument: (sock: any, jid: any, html: any, { fileName, caption, ...options }?: any) => Promise<any>;
export declare const fileSection: (url: any, { title, fileExtension, fileLength, pageCount, previewImage }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const fileLinkSection: (url: any, { title, fileExtension, fileLength, pageCount, previewImage }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const botMediaMetadata: (documentMessage: any) => any;
export declare const prepareFileArtifact: (sock: any, content: any, { mimetype, fileName, title, id }?: any) => Promise<{
    mediaId: any;
    media: any;
    documentMessage: import("../../index.js").proto.Message.DocumentMessage.$Properties | null | undefined;
    section: {
        view_model: {
            [x: number]: any;
            __typename: string;
        };
        __typename: string;
    };
    mediaDetails: {
        id: any;
        previewMedia: any;
        highResMedia: any;
    };
}>;
export declare const sendHtmlArtifact: (sock: any, jid: any, html: any, { fileName, title, label, id, bypassDownload, ...options }?: any) => Promise<{
    message: import("../../index.js").WAMessage;
    mediaId: any;
}>;
export declare const SourceProvider: Readonly<{
    UNKNOWN: 0;
    BING: 1;
    GOOGLE: 2;
    SUPPORT: 3;
    OTHER: 4;
}>;
export declare const botSourcesMetadata: (sources: any) => {
    sources: any[];
};
export declare const EMBEDDED_SCREEN_PRESENTATION: Readonly<{
    HALF_HEIGHT: "HALF_HEIGHT";
    FULL_HEIGHT: "FULL_HEIGHT";
}>;
export declare const EMBEDDED_SCREEN_TYPENAME = "FOAUnifiedResponseEmbeddedScreen";
export declare const EMBEDDED_SCREEN_TABBED_TYPENAME = "FOAEmbeddedScreenContentTabbed";
export declare const EMBEDDED_SCREEN_SINGLE_TYPENAME = "FOAEmbeddedSingleScreen";
export declare const EMBEDDED_SCREEN_CONTEXTUAL_TYPENAME = "GenAIEmbeddedContextualScreenContent";
export declare const EMBEDDED_SCREEN_TAB_TYPENAME = "FOAUnifiedResponseTab";
export declare const AI_RICH_SECTION_TYPENAME: string;
export declare const AI_RICH_UNIFIED_RESPONSE_TYPENAME: string;
export declare const AI_RICH_UNIFIED_RESPONSE_TYPENAME_APP = "GenAIUnifiedResponse";
export declare const AI_RICH_NESTED_UNIFIED_RESPONSE_TYPENAME = "GenAINestedUnifiedResponse";
export declare const AI_RICH_NODES: readonly string[];
export declare const embeddedTab: ({ id, header, tabHeader, sections, typename }?: any) => any;
export declare const embeddedTabbedContent: (tabs: any, { typename }?: any) => {
    __typename: string | undefined;
    tabs: any[];
};
export declare const AI_RICH_RESPONSE_KEYS: readonly string[];
export declare const embeddedScreen: ({ id, title, content, tabs, tabsTypename, typename, header, body, artifacts, steps, stepEntries, sources, pollId }?: any) => any;
export declare const readEmbeddedTabs: (screen: any) => any[];
export declare const readEmbeddedSections: (screen: any) => any[];
export declare const footerActionSection: (actionType: any, { buttonText, url }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const BLOKS_A2UI_TYPE = "im_a2ui";
export declare const BLOKS_A2UI_REPLY_ACTION = "a2ui_reply_action";
export declare const BLOKS_A2UI_SUPPORTED_ELEMENTS: readonly string[];
export declare const bloksSection: (type: any, data: any, { uuid, initialResponse, versioningId }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const bloksWidget: ({ type, data, uuid, fallback }?: any) => {
    type: string;
    data: string;
    uuid: any;
    fallback: string;
};
export declare const A2UI_VERSION = "v0.9";
export declare const A2UI_BASIC_CATALOG = "https://a2ui.org/specification/v0_9/catalogs/basic/catalog.json";
export declare const A2UI_ROOT_ID = "root";
export declare const a2uiText: (id: any, text: any, { variant }?: any) => any;
export declare const a2uiImage: (id: any, url: any, { variant, fit }?: any) => any;
export declare const a2uiColumn: (id: any, children?: never[]) => any;
export declare const a2uiRow: (id: any, children?: never[]) => any;
export declare const a2uiCard: (id: any, child: any) => any;
export declare const a2uiInfoCard: (element?: {}) => {
    type: any;
};
export declare const a2uiListCard: (element?: {}) => {
    type: any;
};
export declare const a2uiFallback: (components: any) => string;
export declare const a2uiSurface: (components: any, { surfaceId, root, catalogId, sendDataModel, version, type, title }?: any) => any;
export declare const a2uiWidget: (components: any, { uuid, surfaceId, root, catalogId, sendDataModel, version, type, title, fallback, data }?: any) => {
    type: string;
    data: string;
    uuid: any;
    fallback: string;
};
export declare const sendA2UI: (sock: any, jid: any, components: any, { buttons, contextInfo, messageId, additionalNodes, ...options }?: any) => Promise<import("../../index.js").WAMessage>;
export declare const buildA2UISection: (components: any, { uuid, surfaceId, root, catalogId, sendDataModel, version, type, title, data, initialResponse, versioningId }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const sendA2UIBloks: (sock: any, jid: any, components: any, { uuid, surfaceId, root, catalogId, sendDataModel, version, type, title, data, initialResponse, versioningId, ...options }?: any) => Promise<import("../../index.js").WAMessage>;
export declare const AI_RICH_SUBMESSAGE_TEXT = 2;
export declare const AI_RICH_SUBMESSAGE_INLINE_IMAGE = 3;
export declare const AI_RICH_SUBMESSAGE_TABLE = 4;
export declare const AI_RICH_SUBMESSAGE_CONTENT_ITEMS = 9;
export declare const AI_RICH_SUBMESSAGE_KINDS: readonly string[];
export declare const aiRichSubmessage: (kind: any, payload?: {}) => any;
export declare const aiRichText: (text: any) => any;
export declare const aiRichInlineImage: (image: any) => any;
export declare const aiRichTable: (table: any) => any;
export declare const aiRichContentItems: (content: any) => any;
export declare const AIRichMessage: {
    SUBMESSAGE_KINDS: readonly string[];
    text: (text: any) => any;
    inlineImage: (image: any) => any;
    table: (table: any) => any;
    contentItems: (content: any) => any;
    submessage: (kind: any, payload?: {}) => any;
    textSection: (text: any) => {
        view_model: {
            [x: number]: any;
            __typename: string;
        };
        __typename: string;
    };
    nativeFlowSection: (name: any, params: any, { uuid, initialResponse, versioningId }?: any) => {
        view_model: {
            [x: number]: any;
            __typename: string;
        };
        __typename: string;
    };
};
export declare const sendAIRichMessage: (sock: any, jid: any, { sections, text, nativeFlow, submessages, forwardWrapper, ...options }?: any) => Promise<import("../../index.js").WAMessage>;
export declare const sendBloksWidget: (sock: any, jid: any, { type, data, uuid, fallback, body, contextInfo, messageId, additionalNodes, ...options }?: any) => Promise<import("../../index.js").WAMessage>;
export declare const decodeBloksWidget: (msg: any) => {
    type: any;
    uuid: any;
    fallback: any;
    data: any;
    params: any;
} | null;
export declare const collectTypenames: (root: any, { limit }?: any) => unknown[];
export declare const decodeAIRich: (msg: any) => {
    responseId: any;
    layouts: any;
    typenames: unknown[];
    footerTypenames: unknown[];
    allTypenames: unknown[];
    sections: any;
    footerSections: any;
    embeddedScreens: any;
    embeddedTabs: any;
    embeddedSections: any;
    submessages: any;
    unified: any;
} | null;
export declare const readRichMessage: (msg: any) => any;
//# sourceMappingURL=extras.d.ts.map