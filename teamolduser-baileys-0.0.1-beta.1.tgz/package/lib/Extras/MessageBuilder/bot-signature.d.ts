/**
 * Ported from @rexxhayanasi/elaina-baileys 1.4.x (MIT) - MessageBuilder/bot-signature.js
 * Copied as-is (JS -> TS, type-checking disabled); only import paths were adapted for tb2.
 * Re-checked against elaina-baileys 1.4.7: the exported surface matches; see PORTED_FROM below.
 */
import { X509Certificate } from 'crypto';
export declare const BOT_SIGNATURE_VERSION = "1";
export declare const BOT_SIGNATURE_USE_CASE_WA_BOT_MSG = 1;
export declare const BOT_SIGNATURE_ROOT_VERSION = "2025-10";
export declare const BOT_SIGNATURE_ROOT_CERTIFICATE = "-----BEGIN CERTIFICATE-----\nMIIC7TCCApOgAwIBAgIUAtu5QuxmVhfGT8LPkjfm40mSl0AwCgYIKoZIzj0EAwIw\ndzEgMB4GA1UEAwwXTWV0YSBXQSBGZWF0dXJlIFJvb3QgQ0ExCzAJBgNVBAYTAlVT\nMRMwEQYDVQQIDApDYWxpZm9ybmlhMRMwEQYDVQQHDApNZW5sbyBQYXJrMRwwGgYD\nVQQKDBNNZXRhIFBsYXRmb3JtcyBJbmMuMCAXDTI1MDkwNDE3MzEyNFoYDzIwNjUw\nOTA0MTczMTI0WjB3MSAwHgYDVQQDDBdNZXRhIFdBIEZlYXR1cmUgUm9vdCBDQTEL\nMAkGA1UEBhMCVVMxEzARBgNVBAgMCkNhbGlmb3JuaWExEzARBgNVBAcMCk1lbmxv\nIFBhcmsxHDAaBgNVBAoME01ldGEgUGxhdGZvcm1zIEluYy4wWTATBgcqhkjOPQIB\nBggqhkjOPQMBBwNCAAT60blw90ebreMkw8+Wpcs0ETAkr1VQjoZoyi7PSSQbsoiP\nqYRnzfRrR+xiahaXbYU83qXiTHjVUiOU9wDxI83qo4H6MIH3MA8GA1UdEwEB/wQF\nMAMBAf8wHQYDVR0OBBYEFNO7KMTVSYUxkL6VS3LyWJw7m76zMIG0BgNVHSMEgaww\ngamAFNO7KMTVSYUxkL6VS3LyWJw7m76zoXukeTB3MSAwHgYDVQQDDBdNZXRhIFdB\nIEZlYXR1cmUgUm9vdCBDQTELMAkGA1UEBhMCVVMxEzARBgNVBAgMCkNhbGlmb3Ju\naWExEzARBgNVBAcMCk1lbmxvIFBhcmsxHDAaBgNVBAoME01ldGEgUGxhdGZvcm1z\nIEluYy6CFALbuULsZlYXxk/Cz5I35uNJkpdAMA4GA1UdDwEB/wQEAwIBhjAKBggq\nhkjOPQQDAgNIADBFAiAINhjk9DbP416vx/WjqdUfexgic08aQsxnpDDsNE5M0gIh\nANorq7KwCQVMtS2or5uKJAQsx1FxCHyDafq2GCk9t0AN\n-----END CERTIFICATE-----";
export declare const loadBotSignatureRoot: () => X509Certificate;
export declare const constructSignaturePayload: ({ botFbid, messageDigest, version }: {
    botFbid: string;
    messageDigest: string | Uint8Array;
    version?: string;
}) => Buffer<ArrayBuffer>;
export declare const isParsableCertificateChain: (chain: any) => boolean;
export interface BotSignatureProof {
    version?: number | string;
    signature?: any;
    certificateChain?: any[];
}
export interface VerifyBotSignatureInput {
    botJid?: string;
    unifiedResponseBytes?: any;
    proof?: BotSignatureProof;
    at?: number;
    root?: X509Certificate;
}
export declare const verifyBotSignature: ({ botJid, unifiedResponseBytes, proof, at, root }?: VerifyBotSignatureInput) => {
    status: "failed";
    reason: string;
} | {
    status: string;
};
//# sourceMappingURL=bot-signature.d.ts.map