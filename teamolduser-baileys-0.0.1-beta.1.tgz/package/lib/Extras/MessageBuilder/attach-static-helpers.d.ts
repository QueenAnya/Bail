export {};
//# sourceMappingURL=attach-static-helpers.d.ts.map