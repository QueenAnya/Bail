/**
 * Ported from @rexxhayanasi/elaina-baileys 1.4.x (MIT) - MessageBuilder/metaai.js
 * Copied as-is (JS -> TS, type-checking disabled); only import paths were adapted for tb2.
 * Re-checked against elaina-baileys 1.4.7: the exported surface matches; see PORTED_FROM below.
 */
export declare const MapQueryStatus: Readonly<{
    FETCHING: "FETCHING";
    FETCHED: "FETCHED";
    FAILED: "FAILED";
}>;
export declare const MapItemMarkerType: Readonly<{
    PIN: "PIN";
    RADIUS: "RADIUS";
}>;
export declare const PlaceDetailsItemType: Readonly<{
    PLACE: "PLACE";
    MARKETPLACE_LISTING: "MARKETPLACE_LISTING";
}>;
export declare const PlaceOpeningStatus: Readonly<{
    OPEN: "OPEN";
    CLOSED: "CLOSED";
}>;
export declare const PlacePriceLevel: Readonly<{
    CHEAP: "CHEAP";
    MODERATE: "MODERATE";
    EXPENSIVE: "EXPENSIVE";
    SPLURGE: "SPLURGE";
}>;
export declare const ClippyArtifactType: Readonly<{
    MINI_APP: "MINI_APP";
    STATIC_HTML: "STATIC_HTML";
}>;
export declare const SportsLeague: Readonly<{
    NFL: "NFL";
    EURO: "EURO";
    WORLD_CUP: "WORLD_CUP";
}>;
export declare const SportsGameStatus: Readonly<{
    SCHEDULED: "SCHEDULED";
    LIVE: "LIVE";
    FINAL: "FINAL";
}>;
export declare const SportsSeasonType: Readonly<{
    PRESEASON: "PRESEASON";
    REGULAR: "REGULAR";
    POSTSEASON: "POSTSEASON";
}>;
export declare const CompactEntityType: Readonly<{
    PERSON: "PERSON";
    PAGE: "PAGE";
    GROUP: "GROUP";
    INSTAGRAM_ACCOUNT: "INSTAGRAM_ACCOUNT";
    CALENDAR_EVENT: "CALENDAR_EVENT";
}>;
export declare const CompactEntityActionType: Readonly<{
    FOLLOW: "FOLLOW";
    UNFOLLOW: "UNFOLLOW";
    JOIN: "JOIN";
    LEAVE: "LEAVE";
    MESSAGE: "MESSAGE";
    VIEW_DETAILS: "VIEW_DETAILS";
}>;
export declare const ActionListRowType: Readonly<{
    ACTION: "ACTION";
    NAVIGATION: "NAVIGATION";
}>;
export declare const SocialEntityItemType: Readonly<{
    FB_PROFILE: "FB_PROFILE";
    FB_PAGE: "FB_PAGE";
    FB_GROUP: "FB_GROUP";
    IG_PROFILE: "IG_PROFILE";
    THREADS_PROFILE: "THREADS_PROFILE";
}>;
export declare const SourceApp: Readonly<{
    FACEBOOK: "FACEBOOK";
    INSTAGRAM: "INSTAGRAM";
    THREADS: "THREADS";
}>;
export declare const PostType: Readonly<{
    PAGE_POST: "PAGE_POST";
    GROUP_POST: "GROUP_POST";
}>;
export declare const PostOrientation: Readonly<{
    PORTRAIT: "PORTRAIT";
    LANDSCAPE: "LANDSCAPE";
}>;
export declare const ProductSourceType: Readonly<{
    CATALOG: "CATALOG";
    MARKETPLACE: "MARKETPLACE";
}>;
export declare const SearchPlannerStepStatus: Readonly<{
    PLANNED: "PLANNED";
    IN_PROGRESS: "IN_PROGRESS";
    COMPLETED: "COMPLETED";
    STOPPED: "STOPPED";
}>;
export declare const OrchestratorSearchEngine: Readonly<{
    BING: "BING";
    BRAVE: "BRAVE";
    GOOGLE: "GOOGLE";
    HELP_CENTER: "HELP_CENTER";
    IN_HOUSE: "IN_HOUSE";
    KSS: "KSS";
    MASE: "MASE";
}>;
export declare const ProfessionalConsentStatus: Readonly<{
    ALLOWED: "ALLOWED";
    NEEDS_CONSENT: "NEEDS_CONSENT";
}>;
export declare const AccountLinkingIntegration: Readonly<{
    APPLE_HEALTH: "APPLE_HEALTH";
    GMAIL: "GMAIL";
    GOOGLE_CALENDAR: "GOOGLE_CALENDAR";
    GOOGLE_CONTACTS: "GOOGLE_CONTACTS";
    GOOGLE_DRIVE: "GOOGLE_DRIVE";
    GOOGLE_HEALTH_CONNECT: "GOOGLE_HEALTH_CONNECT";
    OUTLOOK_CALENDAR: "OUTLOOK_CALENDAR";
    OUTLOOK_CONTACTS: "OUTLOOK_CONTACTS";
    OUTLOOK_MAIL: "OUTLOOK_MAIL";
}>;
export declare const AccountLinkingStatus: Readonly<{
    INITIATED: "INITIATED";
    LINKED: "LINKED";
    UNLINKED: "UNLINKED";
}>;
export declare const CalendarEventOperation: Readonly<{
    CREATE: "CREATE";
    UPDATE: "UPDATE";
    DELETE: "DELETE";
}>;
export declare const CalendarEventState: Readonly<{
    PENDING: "PENDING";
    CONFIRMED: "CONFIRMED";
    CANCELLED: "CANCELLED";
}>;
export declare const WidgetCtaKind: Readonly<{
    CONFIRM: "CONFIRM";
    CANCEL: "CANCEL";
    OTHER: "OTHER";
}>;
export declare const WidgetCtaState: Readonly<{
    PENDING: "PENDING";
    CONFIRMED: "CONFIRMED";
    CANCELLED: "CANCELLED";
}>;
export declare const MultipleResponseLayoutType: Readonly<{
    IN_THREAD: "IN_THREAD";
    BOTTOM_SHEET: "BOTTOM_SHEET";
}>;
export declare const ThreadSurfingEntityType: Readonly<{
    CELEBRITY: "CELEBRITY";
    INFO_TERM: "INFO_TERM";
    MOVIE: "MOVIE";
    RESTAURANT: "RESTAURANT";
    SPORTS_TEAM: "SPORTS_TEAM";
    TV_SHOWS: "TV_SHOWS";
}>;
export declare const ThreadSurfingActionType: Readonly<{
    AI_LOOKUP: "AI_LOOKUP";
    CONTEXTUAL_MENU: "CONTEXTUAL_MENU";
}>;
export declare const MediaShape: Readonly<{
    CIRCLE: "CIRCLE";
    SQUARE: "SQUARE";
    VERTICAL: "VERTICAL";
}>;
export declare const MediaHorizontalAlignment: Readonly<{
    START: "START";
    END: "END";
}>;
export declare const MediaVerticalAlignment: Readonly<{
    TOP: "TOP";
    CENTER: "CENTER";
}>;
export declare const AddonActionAlignment: Readonly<{
    START: "START";
    END: "END";
}>;
export declare const ImageAssetQueryStatus: Readonly<{
    FETCHING: "FETCHING";
    FETCHED: "FETCHED";
    FAILED: "FAILED";
}>;
export declare const CodeBlockType: Readonly<{
    DEFAULT: "DEFAULT";
    COMMENT: "COMMENT";
    KEYWORD: "KEYWORD";
    METHOD: "METHOD";
    NUMBER: "NUMBER";
    STR: "STR";
}>;
export declare const FollowUpSuggestionCategory: Readonly<{
    ADD: "ADD";
    ANIMATE: "ANIMATE";
    FRAME: "FRAME";
    LIGHT: "LIGHT";
    OTHER: "OTHER";
    RETOUCH: "RETOUCH";
    SCENE: "SCENE";
    STYLE: "STYLE";
}>;
export declare const InformTreatmentRenderingType: Readonly<{
    GEOBLOCK: "GEOBLOCK";
    MEDIA_LABEL: "MEDIA_LABEL";
    POST_COVER: "POST_COVER";
    POST_LABEL: "POST_LABEL";
    WARNING_SCREENS: "WARNING_SCREENS";
}>;
export declare const UnifiedResponseSectionType: Readonly<{
    REASONING: "REASONING";
    RESPONDING: "RESPONDING";
}>;
export declare const UnifiedResponseMessageGroupKind: Readonly<{
    COMMENTARY: "COMMENTARY";
    PRIMARY_RESPONSE: "PRIMARY_RESPONSE";
}>;
export declare const customSection: (typename: any, fields?: {}, { layout }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const placeItem: ({ id, name, description, imageUrl, itemType, categoryId, categoryName, priceLevel, openingStatus, openingHours, rating, latitude, longitude, streetAddress, street, locality, region, country, postalCode, timezone, marketplace }?: any) => any;
export declare const mapSection: ({ items, motivation, staticMapUrl, staticMapDarkUrl, queryStatus }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const locationPermissionSection: (placeholder?: string) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const timestampPlaceholderSection: (placeholder?: string) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const sportsSection: ({ gameId, league, status, statusDetail, startTime, venue, group, groupName, homeTeam, awayTeam, homeScore, awayScore, homeRecord, awayRecord, seasonType, week, contentTypename }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const videoSection: ({ postId, title, url: reelsUrl, thumbnailUrl, creator, avatarUrl, contentHash, likes, comments, shares, isVerified, sourceApp, progressiveUrls, dashManifests }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const reminderSection: ({ reminderId, title, triggerType, triggerTime, createTime, isDeleted, thumbnailUrl, fullSizeUrl, mediaKey }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const commentSection: ({ text, url: commentUrl, actorName, profileImage, subtitle, likes, replies, isVerified }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const compactEntitySection: ({ title, subtitle, secondarySubtitle, image, entityId, entityUrl, entityType, actionType, isVerified }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const actionListRow: ({ title, subtitle, action, icon, url: rowUrl, rowType }?: any) => any;
export declare const actionListSection: (rows?: never[]) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const plannerStep: ({ title, instruction, status }?: any) => any;
export declare const searchPlannerSection: (options?: {}) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const searchResultV2Section: (options?: {}) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const plannerSnippetSection: ({ header, currentStep, totalSteps, status }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const chainOfThoughtSection: ({ header, subtitle, plannerState, imageArtifacts, text }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const searchAdSection: ({ storyId, actorName, actorImageUrl, imageUrl, message }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const transparencySignal: ({ id, signalType, value, memory }?: any) => any;
export declare const transparencySection: ({ annotation, signals, responseId }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const professionalConsentSection: ({ title, body, status, providerLabel, providerIconUrl, ctaLabel, allowedLabel, allowedCtaLabel, allowedProviderLabel, allowedDescription, description, primaryLabel, secondaryLabel, subtitle, originalPrompt, learnMoreLabel, learnMoreUrl }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const accountLinkingApp: ({ label, integrationFbid, integrationSlug, iconUrl }?: any) => any;
export declare const accountLinkingSection: ({ title, subtitle, imageUrl, ctaLabel, ctaUrl, originalPrompt, integrationType, integrationStatus, integrationId, apps }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const calendarEvent: ({ title, startTime, endTime, location, description, recurrenceText, deeplink, attendees }?: any) => any;
export declare const calendarWidgetSection: ({ title, iconUrls, sections, ctas, toast }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const chainingSuggestionSection: ({ promptText, title, imageUri, externalConversationId, topic, cardId }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const mediaItem: ({ previewUrl, fullUrl, darkPreviewUrl, darkFullUrl, source, contentHash, assetQueryStatus, followUpPills }?: any) => any;
export declare const mediaGridSection: (items?: never[]) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const contextualSourcesSection: (sources?: never[]) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const threadSurfingItem: ({ entity, entityType, prompts }?: any) => any;
export declare const socialEntityItem: ({ entityId, name, fullName, pictureUrl, entityUrl, entityType, isVerified }?: any) => any;
export declare const placeEntityItem: ({ placeId, name, imageUrl, motivation }?: any) => any;
export declare const productEntityItem: ({ productId, title, productUrl, imageUrl, additionalImages, price, salePrice, brand, sourceType, isUnavailable, adTrackingCode }?: any) => any;
export declare const sideBySideSurveyItem: ({ surveyId, threadId, botId, responseOtid, responseTimestampMs, simonSessionFbid, tessaSessionFbid, testArmName }?: any) => any;
export declare const multipleResponseSection: (responses?: never[], { layoutType, survey }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const bloomCardSection: (primitives?: never[]) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const addonActionSection: (primitives?: never[], { actionType, alignment }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const QuotaUpsellMeterUsageType: Readonly<{
    META_AI_THINK_HARD: "META_AI_THINK_HARD";
}>;
export declare const quotaUpsellButton: ({ label, action, deeplink }?: any) => any;
export declare const quotaUpsellSection: ({ title, body, bodyLine1, bodyLine2, meterUsageType, benefitType, buttons }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const quizQuestion: ({ question, options, correctIndices, explanation, hints }?: any) => any;
export declare const quizSection: ({ title, subject, questions }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const actionGroupButton: ({ actionId, clientActionId, label, deeplink, deeplinkUrl, androidDeeplinkUrl }?: any) => any;
export declare const actionGroupSection: ({ groupId, recommendedActionId, buttons }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const fusedComparisonCta: ({ label, uri }?: any) => any;
export declare const fusedComparisonColumn: ({ productId, title, productUrl, merchant, image, price, originalPrice, cta }?: any) => any;
export declare const fusedComparisonRow: ({ label, cells }?: any) => any;
export declare const fusedComparisonSection: ({ columns, rows, labelColumnIndex, pinLabelColumn }?: any) => {
    view_model: {
        [x: number]: any;
        __typename: string;
    };
    __typename: string;
};
export declare const readSignedRichResponse: (msg: any) => {
    richResponseMessage: any;
    botMetadata: any;
    botJid: any;
    unifiedResponseBytes: Buffer<ArrayBuffer> | undefined;
    proof: any;
    hasProof: boolean;
} | null;
export declare const verifyRichResponseSignature: (msg: any, { at }?: any) => {
    status: string;
} | {
    status: string;
    reason: string;
};
export declare const forwardRichResponse: (sock: any, jid: any, msg: any, { quoted, contextInfo, messageId, additionalNodes, forwardWrapper, ...options }?: any) => Promise<import("../../index.js").WAMessage>;
//# sourceMappingURL=metaai.d.ts.map