/**
 * Ported from @rexxhayanasi/elaina-baileys 1.4.x - MessageBuilder/index.js
 * Copied as-is (JS -> TS, type-checking disabled); only import paths were adapted for tb2.
 *
 * NOTE: this file is NOT covered by the repository's MIT license alone. It carries its author's own
 * watermark / license notice right below (Nixel). Keep that notice, do not reupload or redistribute
 * this module as a standalone product. See LICENSE.
 * Re-checked against elaina-baileys 1.4.7: the exported surface matches; see PORTED_FROM below.
 */
/**
 * Do not remove this watermark.
 *
 * NIXCODE - Advanced WhatsApp Interactive Message Builder
 * Built for creating buttons, carousels, native flows,
 * and AI rich response payloads using Baileys with
 * fluent chaining, flexible payload customization,
 * and scalable architecture for modern bot development.
 *
 * Runtime:
 * - Baileys: @rexxhayanasi/elaina-baileys
 *
 * Created by Nixel
 * Contributors: ~ Ahmad tumbuh kembang
 *
 * WhatsApp: wa.me/6285188349341
 * Channel: https://whatsapp.com/channel/0029VbCV1ck8fewpdNb2TY2k
 *
 * Copyright (c) 2026 Nixel
 *
 * Permission is granted to use and modify this library
 * for personal or commercial projects.
 *
 * Reuploading, reselling, relicensing, or redistributing
 * this library as a standalone product is prohibited.
 *
 * Do not claim this project as your own original work.
 */
declare const VERSION = "4.7";
declare class AIRichError extends Error {
    constructor(message: any, code: any, meta?: {});
}
declare class ItemNotFoundError extends AIRichError {
    constructor(id: any, availableIds?: never[]);
}
declare class DuplicateIdError extends AIRichError {
    constructor(id: any);
}
declare class InvalidTargetError extends AIRichError {
    constructor(message: any, meta?: {});
}
declare class ContentValidationError extends AIRichError {
    constructor(message: any, meta?: {});
}
declare class Toolkit {
    constructor();
    static extractIE(text: any, { extract, hyperlink, citation, latex, deeplink }?: any): {
        text: any;
        ie: never[];
        inline_entities: never[];
    } | {
        text: string;
        ie: ({
            type: string;
            ie: {
                key: string;
                text: any;
                url: any;
                width: any;
                height: any;
                font_height: any;
                padding: any;
                is_trusted?: undefined;
                reference_id?: undefined;
            };
        } | {
            type: string;
            ie: {
                key: string;
                text: any;
                url: any;
                width?: undefined;
                height?: undefined;
                font_height?: undefined;
                padding?: undefined;
                is_trusted?: undefined;
                reference_id?: undefined;
            };
        } | {
            type: string;
            ie: {
                key: string;
                text: any;
                url: any;
                is_trusted: boolean;
                width?: undefined;
                height?: undefined;
                font_height?: undefined;
                padding?: undefined;
                reference_id?: undefined;
            };
        } | {
            type: string;
            ie: {
                reference_id: number;
                key: string;
                text: string;
                url: any;
                width?: undefined;
                height?: undefined;
                font_height?: undefined;
                padding?: undefined;
                is_trusted?: undefined;
            };
        })[];
        inline_entities: ({
            key: any;
            metadata: {
                display_name: any;
                is_trusted: any;
                url: any;
                __typename: string;
                deeplink_url?: undefined;
                text?: undefined;
                reference_id?: undefined;
                reference_url?: undefined;
                reference_title?: undefined;
                reference_display_name?: undefined;
                sources?: undefined;
                latex_expression?: undefined;
                latex_image?: undefined;
                font_height?: undefined;
                padding?: undefined;
            };
        } | {
            key: any;
            metadata: {
                deeplink_url: any;
                text: any;
                __typename: string;
                display_name?: undefined;
                is_trusted?: undefined;
                url?: undefined;
                reference_id?: undefined;
                reference_url?: undefined;
                reference_title?: undefined;
                reference_display_name?: undefined;
                sources?: undefined;
                latex_expression?: undefined;
                latex_image?: undefined;
                font_height?: undefined;
                padding?: undefined;
            };
        } | {
            key: any;
            metadata: {
                reference_id: any;
                reference_url: any;
                reference_title: any;
                reference_display_name: any;
                sources: never[];
                __typename: string;
                display_name?: undefined;
                is_trusted?: undefined;
                url?: undefined;
                deeplink_url?: undefined;
                text?: undefined;
                latex_expression?: undefined;
                latex_image?: undefined;
                font_height?: undefined;
                padding?: undefined;
            };
        } | {
            key: any;
            metadata: {
                latex_expression: any;
                latex_image: {
                    url: any;
                    width: number;
                    height: number;
                };
                font_height: number;
                padding: number;
                __typename: string;
                display_name?: undefined;
                is_trusted?: undefined;
                url?: undefined;
                deeplink_url?: undefined;
                text?: undefined;
                reference_id?: undefined;
                reference_url?: undefined;
                reference_title?: undefined;
                reference_display_name?: undefined;
                sources?: undefined;
            };
        })[];
    };
    static resize(buffer: any, x: any, y: any, fit?: string): Promise<any>;
    static waitAllPromises(input: any): Promise<any>;
    static fetchBuffer(url: any, options?: {}, { silent }?: any): Promise<Buffer<ArrayBufferLike>>;
    static toUrl(_client: any, path: any, mediaType?: string): Promise<any>;
    static resolveMedia(_client: any, media: any, mediaType?: string, { resolveUrl, resolveWAUrl, result, resize, width, height }?: any): any;
    static getMp4Duration(buffer: any, { silent }?: any): number;
    static getMp4Preview(videoBuffer: any, { time, result, resize, width, height, silent }?: any): Promise<unknown>;
    static stringifyEscaped(obj: any): string;
}
declare class BaseBuilder {
    constructor();
    setTitle(title: any): this;
    setSubtitle(subtitle: any): this;
    setBody(body: any): this;
    setFooter(footer: any): this;
    setContextInfo(obj: any): this;
    addPayload(obj: any): this;
}
declare class Button extends BaseBuilder {
    #private;
    constructor(client: any);
    loadFrom(msg: any): this;
    setImage(path: any, options?: {}): this;
    setVideo(path: any, options?: {}): this;
    setDocument(path: any, options?: {}): this;
    setMedia(obj: any): this;
    clearButtons(): this;
    setParams(obj: any): this;
    addButton(name: any, params: any): this;
    makeRow(header?: string, title?: string, description?: string, id?: string): this;
    makeSection(title?: string, highlight_label?: string): this;
    addSelection(title: any, options?: {}): this;
    addReply(display_text?: string, id?: string, options?: {}): this;
    addCall(display_text?: string, id?: string, options?: {}): this;
    addReminder(display_text?: string, id?: string, options?: {}): this;
    addCancelReminder(display_text?: string, id?: string, options?: {}): this;
    addAddress(display_text?: string, id?: string, options?: {}): this;
    addLocation(options?: {}): this;
    addUrl(display_text?: string, url?: string, webview_interaction?: boolean, options?: {}): this;
    addCopy(display_text?: string, copy_code?: string, options?: {}): this;
    static paramsList: {
        limited_time_offer: {
            text: string;
            url: string;
            copy_code: string;
            expiration_time: string;
        };
        bottom_sheet: {
            in_thread_buttons_limit: string;
            divider_indices: string[];
            list_title: string;
            button_title: string;
        };
        tap_target_configuration: {
            title: string;
            description: string;
            canonical_url: string;
            domain: string;
            buttonIndex: string;
        };
    };
    toCard(): Promise<{
        body: {
            text: any;
        };
        footer: {
            text: any;
        };
        header: any;
        nativeFlowMessage: {
            messageParamsJson: string;
            buttons: any;
        };
    }>;
    build(jid: any, { messageId, ...options }?: any): Promise<import("../../index.js").WAMessage>;
    send(jid: any, { messageId, additionalNodes, ...options }?: any): Promise<import("../../index.js").WAMessage>;
}
declare class ButtonV2 extends BaseBuilder {
    #private;
    constructor(client: any);
    loadFrom(msg: any): this;
    addButton(displayText?: string, buttonId?: `${string}-${string}-${string}-${string}-${string}`): this;
    addRawButton(obj: any): this;
    setRawThumbnail(thumbnail: any): this;
    setThumbnail(path: any): this;
    setMedia(obj: any): this;
    build(jid: any, { messageId, ...options }?: any): Promise<import("../../index.js").WAMessage>;
    send(jid: any, { messageId, additionalNodes, ...options }?: any): Promise<import("../../index.js").WAMessage>;
}
declare class Carousel extends BaseBuilder {
    #private;
    constructor(client: any);
    loadFrom(msg: any): this;
    addCard(card: any): this;
    build(jid: any, { messageId, ...options }?: any): import("../../index.js").WAMessage;
    send(jid: any, { messageId, additionalNodes, ...options }?: any): Promise<import("../../index.js").WAMessage>;
}
declare class AIRich extends BaseBuilder {
    #private;
    constructor(client: any, { dynamic, unsupportedTypeAlert }?: any);
    _dropSignature(): this;
    get isSignaturePreserved(): boolean;
    addEmbeddedScreen(screen: any): this;
    setBotMetadata(extra: any): this;
    addFooterSection(section: any): this;
    clearFooterSections(): this;
    loadFrom(msg: any): this;
    setResponseMeta(meta: any): this;
    setResponseId(id: any): this;
    refreshResponseId(): this;
    setBotResponseId(id: any): this;
    refreshBotResponseId(): this;
    createAlert(type: any): {
        messageType: number;
        messageText: string;
    } | undefined;
    addText(text: any, { hyperlink, citation, latex, deeplink, id, replace, insertAt }?: any): this;
    addFOAText(text: any, { id, replace, insertAt }?: any): this;
    addCode(language: any, code: any, { id, replace, insertAt }?: any): this;
    addTable(table: any, { hyperlink, citation, latex, deeplink, id, replace, insertAt }?: any): this;
    static MAP_DELTA: number;
    addMap(places?: never[], { center, latitudeDelta, longitudeDelta, showInfoList, motivation, staticMapUrl, staticMapDarkUrl, id, replace, insertAt }?: any): this;
    addSource(sources?: never[], { id, replace, insertAt }?: any): this;
    addReels(reelsItems?: never[], { id, replace, insertAt }?: any): this;
    addImage(imageUrl: any, { width, height, status, update_text, resolveUrl, id, replace, insertAt }?: any): this;
    addVideo(videoUrl: any, { autoFill, status, estimatedTime, id, replace, insertAt }?: any): this;
    addProduct(data?: {}, { id, replace, insertAt }?: any): this;
    addHtmlCard(html: any, { mimeType, width, height, cardType, sandbox, id, replace, insertAt }?: any): this;
    addSelectableText(text: any, { selectionId, id, replace, insertAt }?: any): this;
    addQuiz(question: any, options?: never[], { explanation, id, replace, insertAt }?: any): this;
    addComparisonTable(columns?: never[], rows?: never[], { highlightLabel, id, replace, insertAt }?: any): this;
    addSports(games?: never[], { league, id, replace, insertAt }?: any): this;
    addPost(data?: {}, { id, replace, insertAt }?: any): this;
    addMetadata(text: any, { id, replace, insertAt }?: any): this;
    addTip(text: any, { id, replace, insertAt }?: any): this;
    addWidget(data: any, { layout, id, replace, insertAt, ...options }?: any): this;
    addFooterAction(data: any, { layout, id, replace, insertAt, ...options }?: any): this;
    addSuggest(suggestion: any, { scroll, layout, id, replace, insertAt }?: any): this;
    build(jid: any, { bypassDownload, forwarded, forwardWrapper, notification, includesUnifiedResponse, includesSubmessages, botJid, forwardingScore, botEntryPointOrigin, messageSharing, disclaimerText, verification, quoted, quotedParticipant, messageId, ...options }?: any): Promise<import("../../index.js").WAMessage>;
    buildEdit(targetJid: any, targetId: any, { msg, messageId, forwardWrapper, ...options }?: any): Promise<import("../../index.js").WAMessage>;
    sendEdit(jid: any, id: any, { msg, messageId, additionalNodes, ...options }?: any): Promise<import("../../index.js").WAMessage>;
    send(jid: any, { bypassDownload, forwarded, notification, includesUnifiedResponse, includesSubmessages, messageId, additionalNodes, ...options }?: any): Promise<import("../../index.js").WAMessage>;
    static tokenizer(code: any, lang?: string): {
        codeBlock: any[];
        unified_codeBlock: {
            content: any;
            type: any;
        }[];
    };
    static toTableMetadata(arr: any, { hyperlink, citation, latex, deeplink }?: any): {
        title: string;
        rows: {
            isHeading?: boolean | undefined;
            items: any[];
        }[];
        unified_rows: {
            markdown_cells?: {
                inline_entities?: never[] | ({
                    key: any;
                    metadata: {
                        display_name: any;
                        is_trusted: any;
                        url: any;
                        __typename: string;
                        deeplink_url?: undefined;
                        text?: undefined;
                        reference_id?: undefined;
                        reference_url?: undefined;
                        reference_title?: undefined;
                        reference_display_name?: undefined;
                        sources?: undefined;
                        latex_expression?: undefined;
                        latex_image?: undefined;
                        font_height?: undefined;
                        padding?: undefined;
                    };
                } | {
                    key: any;
                    metadata: {
                        deeplink_url: any;
                        text: any;
                        __typename: string;
                        display_name?: undefined;
                        is_trusted?: undefined;
                        url?: undefined;
                        reference_id?: undefined;
                        reference_url?: undefined;
                        reference_title?: undefined;
                        reference_display_name?: undefined;
                        sources?: undefined;
                        latex_expression?: undefined;
                        latex_image?: undefined;
                        font_height?: undefined;
                        padding?: undefined;
                    };
                } | {
                    key: any;
                    metadata: {
                        reference_id: any;
                        reference_url: any;
                        reference_title: any;
                        reference_display_name: any;
                        sources: never[];
                        __typename: string;
                        display_name?: undefined;
                        is_trusted?: undefined;
                        url?: undefined;
                        deeplink_url?: undefined;
                        text?: undefined;
                        latex_expression?: undefined;
                        latex_image?: undefined;
                        font_height?: undefined;
                        padding?: undefined;
                    };
                } | {
                    key: any;
                    metadata: {
                        latex_expression: any;
                        latex_image: {
                            url: any;
                            width: number;
                            height: number;
                        };
                        font_height: number;
                        padding: number;
                        __typename: string;
                        display_name?: undefined;
                        is_trusted?: undefined;
                        url?: undefined;
                        deeplink_url?: undefined;
                        text?: undefined;
                        reference_id?: undefined;
                        reference_url?: undefined;
                        reference_title?: undefined;
                        reference_display_name?: undefined;
                        sources?: undefined;
                    };
                })[] | undefined;
                text: any;
            }[] | undefined;
            is_header: boolean;
            cells: any[];
        }[];
    };
    static isMetaSignature(verificationMetadata: any): boolean;
    static _warnPlaceholderSignature(client: any): void;
    static PLACEHOLDER_MARKER: Buffer<ArrayBuffer>;
    static generateVerificationMetadata(): {
        proofs: {
            version: number;
            useCase: number;
            signature: string;
            certificateChain: string[];
        }[];
    };
    static DEFAULT_BOT_JID: string;
    static FORWARD_ORIGIN_META_AI: number;
    static BOT_ENTRY_POINT_META_AI_FORWARD: number;
    static wrapRichResponse(richResponseMessage: any, forwardWrapper?: boolean): {
        botForwardedMessage: {
            message: {
                richResponseMessage: any;
            };
        };
        richResponseMessage?: undefined;
    } | {
        richResponseMessage: any;
        botForwardedMessage?: undefined;
    };
    static LAYOUT_FIELDS: Readonly<{
        Single: "primitive";
        Grid: "primitives";
        HScroll: "primitives";
        VStack: "primitives";
        ActionRow: "primitives";
        AddonAction: "primitives";
        FlexibleCountGrid: "primitives";
        RichListItem: "text_content";
        MultipleResponse: "responses";
        IGSuggestedBloomCard: "primitives";
    }>;
    static SECTION_TYPENAME: string;
    static UNIFIED_RESPONSE_TYPENAME: string;
    static normalizeSection(section: any): any;
    static newLayout(name: any, data: any, extra?: {}): {
        view_model: {
            [x: number]: any;
            __typename: string;
        };
        __typename: string;
    };
    _makeNode(id: any, section: any, submessage: any): {
        id: any;
        section: any;
        submessage: any;
    };
    _registerId(node: any, id: any): void;
    _unregisterId(node: any): void;
    hasId(id: any): any;
    getIds(): any[];
    peek(id: any): {
        id: any;
        section: any;
        submessage: any;
    } | null;
    assignId(index: any, id: any): this;
    _getNode(id: any): any;
    _resolveTarget(target: any): {
        id: string;
        offset: any;
    };
    _resolveNodeIndex(target: any): {
        id: string;
        offset: any;
        baseIndex: any;
        index: any;
    };
    _validateSections(section: any): any[];
    _validateSubmessages(submessage: any): any[];
    _pairSubmessages(sections: any, submessages: any): any;
    _addContent(section: any, submessage: any, { id, replace, insertAt }?: any): this;
    addSection(section: any, { submessage, text, ...options }?: any): this;
    addSubmessage(submessage: any, { id, replace, insertAt }?: any): this;
    delete(target: any): this;
    get _sections(): any;
    get _submessages(): any;
    get sections(): any;
    get items(): any;
}
export { VERSION, VERSION as MESSAGE_BUILDER_VERSION, Button, ButtonV2, Carousel as AIRichCarousel, AIRich, Toolkit, AIRichError, ItemNotFoundError, DuplicateIdError, InvalidTargetError, ContentValidationError };
export declare const MessageBuilder: {
    VERSION: string;
    Button: typeof Button;
    ButtonV2: typeof ButtonV2;
    Carousel: typeof Carousel;
    AIRichCarousel: typeof Carousel;
    AIRich: typeof AIRich;
    Toolkit: typeof Toolkit;
    AIRichError: typeof AIRichError;
    ItemNotFoundError: typeof ItemNotFoundError;
    DuplicateIdError: typeof DuplicateIdError;
    InvalidTargetError: typeof InvalidTargetError;
    ContentValidationError: typeof ContentValidationError;
};
export declare const MB: {
    VERSION: string;
    Button: typeof Button;
    ButtonV2: typeof ButtonV2;
    Carousel: typeof Carousel;
    AIRichCarousel: typeof Carousel;
    AIRich: typeof AIRich;
    Toolkit: typeof Toolkit;
    AIRichError: typeof AIRichError;
    ItemNotFoundError: typeof ItemNotFoundError;
    DuplicateIdError: typeof DuplicateIdError;
    InvalidTargetError: typeof InvalidTargetError;
    ContentValidationError: typeof ContentValidationError;
};
//# sourceMappingURL=index.d.ts.map