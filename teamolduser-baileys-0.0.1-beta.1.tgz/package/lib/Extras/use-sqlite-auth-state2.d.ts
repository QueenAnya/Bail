/**
 * SQLite auth-state adapter ported from @rexxhayanasi/elaina-baileys' Utils/use-sqlite-auth-state.js
 * (MIT; upstream attribution is preserved in the repository's LICENSE).
 * Kept as `useSqliteAuthState2` so Anya's existing `useSqliteAuthState` API remains unchanged.
 *
 * Uses the same `creds` and `signal_keys` schema as the Elaina implementation. When an existing
 * database handle is supplied, its lifecycle remains owned by the caller; a handle created from
 * `dbPath` is owned and closed by this adapter.
 */
import type BetterSqlite3 from 'better-sqlite3';
import type { AuthenticationStateWithListing } from '../Types/index.js';
export type SqliteAuthState2Options = {
    /** Path to a SQLite database file (created when it does not exist). */
    dbPath?: string;
    /** alias of `dbPath` */
    path?: string;
    /** Existing better-sqlite3 Database instance. This adapter will not close it. */
    database?: BetterSqlite3.Database;
    /**
     * Namespace this session inside the database: keys are stored as `<session>:<key>`.
     *
     * Omit it (or pass `default`) and rows look exactly as they always have, so an existing database keeps working.
     * Set it and several bots can share one file.
     */
    session?: string;
};
export type SqliteAuthState2Result = {
    state: AuthenticationStateWithListing;
    saveCreds: () => Promise<void>;
    clearAuth: () => Promise<void>;
    close: () => Promise<void>;
};
/**
 * Create an Elaina-compatible SQLite auth state. Enables WAL mode and exposes `clearAuth()` and `close()`.
 * The existing `useSqliteAuthState` implementation is intentionally not modified.
 */
export declare function useSqliteAuthState2(
/**
 * Options object, or positional arguments. Accepted shapes:
 * `(dbPath)`, `(dbPath, session)`, `({ dbPath })`, `({ dbPath, session })`, `({ database })`.
 */
a: string | SqliteAuthState2Options, b?: string | SqliteAuthState2Options, c?: string): Promise<SqliteAuthState2Result>;
/**
 * Elaina exports this adapter as `useSqliteAuthState`. That name is already taken at the package root by Anya's own
 * adapter (`src/Addons/use-sqlite-auth-state.ts`), so this module cannot re-export it without a clash. Import the
 * Elaina-compatible one as `useSqliteAuthState2`, or take `useSqliteAuthState` from the package root for Anya's.
 */
/**
 * Elaina's export name for this adapter.
 *
 * The pre-existing Anya adapter keeps the bare `useSqliteAuthState` name, so the Elaina-compatible port is exported
 * as `useSqliteAuthState2` (this function). Both names are available: the bare one from the package root resolves to
 * Anya's original, and this alias gives code ported from elaina-baileys its own name.
 */
export declare const useSqliteAuthState: typeof useSqliteAuthState2;
//# sourceMappingURL=use-sqlite-auth-state2.d.ts.map