/**
 * The socket-shaped facade over the newsletter status API.
 *
 * Upstream (elaina-baileys) attaches each operation to the socket individually:
 *   sock.sendNewsletterStatus = makeNewsletterStatusSender(sock, config)
 *   sock.sendNewsletterStatusReaction = makeNewsletterStatusReactionSender(sock)
 *   ...
 *
 * This fork hands the same five methods back as one object so `Extras/socket.ts` can merge them with the other
 * ported layers in a single spread. The operations themselves live in `newsletter-status.ts`, which is why that
 * file stays byte-identical to upstream; only this composition is local.
 */
import { type NewsletterStatusConfig, type NewsletterStatusSocket } from './newsletter-status.js';
export declare const makeNewsletterStatusExtras: (sock: NewsletterStatusSocket, config?: NewsletterStatusConfig) => {
    sendNewsletterStatus: (jid: string, content: any, options?: Record<string, any>) => Promise<any>;
    sendNewsletterStatusReaction: (jid: string, parentServerId: string | number, reaction?: string | null, options?: {
        messageId?: string;
        ackTimeoutMs?: number;
    }) => Promise<{
        key: {
            remoteJid: string;
            fromMe: boolean;
            id: string;
        };
        status: import("../index.js").proto.WebMessageInfo.Status;
        newsletterStatusServerId: number | undefined;
        newsletterStatusAck: {
            class: string | undefined;
            from: string | undefined;
            id: string | undefined;
            t: number | undefined;
            serverId: number | undefined;
            edit: string | undefined;
            error: string | undefined;
            applicationError: number | undefined;
            backoff: number | undefined;
            node: any;
        };
        newsletterStatusResponse: any;
    }>;
    revokeNewsletterStatus: (jid: string, statusId: string, options?: {
        ackTimeoutMs?: number;
    }) => Promise<{
        key: {
            remoteJid: string;
            fromMe: boolean;
            id: string;
        };
        status: import("../index.js").proto.WebMessageInfo.Status;
        newsletterStatusAck: {
            class: string | undefined;
            from: string | undefined;
            id: string | undefined;
            t: number | undefined;
            serverId: number | undefined;
            edit: string | undefined;
            error: string | undefined;
            applicationError: number | undefined;
            backoff: number | undefined;
            node: any;
        };
        newsletterStatusResponse: any;
    }>;
    getNewsletterStatuses: (jid: string, options?: Record<string, any>) => Promise<{
        jid: string | undefined;
        t: number | undefined;
        statuses: {
            id: string | undefined;
            serverId: number | undefined;
            t: number | undefined;
            isSender: boolean;
            type: string | undefined;
            edit: string | undefined;
            mediaType: string | undefined;
            interactionType: string | undefined;
            reaction: string | undefined;
            adminProfile: {
                id: string | undefined;
                name: string | undefined;
                pictureId: string | undefined;
                pictureDirectPath: string | undefined;
            } | undefined;
            paidPartnership: boolean;
            aiContent: boolean;
            editTimestamp: number | undefined;
            originalTimestamp: number | undefined;
            reactionCounts: {
                code: string | undefined;
                count: number | undefined;
            }[] | undefined;
            viewsCount: number | undefined;
            responsesCount: number | undefined;
            message: (import("../index.js").proto.Message & import("../index.js").proto.Message.$Shape) | undefined;
            node: import("../index.js").BinaryNode;
        }[];
    }>;
    getNewsletterStatusUpdates: (jid: string, options?: Record<string, any>) => Promise<{
        jid: string | undefined;
        t: number | undefined;
        statuses: {
            id: string | undefined;
            serverId: number | undefined;
            t: number | undefined;
            isSender: boolean;
            type: string | undefined;
            edit: string | undefined;
            mediaType: string | undefined;
            interactionType: string | undefined;
            reaction: string | undefined;
            adminProfile: {
                id: string | undefined;
                name: string | undefined;
                pictureId: string | undefined;
                pictureDirectPath: string | undefined;
            } | undefined;
            paidPartnership: boolean;
            aiContent: boolean;
            editTimestamp: number | undefined;
            originalTimestamp: number | undefined;
            reactionCounts: {
                code: string | undefined;
                count: number | undefined;
            }[] | undefined;
            viewsCount: number | undefined;
            responsesCount: number | undefined;
            message: (import("../index.js").proto.Message & import("../index.js").proto.Message.$Shape) | undefined;
            node: import("../index.js").BinaryNode;
        }[];
    }>;
};
//# sourceMappingURL=newsletter-status-socket.d.ts.map