import { type DatabaseAuthState } from './auth-store.js';
export interface RedisAuthState2Options {
    /** an existing node-redis client (it is NOT closed by `close()` unless `closeClient` is true) */
    client?: any;
    /** connection string, used when no client is given, e.g. `redis://localhost:6379` */
    uri?: string;
    /** alias of `uri` — the same connection string, for callers who read `REDIS_URL` */
    url?: string;
    /** extra `createClient` options, merged over `{ url: uri }` */
    config?: any;
    /** session name, lets several bots share one Redis, default `default` */
    session?: string;
    /** key prefix, default `baileys_auth` — the same default as `useRedisAuthState` */
    prefix?: string;
    /** close the client in `close()` even when it was passed in, default false */
    closeClient?: boolean;
}
export declare function useRedisAuthState2(
/** `(url)`, `(url, session)`, `({ url, session })`, `({ client })`. */
a?: string | RedisAuthState2Options, b?: string | RedisAuthState2Options, c?: string): Promise<DatabaseAuthState>;
//# sourceMappingURL=use-redis-auth-state2.d.ts.map