/**
 * Ported from @rexxhayanasi/elaina-baileys 1.4.x (MIT) - Utils/html-app.js
 * Copied as-is (JS -> TS); only import paths and parameter types were adapted for tb2.
 * Re-checked against elaina-baileys 1.4.7: the exported surface matches; see PORTED_FROM below.
 */
export declare const HTML_APP_MESSAGE_CEILING: number;
export declare const HTML_APP_BYTE_BUDGET: number;
export declare const HTML_APP_BYTE_LIMIT: number;
export declare const wireBytes: (html: string) => number;
export interface HtmlAppCheckOptions {
    height?: number;
    maxBytes?: number;
}
export declare const checkHtmlApp: (html: string, { height, maxBytes }?: HtmlAppCheckOptions) => {
    ok: boolean;
    bytes: number;
    wireBytes: number;
    embeddedBytes: number;
    problems: string[];
    warnings: string[];
};
//# sourceMappingURL=html-app.d.ts.map