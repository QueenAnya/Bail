/**
 * Ported from @rexxhayanasi/elaina-baileys (MIT) - Utils/payment-messages.js, rewritten in TypeScript.
 *
 * Builders / readers for split payments and payment reminders (`splitPayment`, `splitPaymentUpdate`,
 * `paymentReminder` content keys, sent through `sock.sendMessage`). The currency is required, exactly as in
 * Elaina's `src/Utils/payment-messages.js` — there is no default, so a missing code is a bug, not an INR charge.
 */
export declare const SplitPaymentStatus: Readonly<{
    PENDING: 0;
    PAID: 1;
}>;
export declare const ReminderFrequency: Readonly<{
    REMINDER_FREQUENCY_UNKNOWN: 0;
    WEEKLY: 1;
    BI_WEEKLY: 2;
    MONTHLY: 3;
    QUARTERLY: 4;
}>;
export declare const ReminderStatus: Readonly<{
    REMINDER_STATUS_UNKNOWN: 0;
    ACTIVE: 1;
    CANCELLED_BY_CREATOR: 2;
    STOPPED_BY_RECEIVER: 3;
    EXPIRED: 4;
    PAID: 5;
}>;
export declare const MONEY_OFFSET = 1000;
/**
 * Money travels as an integer scaled by offset, so 500 rupees at the usual offset of 1000 go on the wire as 500000.
 * Passing the scaled value by mistake overcharges by three orders of magnitude, so the amount here is always the
 * human one (e.g. `money(500, 'INR')`).
 */
export declare const money: (amount: number | string, currencyCode: string | undefined, offset?: number) => {
    value: number;
    offset: number;
    currencyCode: string;
};
export declare const readMoney: (value: any) => {
    amount: number;
    currencyCode: string;
} | undefined;
export interface SplitPaymentParticipant {
    jid: string;
    amount?: number | string;
    currency?: string;
    status?: number;
}
export interface SplitPaymentInput {
    splitId: string | number;
    total?: number | string;
    currency?: string;
    description?: string;
    requesterJid?: string;
    participants: SplitPaymentParticipant[];
    createdAt?: number;
}
export declare const buildSplitPayment: ({ splitId, total, currency, description, requesterJid, participants, createdAt }?: Partial<SplitPaymentInput>) => {
    splitId: string;
    totalAmount: {
        value: number;
        offset: number;
        currencyCode: string;
    } | undefined;
    description: string | undefined;
    requesterJid: string | undefined;
    participants: {
        jid: string;
        amount: {
            value: number;
            offset: number;
            currencyCode: string;
        } | undefined;
        status: number;
    }[];
    createdAtMs: number;
};
export declare const buildSplitPaymentUpdate: ({ splitId, participantJid }?: {
    splitId?: string | number;
    participantJid?: string;
}) => {
    splitId: string;
    participantJid: string;
};
export interface PaymentReminderInput {
    reminderId: string | number;
    instanceId?: string | number;
    description?: string;
    frequency?: number;
    status?: number;
    amount?: number | string;
    currency?: string;
    payeeVpa?: string;
    payeeJid?: string;
    payerJid?: string;
}
export declare const buildPaymentReminder: ({ reminderId, instanceId, description, frequency, status, amount, currency, payeeVpa, payeeJid, payerJid }?: Partial<PaymentReminderInput>) => {
    reminderId: string;
    instanceId: string | undefined;
    description: string | undefined;
    frequency: number;
    status: number;
    amount: {
        value: number;
        offset: number;
        currencyCode: string;
    } | undefined;
    payeeVpa: string | undefined;
    payeeJid: string | undefined;
    payerJid: string | undefined;
};
export declare const readSplitPayment: (msg: any) => {
    splitId: any;
    total: {
        amount: number;
        currencyCode: string;
    } | undefined;
    description: any;
    requesterJid: any;
    createdAtMs: number | undefined;
    participants: any;
} | null;
export declare const readPaymentReminder: (msg: any) => {
    reminderId: any;
    instanceId: any;
    description: any;
    frequency: any;
    status: any;
    amount: {
        amount: number;
        currencyCode: string;
    } | undefined;
    payeeVpa: any;
    payeeJid: any;
    payerJid: any;
} | null;
//# sourceMappingURL=payment-messages.d.ts.map