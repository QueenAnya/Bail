/**
 * Ported from @rexxhayanasi/elaina-baileys (MIT) - Utils/status-stickers.js, rewritten in TypeScript.
 *
 * Interactive "stickers" for status images / videos (location, channel, link, music, embedded message) as
 * `InteractiveAnnotation` objects, plus the `music` message builder / reader.
 */
import { proto } from '../../WAProto/index.js';
export declare const StatusLinkType: Readonly<{
    RASTERIZED_LINK_PREVIEW: 1;
    RASTERIZED_LINK_TRUNCATED: 2;
    RASTERIZED_LINK_FULL_URL: 3;
}>;
export declare const STICKER_DEFAULT_AREA: Readonly<{
    x: 0.25;
    y: 0.4;
    width: 0.5;
    height: 0.2;
}>;
export interface StickerArea {
    x: number;
    y: number;
    width: number;
    height: number;
}
/** the four corners of a sticker area (fractions of the media, 0..1) */
export declare const stickerArea: ({ x, y, width, height }?: StickerArea) => {
    x: number;
    y: number;
}[];
export declare const locationSticker: ({ latitude, longitude, name, area, skipConfirmation }?: {
    latitude?: number;
    longitude?: number;
    name?: string;
    area?: StickerArea;
    skipConfirmation?: boolean;
}) => {
    polygonVertices: {
        x: number;
        y: number;
    }[];
};
export declare const channelSticker: ({ jid, name, serverMessageId, accessibilityText, area }?: {
    jid?: string;
    name?: string;
    serverMessageId?: number;
    accessibilityText?: string;
    area?: StickerArea;
}) => {
    polygonVertices: {
        x: number;
        y: number;
    }[];
};
export declare const linkSticker: ({ url, title, area, linkType }?: {
    url?: string;
    title?: string;
    area?: StickerArea;
    linkType?: number;
}) => {
    polygonVertices: {
        x: number;
        y: number;
    }[];
};
export interface MusicStickerOptions {
    songId?: string | number;
    title?: string;
    author?: string;
    mediaId?: string | number;
    artworkDirectPath?: string;
    artworkSha256?: Uint8Array | string;
    artworkEncSha256?: Uint8Array | string;
    artworkMediaKey?: Uint8Array | string;
    artistAttribution?: string;
    countryBlocklist?: Uint8Array | string;
    isExplicit?: boolean;
    startTimeMs?: number;
    derivedStartTimeMs?: number;
    durationMs?: number;
    area?: StickerArea;
}
export declare const musicSticker: ({ songId, title, author, mediaId, artworkDirectPath, artworkSha256, artworkEncSha256, artworkMediaKey, artistAttribution, countryBlocklist, isExplicit, startTimeMs, derivedStartTimeMs, durationMs, area }?: MusicStickerOptions) => {
    polygonVertices: {
        x: number;
        y: number;
    }[];
};
export declare const messageSticker: ({ stanzaId, message, area }?: {
    stanzaId?: string;
    message?: any;
    area?: StickerArea;
}) => {
    polygonVertices: {
        x: number;
        y: number;
    }[];
};
/** validates sticker annotations and turns them into `proto.InteractiveAnnotation` objects */
export declare const normalizeStickers: (stickers: any) => proto.InteractiveAnnotation[];
export declare const readStickers: (message: any) => {
    kind: string;
    area: {
        x: any;
        y: any;
        width: number;
        height: number;
    } | undefined;
    location: any;
    channel: any;
    link: {
        url: any;
        title: any;
        linkType: any;
    } | undefined;
    music: {
        songId: any;
        title: any;
        author: any;
    } | undefined;
    message: any;
    annotation: any;
}[];
export declare const MusicMessageStyle: Readonly<{
    UNKNOWN: 0;
    VINYL: 1;
}>;
export declare const MUSIC_ALLOWED_HOSTS: readonly string[];
export declare const isMusicHostAllowed: (value: unknown) => boolean;
export declare const buildMusicMessage: ({ songUri, artworkUri, style, contextInfo, ...music }?: MusicStickerOptions & {
    songUri?: string;
    artworkUri?: string;
    style?: number;
    contextInfo?: any;
}) => {
    embeddedMusic: any;
    songUri: string | undefined;
    artworkUri: string | undefined;
    style: number;
    contextInfo: any;
};
export declare const readMusicMessage: (msg: any) => {
    songId: any;
    mediaId: any;
    title: any;
    author: any;
    artistAttribution: any;
    isExplicit: any;
    startTimeMs: any;
    durationMs: any;
    songUri: any;
    artworkUri: any;
    style: any;
    embeddedMusic: any;
} | null;
//# sourceMappingURL=status-stickers.d.ts.map