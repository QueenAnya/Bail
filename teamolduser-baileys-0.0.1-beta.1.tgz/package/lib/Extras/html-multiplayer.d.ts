/**
 * Ported from @rexxhayanasi/elaina-baileys 1.4.x (MIT) - Utils/html-multiplayer.js
 * Copied as-is (JS -> TS); only import paths and parameter types were adapted for tb2.
 * Re-checked against elaina-baileys 1.4.7: the exported surface matches; see PORTED_FROM below.
 */
export interface HtmlMultiplayerOptions {
    url?: string;
    room?: string;
    seat?: string | number | null;
    reconnectMs?: number;
    maxReconnectMs?: number;
}
export declare const htmlMultiplayerPrelude: ({ url, room, seat, reconnectMs, maxReconnectMs }?: HtmlMultiplayerOptions) => string;
export declare const withHtmlMultiplayer: (html: string, options?: HtmlMultiplayerOptions) => string;
//# sourceMappingURL=html-multiplayer.d.ts.map