/**
 * Ported from @rexxhayanasi/elaina-baileys 1.4.x (MIT) - Utils/link-preview-metadata.js
 * Copied as-is (JS -> TS); only import paths and parameter types were adapted for tb2.
 * Re-checked against elaina-baileys 1.4.7: the exported surface matches; see PORTED_FROM below.
 */
export declare const SocialMediaPostType: Readonly<{
    NONE: 0;
    REEL: 1;
    LIVE_VIDEO: 2;
    LONG_VIDEO: 3;
    SINGLE_IMAGE: 4;
    CAROUSEL: 5;
}>;
export interface VideoEndCardInput {
    username?: string;
    caption?: string;
    thumbnailUrl?: string;
    profilePictureUrl?: string;
}
export declare const videoEndCard: ({ username, caption, thumbnailUrl, profilePictureUrl }?: VideoEndCardInput) => Record<string, any>;
/**
 * The same video url and music node exist twice, once nested in
 * LinkPreviewMetadata and once directly on ExtendedTextMessage. Which one the
 * client reads is not visible from the client, so both carry the same value.
 */
export interface SocialPreviewInput {
    postType?: number;
    videoUrl?: string;
    videoCaption?: string;
    muted?: boolean;
    durationSeconds?: number;
    experimentId?: string;
    music?: any;
    endCards?: any[];
}
export interface SocialPreviewInput {
    postType?: number;
    videoUrl?: string;
    videoCaption?: string;
    muted?: boolean;
    durationSeconds?: number;
    experimentId?: string;
    music?: any;
    endCards?: any[];
}
export declare const buildSocialPreview: ({ postType, videoUrl, videoCaption, muted, durationSeconds, experimentId, music, endCards }?: SocialPreviewInput) => Record<string, any>;
export declare const readSocialPreview: (msg: any) => Record<string, any> | null;
//# sourceMappingURL=link-preview-metadata.d.ts.map