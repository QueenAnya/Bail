import NodeCache from '@cacheable/node-cache';
import { Boom } from '@hapi/boom';
import { proto } from '../../WAProto/index.js';
import { type CapturedUnifiedResponse, type ExtractOptions, type GenerateRichHtmlOptions, type GenerateRichMessageOptions, type LatexExpression, type RichSubMessage } from '../Addons/message-composer.js';
import { type PresenceMonitorOptions } from '../Addons/presence-monitor.js';
import { type StickerPackInput, type StickerPackOptions } from '../Addons/stickerpack.js';
import type { AnyMessageContent, MediaConnInfo, MessageReceiptType, MessageRelayOptions, MiscMessageGenerationOptions, SocketConfig, WAMediaUpload, WAMessage, WAMessageKey, WAUrlInfo } from '../Types/index.js';
import { MessageRetryManager } from '../Utils/index.js';
import { type BinaryNode, type JidWithDevice } from '../WABinary/index.js';
import { USyncQuery } from '../WAUSync/index.js';
/**
 * Resolves a PN or hosted-PN JID to its mapped LID for outbound sends.
 * Uses local-only store lookup — does NOT trigger USync / network.
 * For cold (unmapped) contacts the original jid is returned unchanged.
 * Source: PR #2692 (frndchagas)
 */
export type MessageSendJid = {
    /** The JID to actually send to (may be LID if mapped) */
    jid: string;
    /** Original PN JID preserved as alternate addressing metadata */
    remoteJidAlt?: string;
    /** 'lid' when routed to a LID, undefined otherwise */
    addressingMode?: 'lid';
    /** Additional stanza attributes for LID addressing */
    additionalAttributes?: Record<string, string>;
};
export declare const resolveMessageSendJid: (jid: string, getStoredLIDForPN: (pn: string) => Promise<string | null>) => Promise<MessageSendJid>;
/**
 * Builds the protocol message and `meta` node for changing (or, with an empty label, removing)
 * the sender's member label in a group.
 */
export declare const buildMemberLabelMessage: (jid: string, memberLabel: string | null | undefined) => {
    label: string;
    content: proto.IMessage;
    node: BinaryNode;
};
export declare const makeMessagesSocket: (config: SocketConfig) => {
    userDevicesCache: import("../Types/index.js").PossiblyExtendedCacheStore | NodeCache<JidWithDevice[]>;
    outboundResendCache: import("../Types/index.js").PossiblyExtendedCacheStore | NodeCache<{
        jid: string;
        message: proto.IMessage;
    }>;
    devicesMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    issuePrivacyTokens: (jids: string[], timestamp?: number) => Promise<any>;
    assertSessions: (jids: string[], force?: boolean) => Promise<boolean>;
    relayMessage: (jid: string, message: proto.IMessage, { messageId: msgId, participant, additionalAttributes, additionalNodes, useUserDevicesCache, useCachedGroupMetadata, statusJidList, AI, secureMetaServiceLabel }: MessageRelayOptions & {
        AI?: boolean;
        secureMetaServiceLabel?: boolean;
    }) => Promise<string>;
    sendReceipt: (jid: string, participant: string | undefined, messageIds: string[], type: MessageReceiptType) => Promise<void>;
    profilePictureUrl: (jid: string, type?: "preview" | "image", timeoutMs?: number) => Promise<string | undefined>;
    getEphemeralGroup: (jid: string) => Promise<number | string>;
    sendReceipts: (keys: WAMessageKey[], type: MessageReceiptType) => Promise<void>;
    readMessages: (keys: WAMessageKey[]) => Promise<void>;
    markIdentityChanged: (jid: string) => void;
    recentlyChangedIdentities: Map<string, NodeJS.Timeout>;
    refreshMediaConn: (forceGet?: boolean) => Promise<MediaConnInfo>;
    getMediaHost: () => string;
    waUploadToServer: import("../Types/index.js").WAMediaUploadFunction;
    fetchPrivacySettings: (force?: boolean) => Promise<{
        [_: string]: string;
    }>;
    sendPeerDataOperationMessage: (pdoMessage: proto.Message.IPeerDataOperationRequestMessage) => Promise<string>;
    /**
     * Request the paired phone to generate a high-quality link preview for a URL.
     * The phone resolves the URL natively and returns metadata via a PDO response,
     * which is handled in process-message and emitted as a 'link-preview.update' event.
     * Falls back to local link-preview-js when `generateHighQualityLinkPreview` is false.
     * Source: PR #2701 (frndchagas)
     */
    requestPhoneLinkPreview: (url: string) => Promise<string>;
    createParticipantNodes: (recipientJids: string[], message: proto.IMessage, extraAttrs?: BinaryNode["attrs"], dsmMessage?: proto.IMessage) => Promise<{
        nodes: BinaryNode[];
        shouldIncludeDeviceIdentity: boolean;
    }>;
    getUSyncDevices: (jids: string[], useCache: boolean, ignoreZeroDevices: boolean) => Promise<(JidWithDevice & {
        jid: string;
    })[]>;
    messageRetryManager: MessageRetryManager | null;
    updateMemberLabel: (jid: string, memberLabel: string) => Promise<string>;
    updateMediaMessage: (message: WAMessage) => Promise<WAMessage>;
    sendGroupStatus: (groupJid: string, content: Record<string, any>, options?: Record<string, any>) => Promise<WAMessage>;
    sendGroupStatusV2: (groupJid: string, content: AnyMessageContent, options?: Record<string, any>) => Promise<WAMessage>;
    sendGroupV4Invite: (groupJid: string, participant: string, inviteCode: string, inviteExpiration?: number, groupName?: string, caption?: string, jpegThumbnail?: Buffer, options?: MiscMessageGenerationOptions) => Promise<WAMessage>;
    sendGroupInviteV4: (groupJid: string, participant: string, inviteCode: string, inviteExpiration?: number, groupName?: string, caption?: string, jpegThumbnail?: Buffer, options?: MiscMessageGenerationOptions) => Promise<WAMessage>;
    sendGroupInvite: (groupJid: string, user: string) => Promise<import("../Types/index.js").GroupInviteAttemptResult[]>;
    monitorPresence: (targets: string | string[], options?: PresenceMonitorOptions) => import("../index.js").PresenceMonitor;
    sendMessage: (jid: string | string[], content: AnyMessageContent, options?: MiscMessageGenerationOptions) => Promise<WAMessage | undefined>;
    /**
     * Build and send a sticker pack via the alternate builder
     * (`prepareStickerPackMessage`, Addons/stickerpack.ts) — kept as a
     * distinct implementation from the one `sock.sendMessage(jid, {
     * stickerPack: {...} })` uses. Use whichever produces the result you
     * need; both are fully supported.
     */
    sendStickerPack: (jid: string, stickerPack: StickerPackInput, options?: MiscMessageGenerationOptions & {
        mediaCache?: StickerPackOptions["mediaCache"];
    }) => Promise<string>;
    resize: (media: WAMediaUpload | string, width?: number, height?: number) => Promise<Buffer>;
    copyNForward: (jid: string, message: WAMessage, forceForward?: boolean | number, options?: MiscMessageGenerationOptions) => Promise<any>;
    sendStatusMentions: (content: AnyMessageContent, jids?: string[]) => Promise<WAMessage>;
    /**
     * Send a rich table via botForwardedMessage → richResponseMessage.
     */
    sendTable: (jid: string, title: string, headers: string[], rows: string[][], quoted?: any, options?: {
        headerText?: string;
        footer?: string;
    }) => Promise<{
        message: proto.IMessage;
        messageId: string;
    }>;
    /**
     * Send a rich list (single-column table).
     */
    sendList: (jid: string, title: string, items: string[] | string[][], quoted?: any, options?: {
        headerText?: string;
        footer?: string;
    }) => Promise<{
        message: proto.IMessage;
        messageId: string;
    }>;
    /**
     * Send a syntax-highlighted code block.
     */
    sendCodeBlock: (jid: string, code: string, quoted?: any, options?: {
        title?: string;
        footer?: string;
        language?: string;
    }) => Promise<{
        message: proto.IMessage;
        messageId: string;
    }>;
    /**
     * Send a rich HTML message (GenAI unified-response HTML primitive),
     * forwarded as a bot-style message.
     */
    sendRichHtml: (jid: string, htmlOrOptions: string | (GenerateRichHtmlOptions & {
        html: string;
    }), quoted?: any, options?: GenerateRichHtmlOptions) => Promise<{
        message: proto.IMessage;
        messageId: string;
    }>;
    /**
     * Send a LaTeX expression as text (no image rendering).
     */
    sendLatex: (jid: string, quoted: any, options: {
        text?: string;
        expressions: LatexExpression[];
        headerText?: string;
        footer?: string;
    }) => Promise<{
        message: proto.IMessage;
        messageId: string;
    }>;
    /**
     * Render LaTeX to PNG images, upload, and send.
     * Accepts a bare LaTeX string, `{formula}`/`{latex}`/`{text}`, a bare
     * expressions array, or the full `{expressions}` form as `options`,
     * and `quoted`/`renderLatexToPng`/`uploadFn` are all optional —
     * defaults to a local MathJax renderer + upload helper when
     * omitted, e.g. `sock.sendLatexImage(jid, null, 'E=mc^2')`.
     */
    sendLatexImage: (jid: string, quoted?: any, options?: any, renderLatexToPng?: (latexExpr: string) => Promise<{
        buffer: Buffer;
        width: number;
        height: number;
    }>, uploadFn?: (buffer: Buffer, type: string) => Promise<{
        url?: string;
        directPath?: string;
    }>) => Promise<{
        message: proto.IMessage;
        messageId: string;
    }>;
    /**
     * Legacy: sends LaTeX as a native latexMetadata rich message (many clients
     * render this blank). Prefer sendLatexImage.
     */
    sendLatexNativeImage: (jid: string, quoted?: any, options?: any, renderLatexToPng?: (latexExpr: string) => Promise<{
        buffer: Buffer;
        width: number;
        height: number;
    }>, uploadFn?: (buffer: Buffer, type: string) => Promise<{
        url?: string;
        directPath?: string;
    }>) => Promise<{
        message: proto.IMessage;
        messageId: string;
    }>;
    /**
     * Render LaTeX to PNG inline image blocks, upload, and send.
     * Same flexible call shape as `sendLatexImage` — see above.
     */
    sendLatexInlineImage: (jid: string, quoted?: any, options?: any, renderLatexToPng?: (latexExpr: string) => Promise<{
        buffer: Buffer;
        width: number;
        height: number;
    }>, uploadFn?: (buffer: Buffer, type: string) => Promise<{
        url?: string;
        directPath?: string;
    }>) => Promise<{
        message: proto.IMessage;
        messageId: string;
    }>;
    /**
     * Send a rich markdown text message formatted natively via Meta AI primitives.
     * WA's richResponse text field already supports its own native markdown-like
     * syntax (*bold*, _italic_, ~strike~, ```code```), so this is a thin wrapper
     * around the TEXT rich-submessage primitive — it does not do a full CommonMark
     * parse, just passes the string straight through as a single TEXT submessage.
     *
     * `options` also controls inline entity extraction: `[text](url)` becomes a
     * clickable hyperlink, `[](url)` becomes a citation, and `[expr|w|h|fh|pad](url)`
     * becomes a rendered latex reference. Pass `{ extract: false }` to disable, or
     * `{ hyperlink: false }` / `{ citation: false }` / `{ latex: false }` to disable
     * a specific kind (all default to `true`).
     */
    sendMarkdown: (jid: string, markdown: string, quoted?: any, options?: ExtractOptions) => Promise<{
        message: proto.IMessage;
        messageId: string;
    }>;
    /**
     * Fetch a real link preview for `url` (regardless of what, if
     * anything, is in the message text) and send it — the reusable,
     * general-purpose version of the "fetch a preview, build the
     * message, send it" pattern, rather than a one-off script hardcoded
     * to a single URL/title/thumbnail.
     *
     * `textOrOptions` — a plain string sets the message text (defaults
     * to `url` itself if omitted); an object sets the text via `.text`
     * and can override any fetched `WAUrlInfo` field (title,
     * description, thumbnail, etc.) — e.g. keep the real OG image but
     * swap the title:
     *   sock.sendLinkPreviewFor(jid, url, { title: 'My own title' })
     *
     * Throws if the URL couldn't be resolved at all (unlike the normal
     * auto-detect-from-text path, which fails silently by design since
     * that's a "preview if we can, don't block sending" convenience —
     * here the caller explicitly asked for a preview of this URL, so a
     * failure should be visible).
     */
    sendLinkPreviewFor: (jid: string, url: string, textOrOptions?: string | ({
        text?: string;
    } & Partial<WAUrlInfo>), sendOptions?: MiscMessageGenerationOptions) => Promise<any>;
    /**
     * Send a fully custom rich message from a raw submessages array.
     * Pass { useMarkdown: true } to render TEXT/TABLE/CODE submessages
     * as native WhatsApp rich-content primitives via unifiedResponse.
     * When useMarkdown is set, `extract`/`hyperlink`/`citation`/`latex` also
     * control inline entity extraction from TEXT and TABLE cell contents,
     * same as `sendMarkdown`.
     */
    sendRichMessage: (jid: string, submessages: RichSubMessage[], quoted?: any, options?: GenerateRichMessageOptions) => Promise<{
        message: proto.IMessage;
        messageId: string;
    }>;
    /**
     * Capture the unifiedResponse payload from an incoming Meta AI message.
     * Returns null if the message is not a rich response.
     */
    extractUnifiedResponse: (msg: proto.IMessage | null | undefined) => CapturedUnifiedResponse | null;
    /** alias of `extractUnifiedResponse` (name used by @innovatorssoft/baileys) */
    captureUnifiedResponse: (msg: proto.IMessage | null | undefined) => CapturedUnifiedResponse | null;
    /**
     * Re-send a captured unifiedResponse to a new JID.
     */
    sendUnifiedResponse: (jid: string, quoted: any, captured: CapturedUnifiedResponse) => Promise<{
        message: proto.IMessage;
        messageId: string;
    }>;
    GroupStatus: (groupJid: string, content: Record<string, any>, options?: Record<string, any>) => Promise<WAMessage>;
    GroupStatusV2: (groupJid: string, content: AnyMessageContent, options?: Record<string, any>) => Promise<WAMessage>;
    newsletterWMexQuery: (variables: Record<string, unknown> | undefined, queryId: string, options: Record<string, unknown>) => Promise<BinaryNode>;
    newsletterCreate: (name: string, description?: string) => Promise<import("../Types/index.js").NewsletterMetadata>;
    newsletterUpdate: (jid: string, updates: import("../Types/index.js").NewsletterUpdate) => Promise<unknown>;
    newsletterFetchAllParticipating: () => Promise<unknown>;
    newsletterSubscribers: (jid: string, options?: {
        count?: number;
    }) => Promise<{
        id: string | undefined;
        phoneNumber: string | undefined;
        displayName: string | undefined;
        username: string | undefined;
        role: string | undefined;
        followTime: string | undefined;
    }[]>;
    newsletterMetadata: (type: "invite" | "jid", key: string, options?: {
        fetchCreationTime?: boolean;
        fetchFullImage?: boolean;
        fetchViewerMetadata?: boolean;
        fetchPinnedMessages?: boolean;
        fetchStatusMetadata?: boolean;
        fetchWamoSub?: boolean;
        viewRole?: string;
    }) => Promise<import("../Types/index.js").NewsletterMetadata | null>;
    newsletterAction: (jid: string, type: keyof typeof import("../Types/index.js").QueryIds) => Promise<void>;
    newsletterFollow: (jid: string) => Promise<unknown>;
    newsletterUnfollow: (jid: string) => Promise<unknown>;
    newsletterMute: (jid: string) => Promise<{
        id: string;
        state: string | undefined;
    }>;
    newsletterUnmute: (jid: string) => Promise<{
        id: string;
        state: string | undefined;
    }>;
    newsletterMuteLegacy: (jid: string) => Promise<unknown>;
    newsletterUnmuteLegacy: (jid: string) => Promise<unknown>;
    newsletterUpdateName: (jid: string, name: string) => Promise<unknown>;
    newsletterUpdateDescription: (jid: string, description: string) => Promise<unknown>;
    newsletterUpdatePicture: (jid: string, content: WAMediaUpload) => Promise<unknown>;
    newsletterRemovePicture: (jid: string) => Promise<unknown>;
    newsletterReactMessage: (jid: string, serverId: string, reaction?: string) => Promise<void>;
    newsletterFetchMessages: (jid: string, count: number, since: number, after: number) => Promise<any>;
    subscribeNewsletterUpdates: (jid: string) => Promise<{
        duration: string;
    } | null>;
    newsletterAdminCount: (jid: string) => Promise<number>;
    newsletterChangeOwner: (jid: string, newOwnerJid: string) => Promise<void>;
    newsletterDemote: (jid: string, userJid: string) => Promise<void>;
    newsletterDelete: (jid: string) => Promise<void>;
    newsletterSubscribed: (options?: {
        fetchStatusMetadata?: boolean;
        fetchWamoSub?: boolean;
    }) => Promise<unknown>;
    newsletterReactionMode: (jid: string, mode: string) => Promise<void>;
    newsletterUpdateUserSetting: (jid: string, type: string, value: boolean) => Promise<{
        id: string;
        state: string | undefined;
    }>;
    newsletterUpdateReactions: (jid: string, setting: string) => Promise<unknown>;
    newsletterFetchMessageUpdates: (jid: string, options?: Record<string, any>) => Promise<{
        jid: string;
        messages: any[];
    }>;
    newsletterQuestionResponses: (jid: string, serverId: string, options?: Record<string, any>) => Promise<{
        jid: any;
        serverId: number;
        responses: {
            id: string | undefined;
            t: number | undefined;
            isSender: boolean;
            responseServerId: string | undefined;
            sender: {
                lid: string | undefined;
                notifyName: string | undefined;
                pictureDirectPath: string | undefined;
            };
            replied: boolean;
            starred: boolean;
            message: any;
        }[];
    }>;
    newsletterMyAddOns: (options?: Record<string, any>) => Promise<any[]>;
    newsletterStatusMyAddOns: (options?: Record<string, any>) => Promise<any[]>;
    newsletterAdminCapabilities: (jid: string) => Promise<any>;
    newsletterEnforcements: (jid: string, locale?: string) => Promise<{
        adminProfiles: any;
        profilePictureDeletions: any;
        suspensions: any;
        violatingMessages: any[];
        geoSuspensions: any[];
    }>;
    newsletterReports: (locale?: string) => Promise<any>;
    newsletterAppealReport: (reportId: string, reason: string) => Promise<unknown>;
    newsletterCanPostStatus: (jid: string) => Promise<{
        canPost: any;
        canPostMusic: any;
        capabilities: any;
    }>;
    newsletterAdminInfo: (jid: string) => Promise<{
        id: any;
        adminCount: any;
        adminProfile: {
            id: any;
            name: any;
            picture: {
                id: any;
                directPath: any;
            } | undefined;
        } | undefined;
        adminProfilesEnabled: any;
    }>;
    newsletterPollVoters: (jid: string, serverId: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterReactionSenders: (jid: string, serverId: string) => Promise<unknown>;
    newsletterPinMessages: (jid: string, serverIds: string | string[]) => Promise<unknown>;
    newsletterUnpinMessages: (jid: string, serverIds: string | string[]) => Promise<unknown>;
    newsletterLabelAiContent: (jid: string, serverId: string, messageType?: string) => Promise<unknown>;
    newsletterLabelPaidPartnership: (jid: string, serverId: string, messageType?: string) => Promise<unknown>;
    newsletterCreateAdminInvite: (jid: string, userJid: string) => Promise<unknown>;
    newsletterRevokeAdminInvite: (jid: string, userJid: string) => Promise<unknown>;
    newsletterAcceptAdminInvite: (jid: string) => Promise<unknown>;
    newsletterDirectoryList: (options?: Record<string, any>) => Promise<unknown>;
    newsletterDirectorySearch: (searchText: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterDirectoryCategories: (options?: Record<string, any>) => Promise<unknown>;
    newsletterSendPollVote: (jid: string, parentServerId: string, options: Record<string, any>) => Promise<{
        id: string;
    }>;
    newsletterInsights: (jid: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterFollowers: (jid: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterPendingAdminInvites: (jid: string) => Promise<any>;
    newsletterQuestionResponseState: (jid: string, serverId: string, responseServerId: string, state: string) => Promise<unknown>;
    newsletterRecommended: (options?: Record<string, any>) => Promise<unknown>;
    newsletterSimilar: (jid: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterFetchUpdates: (jid: string, count: number, after?: number, since?: number) => Promise<any>;
    groupMetadata: (jid: string) => Promise<import("../Types/index.js").GroupMetadata>;
    groupCreate: (subject: string, participants: string[]) => Promise<import("../Types/index.js").GroupMetadata>;
    groupLeave: (id: string) => Promise<void>;
    groupUpdateSubject: (jid: string, subject: string) => Promise<void>;
    groupRequestParticipantsList: (jid: string) => Promise<{
        [key: string]: string;
    }[]>;
    groupRequestParticipantsUpdate: (jid: string, participants: string[], action: "approve" | "reject") => Promise<{
        status: string;
        jid: string | undefined;
    }[]>;
    groupParticipantsUpdate: (jid: string, participants: string[], action: import("../Types/index.js").ParticipantAction) => Promise<{
        status: string;
        jid: string | undefined;
        content: BinaryNode;
    }[]>;
    groupUpdateDescription: (jid: string, description?: string) => Promise<void>;
    groupInviteCode: (jid: string) => Promise<string | undefined>;
    groupRevokeInvite: (jid: string) => Promise<string | undefined>;
    groupAcceptInvite: (code: string) => Promise<string | undefined>;
    groupRevokeInviteV4: (groupJid: string, invitedJid: string) => Promise<boolean>;
    groupAcceptInviteV4: (key: string | WAMessageKey, inviteMessage: proto.Message.IGroupInviteMessage) => Promise<any>;
    groupGetInviteInfo: (code: string) => Promise<import("../Types/index.js").GroupMetadata>;
    groupToggleEphemeral: (jid: string, ephemeralExpiration: number) => Promise<void>;
    groupSettingUpdate: (jid: string, setting: "announcement" | "not_announcement" | "locked" | "unlocked") => Promise<void>;
    groupMemberAddMode: (jid: string, mode: "admin_add" | "all_member_add") => Promise<void>;
    groupJoinApprovalMode: (jid: string, mode: "on" | "off") => Promise<void>;
    groupFetchAllParticipating: () => Promise<{
        [_: string]: import("../Types/index.js").GroupMetadata;
    }>;
    serverProps: {
        privacyTokenOn1to1: boolean;
        profilePicPrivacyToken: boolean;
        lidTrustedTokenIssueToLid: boolean;
    };
    createCallLink: (type: "audio" | "video", event?: {
        startTime: number;
    }, timeoutMs?: number) => Promise<string | undefined>;
    getBotListV2: () => Promise<import("../Types/index.js").BotListInfo[]>;
    messageMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    receiptMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    appStatePatchMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    notificationMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    upsertMessage: (msg: WAMessage, type: import("../Types/index.js").MessageUpsertType) => Promise<void>;
    appPatch: (patchCreate: import("../Types/index.js").WAPatchCreate) => Promise<void>;
    sendPresenceUpdate: (type: import("../Types/index.js").WAPresence, toJid?: string) => Promise<void>;
    presenceSubscribe: (toJid: string) => Promise<void>;
    fetchBlocklist: () => Promise<(string | undefined)[]>;
    fetchStatus: (...jids: string[]) => Promise<import("../WAUSync/index.js").USyncQueryResultList[] | undefined>;
    fetchTextStatus: (...jids: string[]) => Promise<import("../WAUSync/index.js").USyncQueryResultList[] | undefined>;
    fetchDisappearingDuration: (...jids: string[]) => Promise<import("../WAUSync/index.js").USyncQueryResultList[] | undefined>;
    updateProfilePicture: (jid: string, content: WAMediaUpload, dimensions?: {
        width: number;
        height: number;
    }) => Promise<void>;
    findUserId: (pnOrLid: string) => Promise<import("../index.js").UserIdLookup>;
    updatePanoramaProfilePicture: (jid: string, content: WAMediaUpload, opts?: {
        maxWidth?: number;
        quality?: number;
    }) => Promise<void>;
    removeProfilePicture: (jid: string) => Promise<void>;
    updateProfileStatus: (status: string | import("../Types/index.js").TextStatusInput) => Promise<void>;
    updateProfileAbout: (status: string | import("../Types/index.js").TextStatusInput) => Promise<void>;
    updateProfileName: (name: string) => Promise<void>;
    updateBlockStatus: (jid: string, action: "block" | "unblock") => Promise<void>;
    updateDisableLinkPreviewsPrivacy: (isPreviewsDisabled: boolean) => Promise<void>;
    updateCallPrivacy: (value: import("../Types/index.js").WAPrivacyCallValue) => Promise<void>;
    updateMessagesPrivacy: (value: import("../Types/index.js").WAPrivacyMessagesValue) => Promise<void>;
    updateLastSeenPrivacy: (value: import("../Types/index.js").WAPrivacyValue) => Promise<void>;
    updateOnlinePrivacy: (value: import("../Types/index.js").WAPrivacyOnlineValue) => Promise<void>;
    updateProfilePicturePrivacy: (value: import("../Types/index.js").WAPrivacyValue) => Promise<void>;
    updateStatusPrivacy: (value: import("../Types/index.js").WAPrivacyValue) => Promise<void>;
    updateReadReceiptsPrivacy: (value: import("../Types/index.js").WAReadReceiptsValue) => Promise<void>;
    updateGroupsAddPrivacy: (value: import("../Types/index.js").WAPrivacyGroupAddValue) => Promise<void>;
    updateDefaultDisappearingMode: (duration: number | string) => Promise<void>;
    updateDefaultDisappearing: (duration: number | string) => Promise<void>;
    updateDisappearingDuration: (duration: number | string) => Promise<void>;
    getBusinessProfile: (jid: string) => Promise<import("../Types/index.js").WABusinessProfile | void>;
    getBroadcastListInfo: (jid: string) => Promise<{
        name?: string;
        recipients: string[];
    }>;
    resyncAppState: (collections: readonly ("critical_unblock_low" | "regular_high" | "regular_low" | "critical_block" | "regular")[], isInitialSync: boolean) => Promise<void>;
    chatModify: (mod: import("../Types/index.js").ChatModification, jid: string) => Promise<void>;
    clearMessage: (jid: string, key: WAMessageKey, timeStamp: number | import("long").default) => Promise<void>;
    deleteChat: (jid: string, key: WAMessageKey, timeStamp: number | import("long").default) => Promise<void>;
    cleanDirtyBits: (type: "account_sync" | "groups", fromTimestamp?: number | string) => Promise<void>;
    addOrEditContact: (jid: string, contact: proto.SyncActionValue.IContactAction) => Promise<void>;
    removeContact: (jid: string) => Promise<void>;
    placeholderResendCache: import("../Types/index.js").CacheStore;
    addLabel: (jid: string, labels: import("../Types/Label.js").LabelActionBody) => Promise<void>;
    addChatLabel: (jid: string, labelId: string) => Promise<void>;
    removeChatLabel: (jid: string, labelId: string) => Promise<void>;
    addMessageLabel: (jid: string, messageId: string, labelId: string) => Promise<void>;
    removeMessageLabel: (jid: string, messageId: string, labelId: string) => Promise<void>;
    star: (jid: string, messages: {
        id: string;
        fromMe?: boolean;
    }[], star: boolean) => Promise<void>;
    addOrEditQuickReply: (quickReply: import("../Types/Bussines.js").QuickReplyAction) => Promise<void>;
    removeQuickReply: (timestamp: string) => Promise<void>;
    type: "md";
    ws: import("./Client/websocket.js").WebSocketClient;
    ev: import("../Types/index.js").BaileysEventEmitter & {
        process(handler: (events: Partial<import("../Types/index.js").BaileysEventMap>) => void | Promise<void>): () => void;
        buffer(): void;
        createBufferedFunction<A extends any[], T>(work: (...args: A) => Promise<T>): (...args: A) => Promise<T>;
        flush(): boolean;
        isBuffering(): boolean;
        destroy(): void;
        once<T extends keyof import("../Types/index.js").BaileysEventMap>(event: T, listener: (arg: import("../Types/index.js").BaileysEventMap[T]) => void): void;
        addListener<T extends keyof import("../Types/index.js").BaileysEventMap>(event: T, listener: (arg: import("../Types/index.js").BaileysEventMap[T]) => void): void;
        removeListener<T extends keyof import("../Types/index.js").BaileysEventMap>(event: T, listener: (arg: import("../Types/index.js").BaileysEventMap[T]) => void): void;
        setMaxListeners(count: number): void;
        getMaxListeners(): number;
        listenerCount(event: import("../Types/index.js").BaileysEvent): number;
        listeners(event: import("../Types/index.js").BaileysEvent): Function[];
        rawListeners(event: import("../Types/index.js").BaileysEvent): Function[];
        eventNames(): (string | symbol)[];
    };
    authState: {
        creds: import("../Types/index.js").AuthenticationCreds;
        keys: import("../Types/index.js").SignalKeyStoreWithTransaction;
    };
    signalRepository: import("../Types/index.js").SignalRepositoryWithLIDStore;
    user: import("../Types/index.js").Contact | undefined;
    connectionHealth: {
        lastMessageReceived: Date;
        consecutivePingFailures: number;
    };
    getLidUser: (jid: string) => Promise<{
        id: string;
        lid?: string;
    }[] | undefined>;
    generateMessageTag: () => string;
    query: (node: BinaryNode, timeoutMs?: number) => Promise<any>;
    waitForMessage: <T>(msgId: string, timeoutMs?: number | undefined) => Promise<T | undefined>;
    waitForSocketOpen: () => Promise<void>;
    sendRawMessage: (data: Uint8Array | Buffer) => Promise<void>;
    sendNode: (frame: BinaryNode) => Promise<void>;
    logout: (msg?: string) => Promise<void>;
    end: (error: Error | undefined) => Promise<void>;
    registerSocketEndHandler: (handler: (error: Error | undefined) => void | Promise<void>) => void;
    onUnexpectedError: (err: Error | Boom, msg: string) => void;
    uploadPreKeys: (count?: number) => Promise<void>;
    uploadPreKeysToServerIfRequired: () => Promise<void>;
    digestKeyBundle: () => Promise<void>;
    rotateSignedPreKey: () => Promise<void>;
    requestPairingCode: (phoneNumber: string, customPairingCode?: string) => Promise<string>;
    cancelPairingCode: () => boolean;
    updateServerTimeOffset: ({ attrs }: BinaryNode) => void;
    sendUnifiedSession: () => Promise<void>;
    wamBuffer: import("../index.js").BinaryInfo;
    waitForConnectionUpdate: (check: (u: Partial<import("../Types/index.js").ConnectionState>) => Promise<boolean | undefined>, timeoutMs?: number) => Promise<void>;
    sendWAMBuffer: (wamBuffer: Buffer) => Promise<any>;
    executeUSyncQuery: (usyncQuery: USyncQuery) => Promise<import("../WAUSync/index.js").USyncQueryResult | undefined>;
    onWhatsApp: (...targets: any[]) => Promise<(import("../Types/index.js").WAUsernameLookupResult | {
        jid: string;
        exists: boolean;
        lid: string | undefined;
        pn?: string;
    })[]>;
    onWhatsAppUsername: (...queries: import("../Types/index.js").WAUsernameQuery[]) => Promise<import("../Types/index.js").WAUsernameLookupResult[]>;
    usernameLookupOverride: {
        fn: ((...queries: import("../Types/index.js").WAUsernameQuery[]) => Promise<import("../Types/index.js").WAUsernameLookupResult[]>) | null;
    };
    fetchUsername: (...jids: string[]) => Promise<import("../Types/index.js").WAUsernameInfo[]>;
    fetchAccountReachoutTimelock: () => Promise<import("../Types/index.js").ReachoutTimelockState>;
    fetchNewChatMessageCap: () => Promise<import("../Types/index.js").NewChatMessageCap>;
};
//# sourceMappingURL=messages-send.d.ts.map