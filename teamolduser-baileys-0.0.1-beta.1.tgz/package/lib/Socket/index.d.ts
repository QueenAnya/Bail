import { type WebViewOptions, type WebViewResult } from '../Addons/webview.js';
import type { UserFacingSocketConfig } from '../Types/index.js';
import { type MergedVoipClient } from '../Voip/socket-client.js';
import type { MergedVoipClientOptions } from '../Voip/types.js';
declare const makeWASocket: (config: UserFacingSocketConfig) => {
    checkUsername: (username: string, includeSuggestions?: boolean) => Promise<import("./username.js").UsernameCheckResult>;
    checkUsernameMulti: (usernames: string[]) => Promise<any>;
    setUsername: (username: string, options?: import("./username.js").UsernameSetOptions) => Promise<any>;
    deleteUsername: () => Promise<any>;
    getMyUsername: () => Promise<string | null>;
    setUsernamePin: (pin: string) => Promise<any>;
    findUserByUsername: (username: string, pin?: string) => Promise<import("./username.js").UserByUsernameResult | null>;
    fetchContactUsernames: (...jids: string[]) => Promise<import("../index.js").USyncQueryResultList[]>;
    getUsernameRecommendations: (source?: keyof typeof import("./username.js").USERNAME_SOURCE | null) => Promise<any>;
    usernameCache: import("../index.js").PossiblyExtendedCacheStore | import("@cacheable/node-cache").NodeCache<unknown>;
    resolveUsername: (username: string) => Promise<import("../index.js").UsernameResolutionResult | null>;
    resolveUsernames: (usernames: string[]) => Promise<(import("../index.js").UsernameResolutionResult | null)[]>;
    invalidateUsername: (username: string) => Promise<void>;
    refreshUsername: (username: string) => Promise<import("../index.js").UsernameResolutionResult | null>;
    onWhatsAppUsername: (...queries: import("../index.js").WAUsernameQuery[]) => Promise<import("../index.js").WAUsernameLookupResult[]>;
    USERNAME_QUERY_IDS: {
        readonly CHECK: "26124072630599520";
        readonly CHECK_MULTI: "27134626522840290";
        readonly SET: "27108705368767936";
        readonly GET: "32618050064506056";
        readonly GET_RECOMMENDATIONS: "26077456248616956";
        readonly PIN_SET: "25529696019976770";
    };
    USERNAME_CHECK_RESULT: {
        readonly SUCCESS: "SUCCESS";
        readonly INVALID: "INVALID";
    };
    USERNAME_SOURCE: {
        readonly FB: "FB";
        readonly IG: "IG";
        readonly USER_INPUT: "USER_INPUT";
        readonly SUGGESTION: "SUGGESTION";
    };
    initiateCall: (jidOrPhoneNumber: string, opts?: import("../Voip/voip-engine.js").InitiateCallOptions) => Promise<import("../index.js").CallSession>;
    initiateCalls: (requests: Array<{
        jid: string;
        options?: import("../Voip/voip-engine.js").InitiateCallOptions;
    }>) => Promise<import("../index.js").CallSession[]>;
    getActiveCalls: () => Promise<import("../index.js").CallSummary[]>;
    getCall: (callId: string) => Promise<import("../index.js").CallSession | undefined>;
    getActiveCallCount: () => Promise<number>;
    endCall: (callId: string) => Promise<void>;
    endAllCalls: () => Promise<void>;
    setVoipOptions: (options: import("../index.js").VoipConfigOptions) => Promise<void>;
    getVoipMemoryStats: () => Promise<{
        process: {
            rssMb: number;
            heapUsedMb: number;
            heapTotalMb: number;
            externalMb: number;
        };
        calls: {
            activeCalls: number;
            waitingCalls: number;
            totalManagedCalls: number;
            maxConcurrentCalls: number | null;
        };
        resourceManager: {
            activeWorkers: number;
            activeRelayConnections: number;
            activeFfmpegProcesses: number;
            compiledModulesCached: number;
        };
    }>;
    getVoipClient: () => Promise<{
        readonly calls: Map<string, import("../index.js").CallSession>;
        getCall: (callId: string) => import("../index.js").CallSession | undefined;
        getActiveCalls: () => Promise<import("../index.js").CallSummary[]>;
        getActiveCallCount: () => Promise<number>;
        endCall: (callId: string) => Promise<void>;
        endAllCalls: () => Promise<void>;
        setOptions: (options: import("../index.js").VoipConfigOptions) => Promise<void>;
        getMemoryStats: () => Promise<{
            process: {
                rssMb: number;
                heapUsedMb: number;
                heapTotalMb: number;
                externalMb: number;
            };
            calls: {
                activeCalls: number;
                waitingCalls: number;
                totalManagedCalls: number;
                maxConcurrentCalls: number | null;
            };
            resourceManager: {
                activeWorkers: number;
                activeRelayConnections: number;
                activeFfmpegProcesses: number;
                compiledModulesCached: number;
            };
        }>;
    }>;
    disconnectVoip: () => void;
    acceptCall: (callId: string, callFromOrOptions?: string | import("../Voip/voip-engine.js").AcceptCallOptions, isVideo?: boolean, options?: import("../Voip/voip-engine.js").AcceptCallOptions) => Promise<any>;
    rejectCall: (callId: string, callFrom?: string, reason?: string) => Promise<any>;
    communityMetadata: (jid: string) => Promise<import("../index.js").GroupMetadata>;
    communityCreate: (subject: string, body: string) => Promise<import("../index.js").GroupMetadata | null>;
    communityCreateGroup: (subject: string, participants: string[], parentCommunityJid: string) => Promise<import("../index.js").GroupMetadata | null>;
    communityLeave: (id: string) => Promise<void>;
    communityUpdateSubject: (jid: string, subject: string) => Promise<void>;
    communityLinkGroup: (groupJid: string, parentCommunityJid: string) => Promise<void>;
    communityUnlinkGroup: (groupJid: string, parentCommunityJid: string) => Promise<void>;
    communityFetchLinkedGroups: (jid: string) => Promise<{
        communityJid: string;
        isCommunity: boolean;
        linkedGroups: {
            id: string | undefined;
            subject: string;
            creation: number | undefined;
            owner: string | undefined;
            size: number | undefined;
        }[];
    }>;
    communityRequestParticipantsList: (jid: string) => Promise<{
        [key: string]: string;
    }[]>;
    communityRequestParticipantsUpdate: (jid: string, participants: string[], action: "approve" | "reject") => Promise<{
        status: string;
        jid: string | undefined;
    }[]>;
    communityParticipantsUpdate: (jid: string, participants: string[], action: import("../index.js").ParticipantAction) => Promise<{
        status: string;
        jid: string | undefined;
        content: import("../index.js").BinaryNode;
    }[]>;
    communityUpdateDescription: (jid: string, description?: string) => Promise<void>;
    communityInviteCode: (jid: string) => Promise<string | undefined>;
    communityRevokeInvite: (jid: string) => Promise<string | undefined>;
    communityAcceptInvite: (code: string) => Promise<string | undefined>;
    communityRevokeInviteV4: (communityJid: string, invitedJid: string) => Promise<boolean>;
    communityAcceptInviteV4: (key: string | import("../index.js").WAMessageKey, inviteMessage: import("../index.js").proto.Message.IGroupInviteMessage) => Promise<any>;
    communityGetInviteInfo: (code: string) => Promise<import("../index.js").GroupMetadata>;
    communityToggleEphemeral: (jid: string, ephemeralExpiration: number) => Promise<void>;
    communitySettingUpdate: (jid: string, setting: "announcement" | "not_announcement" | "locked" | "unlocked") => Promise<void>;
    communityMemberAddMode: (jid: string, mode: "admin_add" | "all_member_add") => Promise<void>;
    communityJoinApprovalMode: (jid: string, mode: "on" | "off") => Promise<void>;
    communityFetchAllParticipating: () => Promise<{
        [_: string]: import("../index.js").GroupMetadata;
    }>;
    logger: import("../Utils/logger.js").ILogger;
    getOrderDetails: (orderId: string, tokenBase64: string, jid?: string) => Promise<import("../index.js").OrderDetails>;
    getCatalog: ({ jid, limit, cursor }: import("../index.js").GetCatalogOptions) => Promise<{
        products: import("../index.js").Product[];
        nextPageCursor: string | undefined;
    }>;
    getCollections: (jid?: string, limit?: number) => Promise<{
        collections: import("../index.js").CatalogCollection[];
    }>;
    productCreate: (create: import("../index.js").ProductCreate) => Promise<import("../index.js").Product>;
    productDelete: (productIds: string[]) => Promise<{
        deleted: number;
    }>;
    productUpdate: (productId: string, update: import("../index.js").ProductUpdate) => Promise<import("../index.js").Product>;
    updateBussinesProfile: (args: import("../Types/Bussines.js").UpdateBussinesProfileProps) => Promise<any>;
    updateBusinessProfile: (args: import("../Types/Bussines.js").UpdateBussinesProfileProps) => Promise<any>;
    updateCoverPhoto: (photo: import("../index.js").WAMediaUpload) => Promise<number>;
    removeCoverPhoto: (id: string) => Promise<any>;
    sendMessageAck: (node: import("../index.js").BinaryNode, errorCode?: number) => Promise<void>;
    sendRetryRequest: (node: import("../index.js").BinaryNode, forceIncludeKeys?: boolean) => Promise<void>;
    offerCall: (toJid: string, isVideo?: boolean) => Promise<{
        id: string;
        to: string;
    }>;
    WAInitiateCall: (jid: string, options?: import("../index.js").WAInitiateCallOptions) => Promise<import("../index.js").WAInitiateCallResult>;
    cancelCall: (callId: string, callTo: string) => Promise<void>;
    preacceptCall: (callId: string, callCreator: string, isVideo?: boolean) => Promise<void>;
    terminateCall: (callId: string, callTo: string, callCreator?: string, reason?: string, duration?: number) => Promise<void>;
    sendRelayLatency: (callId: string, callCreator: string, relays: Array<{
        relayName?: string;
        latency: number;
        relayId?: string;
        dlBw?: number;
        ulBw?: number;
    }>, transactionId?: string) => Promise<void>;
    sendTransport: (callId: string, callCreator: string, to: string, candidates: Array<{
        priority: string;
        data: Uint8Array;
    }>, round?: number) => Promise<void>;
    sendCallDuration: (callId: string, callCreator: string, peer: string, audioDuration: number, callType?: string) => Promise<void>;
    muteCall: (callId: string, callCreator: string, to: string, muted: boolean) => Promise<void>;
    unmuteCall: (callId: string, callCreator: string, to: string) => Promise<void>;
    sendHeartbeat: (callId: string, callCreator: string) => Promise<void>;
    sendEncRekey: (callId: string, callCreator: string, to: string, transactionId: string) => Promise<void>;
    sendVideoState: (callId: string, callCreator: string, to: string, enabled: boolean, orientation?: string) => Promise<void>;
    queryCallLink: (token: string, media?: string) => Promise<any>;
    joinCallLink: (token: string, media?: string) => Promise<any>;
    fetchMessageHistory: (count: number, oldestMsgKey: import("../index.js").WAMessageKey, oldestMsgTimestamp: number | import("long").default) => Promise<string>;
    requestPlaceholderResend: (messageKey: import("../index.js").WAMessageKey, msgData?: Partial<import("../index.js").WAMessage>) => Promise<string | undefined>;
    messageRetryManager: import("../index.js").MessageRetryManager | null;
    userDevicesCache: import("../index.js").PossiblyExtendedCacheStore | import("@cacheable/node-cache").NodeCache<import("../index.js").JidWithDevice[]>;
    outboundResendCache: import("../index.js").PossiblyExtendedCacheStore | import("@cacheable/node-cache").NodeCache<{
        jid: string;
        message: import("../index.js").proto.IMessage;
    }>;
    devicesMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    issuePrivacyTokens: (jids: string[], timestamp?: number) => Promise<any>;
    assertSessions: (jids: string[], force?: boolean) => Promise<boolean>;
    relayMessage: (jid: string, message: import("../index.js").proto.IMessage, { messageId: msgId, participant, additionalAttributes, additionalNodes, useUserDevicesCache, useCachedGroupMetadata, statusJidList, AI, secureMetaServiceLabel }: import("../index.js").MessageRelayOptions & {
        AI?: boolean;
        secureMetaServiceLabel?: boolean;
    }) => Promise<string>;
    sendReceipt: (jid: string, participant: string | undefined, messageIds: string[], type: import("../index.js").MessageReceiptType) => Promise<void>;
    profilePictureUrl: (jid: string, type?: "preview" | "image", timeoutMs?: number) => Promise<string | undefined>;
    getEphemeralGroup: (jid: string) => Promise<number | string>;
    sendReceipts: (keys: import("../index.js").WAMessageKey[], type: import("../index.js").MessageReceiptType) => Promise<void>;
    readMessages: (keys: import("../index.js").WAMessageKey[]) => Promise<void>;
    markIdentityChanged: (jid: string) => void;
    recentlyChangedIdentities: Map<string, NodeJS.Timeout>;
    refreshMediaConn: (forceGet?: boolean) => Promise<import("../index.js").MediaConnInfo>;
    getMediaHost: () => string;
    waUploadToServer: import("../index.js").WAMediaUploadFunction;
    fetchPrivacySettings: (force?: boolean) => Promise<{
        [_: string]: string;
    }>;
    sendPeerDataOperationMessage: (pdoMessage: import("../index.js").proto.Message.IPeerDataOperationRequestMessage) => Promise<string>;
    requestPhoneLinkPreview: (url: string) => Promise<string>;
    createParticipantNodes: (recipientJids: string[], message: import("../index.js").proto.IMessage, extraAttrs?: import("../index.js").BinaryNode["attrs"], dsmMessage?: import("../index.js").proto.IMessage) => Promise<{
        nodes: import("../index.js").BinaryNode[];
        shouldIncludeDeviceIdentity: boolean;
    }>;
    getUSyncDevices: (jids: string[], useCache: boolean, ignoreZeroDevices: boolean) => Promise<(import("../index.js").JidWithDevice & {
        jid: string;
    })[]>;
    updateMemberLabel: (jid: string, memberLabel: string) => Promise<string>;
    updateMediaMessage: (message: import("../index.js").WAMessage) => Promise<import("../index.js").WAMessage>;
    sendGroupStatus: (groupJid: string, content: Record<string, any>, options?: Record<string, any>) => Promise<import("../index.js").WAMessage>;
    sendGroupStatusV2: (groupJid: string, content: import("../index.js").AnyMessageContent, options?: Record<string, any>) => Promise<import("../index.js").WAMessage>;
    sendGroupV4Invite: (groupJid: string, participant: string, inviteCode: string, inviteExpiration?: number, groupName?: string, caption?: string, jpegThumbnail?: Buffer, options?: import("../index.js").MiscMessageGenerationOptions) => Promise<import("../index.js").WAMessage>;
    sendGroupInviteV4: (groupJid: string, participant: string, inviteCode: string, inviteExpiration?: number, groupName?: string, caption?: string, jpegThumbnail?: Buffer, options?: import("../index.js").MiscMessageGenerationOptions) => Promise<import("../index.js").WAMessage>;
    sendGroupInvite: (groupJid: string, user: string) => Promise<import("../index.js").GroupInviteAttemptResult[]>;
    monitorPresence: (targets: string | string[], options?: import("../index.js").PresenceMonitorOptions) => import("../index.js").PresenceMonitor;
    sendMessage: (jid: string | string[], content: import("../index.js").AnyMessageContent, options?: import("../index.js").MiscMessageGenerationOptions) => Promise<import("../index.js").WAMessage | undefined>;
    sendStickerPack: (jid: string, stickerPack: import("../index.js").StickerPackInput, options?: import("../index.js").MiscMessageGenerationOptions & {
        mediaCache?: import("../index.js").StickerPackOptions["mediaCache"];
    }) => Promise<string>;
    resize: (media: import("../index.js").WAMediaUpload | string, width?: number, height?: number) => Promise<Buffer>;
    copyNForward: (jid: string, message: import("../index.js").WAMessage, forceForward?: boolean | number, options?: import("../index.js").MiscMessageGenerationOptions) => Promise<any>;
    sendStatusMentions: (content: import("../index.js").AnyMessageContent, jids?: string[]) => Promise<import("../index.js").WAMessage>;
    sendTable: (jid: string, title: string, headers: string[], rows: string[][], quoted?: any, options?: {
        headerText?: string;
        footer?: string;
    }) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendList: (jid: string, title: string, items: string[] | string[][], quoted?: any, options?: {
        headerText?: string;
        footer?: string;
    }) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendCodeBlock: (jid: string, code: string, quoted?: any, options?: {
        title?: string;
        footer?: string;
        language?: string;
    }) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendRichHtml: (jid: string, htmlOrOptions: string | (import("../index.js").GenerateRichHtmlOptions & {
        html: string;
    }), quoted?: any, options?: import("../index.js").GenerateRichHtmlOptions) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendLatex: (jid: string, quoted: any, options: {
        text?: string;
        expressions: import("../index.js").LatexExpression[];
        headerText?: string;
        footer?: string;
    }) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendLatexImage: (jid: string, quoted?: any, options?: any, renderLatexToPng?: (latexExpr: string) => Promise<{
        buffer: Buffer;
        width: number;
        height: number;
    }>, uploadFn?: (buffer: Buffer, type: string) => Promise<{
        url?: string;
        directPath?: string;
    }>) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendLatexNativeImage: (jid: string, quoted?: any, options?: any, renderLatexToPng?: (latexExpr: string) => Promise<{
        buffer: Buffer;
        width: number;
        height: number;
    }>, uploadFn?: (buffer: Buffer, type: string) => Promise<{
        url?: string;
        directPath?: string;
    }>) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendLatexInlineImage: (jid: string, quoted?: any, options?: any, renderLatexToPng?: (latexExpr: string) => Promise<{
        buffer: Buffer;
        width: number;
        height: number;
    }>, uploadFn?: (buffer: Buffer, type: string) => Promise<{
        url?: string;
        directPath?: string;
    }>) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendMarkdown: (jid: string, markdown: string, quoted?: any, options?: import("../index.js").ExtractOptions) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendLinkPreviewFor: (jid: string, url: string, textOrOptions?: string | ({
        text?: string;
    } & Partial<import("../index.js").WAUrlInfo>), sendOptions?: import("../index.js").MiscMessageGenerationOptions) => Promise<any>;
    sendRichMessage: (jid: string, submessages: import("../index.js").RichSubMessage[], quoted?: any, options?: import("../index.js").GenerateRichMessageOptions) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    extractUnifiedResponse: (msg: import("../index.js").proto.IMessage | null | undefined) => import("../index.js").CapturedUnifiedResponse | null;
    captureUnifiedResponse: (msg: import("../index.js").proto.IMessage | null | undefined) => import("../index.js").CapturedUnifiedResponse | null;
    sendUnifiedResponse: (jid: string, quoted: any, captured: import("../index.js").CapturedUnifiedResponse) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    GroupStatus: (groupJid: string, content: Record<string, any>, options?: Record<string, any>) => Promise<import("../index.js").WAMessage>;
    GroupStatusV2: (groupJid: string, content: import("../index.js").AnyMessageContent, options?: Record<string, any>) => Promise<import("../index.js").WAMessage>;
    newsletterWMexQuery: (variables: Record<string, unknown> | undefined, queryId: string, options: Record<string, unknown>) => Promise<import("../index.js").BinaryNode>;
    newsletterCreate: (name: string, description?: string) => Promise<import("../index.js").NewsletterMetadata>;
    newsletterUpdate: (jid: string, updates: import("../index.js").NewsletterUpdate) => Promise<unknown>;
    newsletterFetchAllParticipating: () => Promise<unknown>;
    newsletterSubscribers: (jid: string, options?: {
        count?: number;
    }) => Promise<{
        id: string | undefined;
        phoneNumber: string | undefined;
        displayName: string | undefined;
        username: string | undefined;
        role: string | undefined;
        followTime: string | undefined;
    }[]>;
    newsletterMetadata: (type: "invite" | "jid", key: string, options?: {
        fetchCreationTime?: boolean;
        fetchFullImage?: boolean;
        fetchViewerMetadata?: boolean;
        fetchPinnedMessages?: boolean;
        fetchStatusMetadata?: boolean;
        fetchWamoSub?: boolean;
        viewRole?: string;
    }) => Promise<import("../index.js").NewsletterMetadata | null>;
    newsletterAction: (jid: string, type: keyof typeof import("../index.js").QueryIds) => Promise<void>;
    newsletterFollow: (jid: string) => Promise<unknown>;
    newsletterUnfollow: (jid: string) => Promise<unknown>;
    newsletterMute: (jid: string) => Promise<{
        id: string;
        state: string | undefined;
    }>;
    newsletterUnmute: (jid: string) => Promise<{
        id: string;
        state: string | undefined;
    }>;
    newsletterMuteLegacy: (jid: string) => Promise<unknown>;
    newsletterUnmuteLegacy: (jid: string) => Promise<unknown>;
    newsletterUpdateName: (jid: string, name: string) => Promise<unknown>;
    newsletterUpdateDescription: (jid: string, description: string) => Promise<unknown>;
    newsletterUpdatePicture: (jid: string, content: import("../index.js").WAMediaUpload) => Promise<unknown>;
    newsletterRemovePicture: (jid: string) => Promise<unknown>;
    newsletterReactMessage: (jid: string, serverId: string, reaction?: string) => Promise<void>;
    newsletterFetchMessages: (jid: string, count: number, since: number, after: number) => Promise<any>;
    subscribeNewsletterUpdates: (jid: string) => Promise<{
        duration: string;
    } | null>;
    newsletterAdminCount: (jid: string) => Promise<number>;
    newsletterChangeOwner: (jid: string, newOwnerJid: string) => Promise<void>;
    newsletterDemote: (jid: string, userJid: string) => Promise<void>;
    newsletterDelete: (jid: string) => Promise<void>;
    newsletterSubscribed: (options?: {
        fetchStatusMetadata?: boolean;
        fetchWamoSub?: boolean;
    }) => Promise<unknown>;
    newsletterReactionMode: (jid: string, mode: string) => Promise<void>;
    newsletterUpdateUserSetting: (jid: string, type: string, value: boolean) => Promise<{
        id: string;
        state: string | undefined;
    }>;
    newsletterUpdateReactions: (jid: string, setting: string) => Promise<unknown>;
    newsletterFetchMessageUpdates: (jid: string, options?: Record<string, any>) => Promise<{
        jid: string;
        messages: any[];
    }>;
    newsletterQuestionResponses: (jid: string, serverId: string, options?: Record<string, any>) => Promise<{
        jid: any;
        serverId: number;
        responses: {
            id: string | undefined;
            t: number | undefined;
            isSender: boolean;
            responseServerId: string | undefined;
            sender: {
                lid: string | undefined;
                notifyName: string | undefined;
                pictureDirectPath: string | undefined;
            };
            replied: boolean;
            starred: boolean;
            message: any;
        }[];
    }>;
    newsletterMyAddOns: (options?: Record<string, any>) => Promise<any[]>;
    newsletterStatusMyAddOns: (options?: Record<string, any>) => Promise<any[]>;
    newsletterAdminCapabilities: (jid: string) => Promise<any>;
    newsletterEnforcements: (jid: string, locale?: string) => Promise<{
        adminProfiles: any;
        profilePictureDeletions: any;
        suspensions: any;
        violatingMessages: any[];
        geoSuspensions: any[];
    }>;
    newsletterReports: (locale?: string) => Promise<any>;
    newsletterAppealReport: (reportId: string, reason: string) => Promise<unknown>;
    newsletterCanPostStatus: (jid: string) => Promise<{
        canPost: any;
        canPostMusic: any;
        capabilities: any;
    }>;
    newsletterAdminInfo: (jid: string) => Promise<{
        id: any;
        adminCount: any;
        adminProfile: {
            id: any;
            name: any;
            picture: {
                id: any;
                directPath: any;
            } | undefined;
        } | undefined;
        adminProfilesEnabled: any;
    }>;
    newsletterPollVoters: (jid: string, serverId: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterReactionSenders: (jid: string, serverId: string) => Promise<unknown>;
    newsletterPinMessages: (jid: string, serverIds: string | string[]) => Promise<unknown>;
    newsletterUnpinMessages: (jid: string, serverIds: string | string[]) => Promise<unknown>;
    newsletterLabelAiContent: (jid: string, serverId: string, messageType?: string) => Promise<unknown>;
    newsletterLabelPaidPartnership: (jid: string, serverId: string, messageType?: string) => Promise<unknown>;
    newsletterCreateAdminInvite: (jid: string, userJid: string) => Promise<unknown>;
    newsletterRevokeAdminInvite: (jid: string, userJid: string) => Promise<unknown>;
    newsletterAcceptAdminInvite: (jid: string) => Promise<unknown>;
    newsletterDirectoryList: (options?: Record<string, any>) => Promise<unknown>;
    newsletterDirectorySearch: (searchText: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterDirectoryCategories: (options?: Record<string, any>) => Promise<unknown>;
    newsletterSendPollVote: (jid: string, parentServerId: string, options: Record<string, any>) => Promise<{
        id: string;
    }>;
    newsletterInsights: (jid: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterFollowers: (jid: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterPendingAdminInvites: (jid: string) => Promise<any>;
    newsletterQuestionResponseState: (jid: string, serverId: string, responseServerId: string, state: string) => Promise<unknown>;
    newsletterRecommended: (options?: Record<string, any>) => Promise<unknown>;
    newsletterSimilar: (jid: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterFetchUpdates: (jid: string, count: number, after?: number, since?: number) => Promise<any>;
    groupMetadata: (jid: string) => Promise<import("../index.js").GroupMetadata>;
    groupCreate: (subject: string, participants: string[]) => Promise<import("../index.js").GroupMetadata>;
    groupLeave: (id: string) => Promise<void>;
    groupUpdateSubject: (jid: string, subject: string) => Promise<void>;
    groupRequestParticipantsList: (jid: string) => Promise<{
        [key: string]: string;
    }[]>;
    groupRequestParticipantsUpdate: (jid: string, participants: string[], action: "approve" | "reject") => Promise<{
        status: string;
        jid: string | undefined;
    }[]>;
    groupParticipantsUpdate: (jid: string, participants: string[], action: import("../index.js").ParticipantAction) => Promise<{
        status: string;
        jid: string | undefined;
        content: import("../index.js").BinaryNode;
    }[]>;
    groupUpdateDescription: (jid: string, description?: string) => Promise<void>;
    groupInviteCode: (jid: string) => Promise<string | undefined>;
    groupRevokeInvite: (jid: string) => Promise<string | undefined>;
    groupAcceptInvite: (code: string) => Promise<string | undefined>;
    groupRevokeInviteV4: (groupJid: string, invitedJid: string) => Promise<boolean>;
    groupAcceptInviteV4: (key: string | import("../index.js").WAMessageKey, inviteMessage: import("../index.js").proto.Message.IGroupInviteMessage) => Promise<any>;
    groupGetInviteInfo: (code: string) => Promise<import("../index.js").GroupMetadata>;
    groupToggleEphemeral: (jid: string, ephemeralExpiration: number) => Promise<void>;
    groupSettingUpdate: (jid: string, setting: "announcement" | "not_announcement" | "locked" | "unlocked") => Promise<void>;
    groupMemberAddMode: (jid: string, mode: "admin_add" | "all_member_add") => Promise<void>;
    groupJoinApprovalMode: (jid: string, mode: "on" | "off") => Promise<void>;
    groupFetchAllParticipating: () => Promise<{
        [_: string]: import("../index.js").GroupMetadata;
    }>;
    serverProps: {
        privacyTokenOn1to1: boolean;
        profilePicPrivacyToken: boolean;
        lidTrustedTokenIssueToLid: boolean;
    };
    createCallLink: (type: "audio" | "video", event?: {
        startTime: number;
    }, timeoutMs?: number) => Promise<string | undefined>;
    getBotListV2: () => Promise<import("../index.js").BotListInfo[]>;
    messageMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    receiptMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    appStatePatchMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    notificationMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    upsertMessage: (msg: import("../index.js").WAMessage, type: import("../index.js").MessageUpsertType) => Promise<void>;
    appPatch: (patchCreate: import("../index.js").WAPatchCreate) => Promise<void>;
    sendPresenceUpdate: (type: import("../index.js").WAPresence, toJid?: string) => Promise<void>;
    presenceSubscribe: (toJid: string) => Promise<void>;
    fetchBlocklist: () => Promise<(string | undefined)[]>;
    fetchStatus: (...jids: string[]) => Promise<import("../index.js").USyncQueryResultList[] | undefined>;
    fetchTextStatus: (...jids: string[]) => Promise<import("../index.js").USyncQueryResultList[] | undefined>;
    fetchDisappearingDuration: (...jids: string[]) => Promise<import("../index.js").USyncQueryResultList[] | undefined>;
    updateProfilePicture: (jid: string, content: import("../index.js").WAMediaUpload, dimensions?: {
        width: number;
        height: number;
    }) => Promise<void>;
    findUserId: (pnOrLid: string) => Promise<import("../index.js").UserIdLookup>;
    updatePanoramaProfilePicture: (jid: string, content: import("../index.js").WAMediaUpload, opts?: {
        maxWidth?: number;
        quality?: number;
    }) => Promise<void>;
    removeProfilePicture: (jid: string) => Promise<void>;
    updateProfileStatus: (status: string | import("../index.js").TextStatusInput) => Promise<void>;
    updateProfileAbout: (status: string | import("../index.js").TextStatusInput) => Promise<void>;
    updateProfileName: (name: string) => Promise<void>;
    updateBlockStatus: (jid: string, action: "block" | "unblock") => Promise<void>;
    updateDisableLinkPreviewsPrivacy: (isPreviewsDisabled: boolean) => Promise<void>;
    updateCallPrivacy: (value: import("../index.js").WAPrivacyCallValue) => Promise<void>;
    updateMessagesPrivacy: (value: import("../index.js").WAPrivacyMessagesValue) => Promise<void>;
    updateLastSeenPrivacy: (value: import("../index.js").WAPrivacyValue) => Promise<void>;
    updateOnlinePrivacy: (value: import("../index.js").WAPrivacyOnlineValue) => Promise<void>;
    updateProfilePicturePrivacy: (value: import("../index.js").WAPrivacyValue) => Promise<void>;
    updateStatusPrivacy: (value: import("../index.js").WAPrivacyValue) => Promise<void>;
    updateReadReceiptsPrivacy: (value: import("../index.js").WAReadReceiptsValue) => Promise<void>;
    updateGroupsAddPrivacy: (value: import("../index.js").WAPrivacyGroupAddValue) => Promise<void>;
    updateDefaultDisappearingMode: (duration: number | string) => Promise<void>;
    updateDefaultDisappearing: (duration: number | string) => Promise<void>;
    updateDisappearingDuration: (duration: number | string) => Promise<void>;
    getBusinessProfile: (jid: string) => Promise<import("../index.js").WABusinessProfile | void>;
    getBroadcastListInfo: (jid: string) => Promise<{
        name?: string;
        recipients: string[];
    }>;
    resyncAppState: (collections: readonly ("critical_unblock_low" | "regular_high" | "regular_low" | "critical_block" | "regular")[], isInitialSync: boolean) => Promise<void>;
    chatModify: (mod: import("../index.js").ChatModification, jid: string) => Promise<void>;
    clearMessage: (jid: string, key: import("../index.js").WAMessageKey, timeStamp: number | import("long").default) => Promise<void>;
    deleteChat: (jid: string, key: import("../index.js").WAMessageKey, timeStamp: number | import("long").default) => Promise<void>;
    cleanDirtyBits: (type: "account_sync" | "groups", fromTimestamp?: number | string) => Promise<void>;
    addOrEditContact: (jid: string, contact: import("../index.js").proto.SyncActionValue.IContactAction) => Promise<void>;
    removeContact: (jid: string) => Promise<void>;
    placeholderResendCache: import("../index.js").CacheStore;
    addLabel: (jid: string, labels: import("../Types/Label.js").LabelActionBody) => Promise<void>;
    addChatLabel: (jid: string, labelId: string) => Promise<void>;
    removeChatLabel: (jid: string, labelId: string) => Promise<void>;
    addMessageLabel: (jid: string, messageId: string, labelId: string) => Promise<void>;
    removeMessageLabel: (jid: string, messageId: string, labelId: string) => Promise<void>;
    star: (jid: string, messages: {
        id: string;
        fromMe?: boolean;
    }[], star: boolean) => Promise<void>;
    addOrEditQuickReply: (quickReply: import("../Types/Bussines.js").QuickReplyAction) => Promise<void>;
    removeQuickReply: (timestamp: string) => Promise<void>;
    type: "md";
    ws: import("./Client/index.js").WebSocketClient;
    ev: import("../index.js").BaileysEventEmitter & {
        process(handler: (events: Partial<import("../index.js").BaileysEventMap>) => void | Promise<void>): () => void;
        buffer(): void;
        createBufferedFunction<A extends any[], T>(work: (...args: A) => Promise<T>): (...args: A) => Promise<T>;
        flush(): boolean;
        isBuffering(): boolean;
        destroy(): void;
        once<T extends keyof import("../index.js").BaileysEventMap>(event: T, listener: (arg: import("../index.js").BaileysEventMap[T]) => void): void;
        addListener<T extends keyof import("../index.js").BaileysEventMap>(event: T, listener: (arg: import("../index.js").BaileysEventMap[T]) => void): void;
        removeListener<T extends keyof import("../index.js").BaileysEventMap>(event: T, listener: (arg: import("../index.js").BaileysEventMap[T]) => void): void;
        setMaxListeners(count: number): void;
        getMaxListeners(): number;
        listenerCount(event: import("../index.js").BaileysEvent): number;
        listeners(event: import("../index.js").BaileysEvent): Function[];
        rawListeners(event: import("../index.js").BaileysEvent): Function[];
        eventNames(): (string | symbol)[];
    };
    authState: {
        creds: import("../index.js").AuthenticationCreds;
        keys: import("../index.js").SignalKeyStoreWithTransaction;
    };
    signalRepository: import("../index.js").SignalRepositoryWithLIDStore;
    user: import("../index.js").Contact | undefined;
    connectionHealth: {
        lastMessageReceived: Date;
        consecutivePingFailures: number;
    };
    getLidUser: (jid: string) => Promise<{
        id: string;
        lid?: string;
    }[] | undefined>;
    generateMessageTag: () => string;
    query: (node: import("../index.js").BinaryNode, timeoutMs?: number) => Promise<any>;
    waitForMessage: <T>(msgId: string, timeoutMs?: number | undefined) => Promise<T | undefined>;
    waitForSocketOpen: () => Promise<void>;
    sendRawMessage: (data: Uint8Array | Buffer) => Promise<void>;
    sendNode: (frame: import("../index.js").BinaryNode) => Promise<void>;
    logout: (msg?: string) => Promise<void>;
    end: (error: Error | undefined) => Promise<void>;
    registerSocketEndHandler: (handler: (error: Error | undefined) => void | Promise<void>) => void;
    onUnexpectedError: (err: Error | import("@hapi/boom").Boom, msg: string) => void;
    uploadPreKeys: (count?: number) => Promise<void>;
    uploadPreKeysToServerIfRequired: () => Promise<void>;
    digestKeyBundle: () => Promise<void>;
    rotateSignedPreKey: () => Promise<void>;
    requestPairingCode: (phoneNumber: string, customPairingCode?: string) => Promise<string>;
    cancelPairingCode: () => boolean;
    updateServerTimeOffset: ({ attrs }: import("../index.js").BinaryNode) => void;
    sendUnifiedSession: () => Promise<void>;
    wamBuffer: import("../index.js").BinaryInfo;
    waitForConnectionUpdate: (check: (u: Partial<import("../index.js").ConnectionState>) => Promise<boolean | undefined>, timeoutMs?: number) => Promise<void>;
    sendWAMBuffer: (wamBuffer: Buffer) => Promise<any>;
    executeUSyncQuery: (usyncQuery: import("../index.js").USyncQuery) => Promise<import("../index.js").USyncQueryResult | undefined>;
    onWhatsApp: (...targets: any[]) => Promise<(import("../index.js").WAUsernameLookupResult | {
        jid: string;
        exists: boolean;
        lid: string | undefined;
        pn?: string;
    })[]>;
    usernameLookupOverride: {
        fn: ((...queries: import("../index.js").WAUsernameQuery[]) => Promise<import("../index.js").WAUsernameLookupResult[]>) | null;
    };
    fetchUsername: (...jids: string[]) => Promise<import("../index.js").WAUsernameInfo[]>;
    fetchAccountReachoutTimelock: () => Promise<import("../index.js").ReachoutTimelockState>;
    fetchNewChatMessageCap: () => Promise<import("../index.js").NewChatMessageCap>;
} & {
    newsletterUpdateUserSetting: (jid: string, type: import("../index.js").NewsletterUserSettingType, muted: boolean) => Promise<{
        id: any;
        state: any;
    }>;
    newsletterUpdateReactions: (jid: string, setting: string) => Promise<any>;
    newsletterFetchMessageUpdates: (jid: string, options?: {
        count?: number;
        since?: number;
        before?: number;
        after?: number;
    }) => Promise<{
        jid: string;
        messages: any[];
    }>;
    newsletterQuestionResponses: (jid: string, serverId: string | number, options?: {
        count?: number;
        before?: number;
        filter?: string;
        searchText?: string;
    }) => Promise<{
        jid: string;
        serverId: number;
        responses: {
            id: string | undefined;
            t: number | undefined;
            isSender: boolean;
            responseServerId: string | undefined;
            sender: {
                lid: string | undefined;
                notifyName: string | undefined;
                pictureDirectPath: string | undefined;
            };
            replied: boolean;
            starred: boolean;
            message: {
                [k: string]: any;
            } | undefined;
        }[];
    }>;
    newsletterMyAddOns: (options?: {
        limit?: number;
        jid?: string;
    }) => Promise<{
        jid: string | undefined;
        messages: {
            serverId: number | undefined;
            reaction: {
                code: string | undefined;
                t: number | undefined;
            } | undefined;
            pollVote: {
                t: number | undefined;
                hashes: string[];
            } | undefined;
        }[];
    }[]>;
    newsletterStatusMyAddOns: (options?: {
        limit?: number;
        jid?: string;
    }) => Promise<{
        jid: string | undefined;
        messages: {
            serverId: number | undefined;
            reaction: {
                code: string | undefined;
                t: number | undefined;
            } | undefined;
            pollVote: {
                t: number | undefined;
                hashes: string[];
            } | undefined;
        }[];
    }[]>;
    newsletterAdminCapabilities: (jid: string) => Promise<string[]>;
    newsletterEnforcements: (jid: string, locale?: string) => Promise<{
        adminProfiles: any;
        profilePictureDeletions: any;
        suspensions: any;
        violatingMessages: {
            enforcementId: any;
            createdAt: number | undefined;
            violationCategory: any;
            source: any;
            appealState: any;
            appealCreatedAt: number | undefined;
            appealReasonOptions: any;
            appealFormUrl: any;
            policy: {
                headline: any;
                subtitle: any;
                overview: any;
                explanation: any;
                adminDisclaimer: any;
            } | undefined;
        }[];
        geoSuspensions: {
            enforcementId: any;
            createdAt: number | undefined;
            violationCategory: any;
            source: any;
            appealState: any;
            appealCreatedAt: number | undefined;
            appealReasonOptions: any;
            appealFormUrl: any;
            policy: {
                headline: any;
                subtitle: any;
                overview: any;
                explanation: any;
                adminDisclaimer: any;
            } | undefined;
        }[];
    }>;
    newsletterReports: (locale?: string) => Promise<any>;
    newsletterAppealReport: (reportId: string | number, reason: string) => Promise<any>;
    newsletterCanPostStatus: (jid: string) => Promise<{
        canPost: boolean;
        canPostMusic: boolean;
        capabilities: string[];
    }>;
    newsletterAdminInfo: (jid: string) => Promise<{
        id: any;
        adminCount: any;
        adminProfile: {
            id: any;
            name: any;
            picture: {
                id: any;
                directPath: any;
            } | undefined;
        } | undefined;
        adminProfilesEnabled: any;
    }>;
    newsletterPollVoters: (jid: string, serverId: string | number, options?: {
        limit?: number;
        voteHash?: string;
    }) => Promise<any>;
    newsletterReactionSenders: (jid: string, serverId: string | number) => Promise<any>;
    newsletterPinMessages: (jid: string, serverIds: string | number | (string | number)[]) => Promise<any>;
    newsletterUnpinMessages: (jid: string, serverIds: string | number | (string | number)[]) => Promise<any>;
    newsletterLabelAiContent: (jid: string, serverId: string | number, messageType?: string) => Promise<any>;
    newsletterLabelPaidPartnership: (jid: string, serverId: string | number, messageType?: string) => Promise<any>;
    newsletterCreateAdminInvite: (jid: string, userJid: string) => Promise<any>;
    newsletterRevokeAdminInvite: (jid: string, userJid: string) => Promise<any>;
    newsletterAcceptAdminInvite: (jid: string) => Promise<any>;
    newsletterDirectoryList: (options?: {
        fetchStatusMetadata?: boolean;
        view?: string;
        countryCodes?: string[];
        categories?: string[];
        limit?: number;
        cursorToken?: string;
    }) => Promise<any>;
    newsletterDirectorySearch: (searchText: string, options?: {
        fetchStatusMetadata?: boolean;
        categories?: string[];
        limit?: number;
        cursorToken?: string;
    }) => Promise<any>;
    newsletterDirectoryCategories: (options?: {
        fetchStatusMetadata?: boolean;
        categories?: string[];
        countryCode?: string;
        perCategoryLimit?: number;
    }) => Promise<any>;
    newsletterSendPollVote: (jid: string, parentServerId: string | number, options: string | string[]) => Promise<{
        id: string;
    }>;
    newsletterInsights: (jid: string, options?: {
        metrics?: string[];
    }) => Promise<any>;
    newsletterFollowers: (jid: string, options?: {
        count?: number;
    }) => Promise<any>;
    newsletterPendingAdminInvites: (jid: string) => Promise<any>;
    newsletterQuestionResponseState: (jid: string, serverId: string | number, responseServerId: string | number, state: string) => Promise<any>;
    newsletterRecommended: (options?: {
        fetchStatusMetadata?: boolean;
        limit?: number;
        countryCodes?: string[];
    }) => Promise<any>;
    newsletterSimilar: (jid: string, options?: {
        fetchStatusMetadata?: boolean;
        limit?: number;
        countryCodes?: string[];
    }) => Promise<any>;
} & {
    getUsername: () => Promise<{
        username: any;
        state: any;
        pin: any;
    }>;
    removeUsername: () => Promise<any>;
    checkUsernameAvailability: (username: string, options?: {
        includeSuggestions?: boolean;
    }) => Promise<{
        available: boolean;
        suggestions: any;
        response: any;
    }>;
    getUsernames: (...jids: (string | string[])[]) => Promise<{
        jid: any;
        username: any;
    }[]>;
    removeUsernamePin: () => Promise<boolean>;
    fetchAbout: (jid: string) => Promise<{
        jid: string;
        status: any;
        response: any;
    }>;
    updateTextStatus: (text: string | null, options?: {
        ephemeralDurationSec?: number;
        emoji?: string;
    }) => Promise<any>;
    fetchUserNotices: (since?: number) => Promise<{
        id: string | undefined;
        stage: string | undefined;
        t: string | undefined;
        version: string | undefined;
        type: string | undefined;
    }[]>;
    updateUserNoticeStage: (noticeId: string | number, stage: string | number) => Promise<void>;
    fetchOptOutList: (options?: {
        category?: string;
        dhash?: string;
    }) => Promise<{
        [key: string]: string;
    }[]>;
    updateOptOut: ({ jid, category, action, dhash, reason, entryPoint, signupId, duration }: {
        jid: string;
        category: string;
        action: string;
        dhash?: string;
        reason?: string;
        entryPoint?: string;
        signupId?: string;
        duration?: number | string | null;
    }) => Promise<void>;
    fetchPushSettings: () => Promise<{
        [key: string]: string;
    }>;
    fetchServerLinkPreview: (url: string) => Promise<any>;
    reportSpam: (jid: string, options?: import("../index.js").SpamReportOptions) => Promise<{
        jid: string | undefined;
        flow: string | undefined;
        reported: boolean;
        node: import("../index.js").BinaryNode;
    }>;
    fetchProps: ({ full }?: {
        full?: boolean;
    }) => Promise<Record<string, string>>;
    getServerProps: ({ refresh }?: {
        refresh?: boolean;
    }) => Promise<Record<string, string>>;
    checkAccountHealth: (jid: string) => Promise<import("../index.js").AccountHealth>;
} & {
    sendHD: (jid: string, content: Record<string, any>, options?: Record<string, any> & {
        useCachedGroupMetadata?: boolean;
        statusJidList?: string[];
        additionalAttributes?: Record<string, string>;
        additionalNodes?: import("../index.js").BinaryNode[];
    }) => Promise<any>;
    sendImgVid: (jid: string, content: {
        image: any;
        video: any;
        caption?: string;
    }, options?: Record<string, any> & {
        useCachedGroupMetadata?: boolean;
        statusJidList?: string[];
        additionalAttributes?: Record<string, string>;
        additionalNodes?: import("../index.js").BinaryNode[];
    }) => Promise<any>;
    removeMemberLabel: (jid: string) => Promise<any>;
    resetGroupSenderKey: (jid: string) => Promise<{
        jid: string;
        cleared: number;
        devices: string[];
    }>;
    groupQuery: (jid: string, type: "get" | "set", content: import("../index.js").BinaryNode[]) => Promise<import("../index.js").BinaryNode>;
    communityQuery: (jid: string, type: "get" | "set", content: import("../index.js").BinaryNode[]) => Promise<import("../index.js").BinaryNode>;
    executeWMexQuery: <T = any>(variables: Record<string, unknown>, queryId: string, dataPath: string) => Promise<T>;
} & {
    sendNewsletterStatus: (jid: string, content: any, options?: Record<string, any>) => Promise<any>;
    sendNewsletterStatusReaction: (jid: string, parentServerId: string | number, reaction?: string | null, options?: {
        messageId?: string;
        ackTimeoutMs?: number;
    }) => Promise<{
        key: {
            remoteJid: string;
            fromMe: boolean;
            id: string;
        };
        status: import("../index.js").proto.WebMessageInfo.Status;
        newsletterStatusServerId: number | undefined;
        newsletterStatusAck: {
            class: string | undefined;
            from: string | undefined;
            id: string | undefined;
            t: number | undefined;
            serverId: number | undefined;
            edit: string | undefined;
            error: string | undefined;
            applicationError: number | undefined;
            backoff: number | undefined;
            node: any;
        };
        newsletterStatusResponse: any;
    }>;
    revokeNewsletterStatus: (jid: string, statusId: string, options?: {
        ackTimeoutMs?: number;
    }) => Promise<{
        key: {
            remoteJid: string;
            fromMe: boolean;
            id: string;
        };
        status: import("../index.js").proto.WebMessageInfo.Status;
        newsletterStatusAck: {
            class: string | undefined;
            from: string | undefined;
            id: string | undefined;
            t: number | undefined;
            serverId: number | undefined;
            edit: string | undefined;
            error: string | undefined;
            applicationError: number | undefined;
            backoff: number | undefined;
            node: any;
        };
        newsletterStatusResponse: any;
    }>;
    getNewsletterStatuses: (jid: string, options?: Record<string, any>) => Promise<{
        jid: string | undefined;
        t: number | undefined;
        statuses: {
            id: string | undefined;
            serverId: number | undefined;
            t: number | undefined;
            isSender: boolean;
            type: string | undefined;
            edit: string | undefined;
            mediaType: string | undefined;
            interactionType: string | undefined;
            reaction: string | undefined;
            adminProfile: {
                id: string | undefined;
                name: string | undefined;
                pictureId: string | undefined;
                pictureDirectPath: string | undefined;
            } | undefined;
            paidPartnership: boolean;
            aiContent: boolean;
            editTimestamp: number | undefined;
            originalTimestamp: number | undefined;
            reactionCounts: {
                code: string | undefined;
                count: number | undefined;
            }[] | undefined;
            viewsCount: number | undefined;
            responsesCount: number | undefined;
            message: (import("../index.js").proto.Message & import("../index.js").proto.Message.$Shape) | undefined;
            node: import("../index.js").BinaryNode;
        }[];
    }>;
    getNewsletterStatusUpdates: (jid: string, options?: Record<string, any>) => Promise<{
        jid: string | undefined;
        t: number | undefined;
        statuses: {
            id: string | undefined;
            serverId: number | undefined;
            t: number | undefined;
            isSender: boolean;
            type: string | undefined;
            edit: string | undefined;
            mediaType: string | undefined;
            interactionType: string | undefined;
            reaction: string | undefined;
            adminProfile: {
                id: string | undefined;
                name: string | undefined;
                pictureId: string | undefined;
                pictureDirectPath: string | undefined;
            } | undefined;
            paidPartnership: boolean;
            aiContent: boolean;
            editTimestamp: number | undefined;
            originalTimestamp: number | undefined;
            reactionCounts: {
                code: string | undefined;
                count: number | undefined;
            }[] | undefined;
            viewsCount: number | undefined;
            responsesCount: number | undefined;
            message: (import("../index.js").proto.Message & import("../index.js").proto.Message.$Shape) | undefined;
            node: import("../index.js").BinaryNode;
        }[];
    }>;
} & {
    sendMessage: (jid: string | string[], content: import("../index.js").AnyMessageContent, options?: import("../index.js").MiscMessageGenerationOptions) => Promise<import("../index.js").WAMessage | undefined>;
    MB: Omit<{
        VERSION: string;
        Button: typeof import("../index.js").Button;
        ButtonV2: typeof import("../index.js").ButtonV2;
        Carousel: typeof import("../index.js").AIRichCarousel;
        AIRichCarousel: typeof import("../index.js").AIRichCarousel;
        AIRich: typeof import("../index.js").AIRich;
        Toolkit: typeof import("../index.js").Toolkit;
        AIRichError: typeof import("../index.js").AIRichError;
        ItemNotFoundError: typeof import("../index.js").ItemNotFoundError;
        DuplicateIdError: typeof import("../index.js").DuplicateIdError;
        InvalidTargetError: typeof import("../index.js").InvalidTargetError;
        ContentValidationError: typeof import("../index.js").ContentValidationError;
    }, "Button" | "ButtonV2" | "Carousel" | "AIRichCarousel" | "AIRich"> & {
        [name: string]: any;
        AIRich: (new (args_0?: any) => import("../index.js").AIRich) & Omit<typeof import("../index.js").AIRich, "prototype">;
        Button: (new () => import("../index.js").Button) & Omit<typeof import("../index.js").Button, "prototype">;
        ButtonV2: (new () => import("../index.js").ButtonV2) & Omit<typeof import("../index.js").ButtonV2, "prototype">;
        Carousel: (new () => import("../index.js").AIRichCarousel) & Omit<typeof import("../index.js").AIRichCarousel, "prototype">;
        AIRichCarousel: (new () => import("../index.js").AIRichCarousel) & Omit<typeof import("../index.js").AIRichCarousel, "prototype">;
    };
    AIRich: (new (args_0?: any) => import("../index.js").AIRich) & Omit<typeof import("../index.js").AIRich, "prototype">;
} & {
    makeVoipClient: (options?: MergedVoipClientOptions) => Promise<MergedVoipClient>;
    webView: (chatId: string, options: WebViewOptions) => Promise<WebViewResult>;
    web: (chatId: string, options: WebViewOptions) => Promise<WebViewResult>;
    sendHtmlWebview: (chatId: string, options: WebViewOptions) => Promise<WebViewResult>;
};
export default makeWASocket;
//# sourceMappingURL=index.d.ts.map