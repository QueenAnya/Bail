import { Boom } from '@hapi/boom';
import { URL } from 'url';
import { type NewChatMessageCap, type ReachoutTimelockState, type SocketConfig, type WAUsernameInfo, type WAUsernameLookupResult, type WAUsernameQuery } from '../Types/index.js';
import { type BinaryNode } from '../WABinary/index.js';
import { BinaryInfo } from '../WAM/BinaryInfo.js';
import { USyncQuery } from '../WAUSync/index.js';
import { WebSocketClient } from './Client/index.js';
/**
 * Connects to WA servers and performs:
 * - simple queries (no retry mechanism, wait for connection establishment)
 * - listen to messages and emit events
 * - query phone connection
 */
/**
 * Hosts the socket is allowed to dial without an explicit opt-in.
 *
 * WhatsApp's own hosts, plus loopback so a local test server works. Anything else — an arbitrary domain, an IP,
 * a tunnel — is refused unless the caller sets `allowCustomEndpoint`. This is the difference between "a library
 * that talks to WhatsApp" and "a library that will talk to whoever configures it".
 */
export declare const WA_ENDPOINT_HOSTS: readonly string[];
export declare const isAllowedEndpoint: (url: URL) => boolean;
export declare const makeSocket: (config: SocketConfig) => {
    type: "md";
    ws: WebSocketClient;
    ev: import("../Types/index.js").BaileysEventEmitter & {
        process(handler: (events: Partial<import("../Types/index.js").BaileysEventMap>) => void | Promise<void>): () => void;
        buffer(): void;
        createBufferedFunction<A extends any[], T>(work: (...args: A) => Promise<T>): (...args: A) => Promise<T>;
        flush(): boolean;
        isBuffering(): boolean;
        destroy(): void;
        once<T extends keyof import("../Types/index.js").BaileysEventMap>(event: T, listener: (arg: import("../Types/index.js").BaileysEventMap[T]) => void): void;
        addListener<T extends keyof import("../Types/index.js").BaileysEventMap>(event: T, listener: (arg: import("../Types/index.js").BaileysEventMap[T]) => void): void;
        removeListener<T extends keyof import("../Types/index.js").BaileysEventMap>(event: T, listener: (arg: import("../Types/index.js").BaileysEventMap[T]) => void): void;
        setMaxListeners(count: number): void;
        getMaxListeners(): number;
        listenerCount(event: import("../Types/index.js").BaileysEvent): number;
        listeners(event: import("../Types/index.js").BaileysEvent): Function[];
        rawListeners(event: import("../Types/index.js").BaileysEvent): Function[];
        eventNames(): (string | symbol)[];
    };
    authState: {
        creds: import("../Types/index.js").AuthenticationCreds;
        keys: import("../Types/index.js").SignalKeyStoreWithTransaction;
    };
    signalRepository: import("../Types/index.js").SignalRepositoryWithLIDStore;
    readonly user: import("../Types/index.js").Contact | undefined;
    /** Connection health metrics for consumer-side monitoring */
    readonly connectionHealth: {
        lastMessageReceived: Date;
        consecutivePingFailures: number;
    };
    getLidUser: (jid: string) => Promise<{
        id: string;
        lid?: string;
    }[] | undefined>;
    generateMessageTag: () => string;
    query: (node: BinaryNode, timeoutMs?: number) => Promise<any>;
    waitForMessage: <T>(msgId: string, timeoutMs?: number | undefined) => Promise<T | undefined>;
    waitForSocketOpen: () => Promise<void>;
    sendRawMessage: (data: Uint8Array | Buffer) => Promise<void>;
    sendNode: (frame: BinaryNode) => Promise<void>;
    logout: (msg?: string) => Promise<void>;
    end: (error: Error | undefined) => Promise<void>;
    registerSocketEndHandler: (handler: (error: Error | undefined) => void | Promise<void>) => void;
    onUnexpectedError: (err: Error | Boom, msg: string) => void;
    uploadPreKeys: (count?: number) => Promise<void>;
    uploadPreKeysToServerIfRequired: () => Promise<void>;
    digestKeyBundle: () => Promise<void>;
    rotateSignedPreKey: () => Promise<void>;
    requestPairingCode: (phoneNumber: string, customPairingCode?: string) => Promise<string>;
    cancelPairingCode: () => boolean;
    updateServerTimeOffset: ({ attrs }: BinaryNode) => void;
    sendUnifiedSession: () => Promise<void>;
    wamBuffer: BinaryInfo;
    /** Waits for the connection to WA to reach a state */
    waitForConnectionUpdate: (check: (u: Partial<import("../Types/index.js").ConnectionState>) => Promise<boolean | undefined>, timeoutMs?: number) => Promise<void>;
    sendWAMBuffer: (wamBuffer: Buffer) => Promise<any>;
    executeUSyncQuery: (usyncQuery: USyncQuery) => Promise<import("../index.js").USyncQueryResult | undefined>;
    onWhatsApp: (...targets: any[]) => Promise<(WAUsernameLookupResult | {
        jid: string;
        exists: boolean;
        lid: string | undefined;
        pn?: string;
    })[]>;
    onWhatsAppUsername: (...queries: WAUsernameQuery[]) => Promise<WAUsernameLookupResult[]>;
    /** Internal — see comment at its declaration above. */
    usernameLookupOverride: {
        fn: ((...queries: WAUsernameQuery[]) => Promise<WAUsernameLookupResult[]>) | null;
    };
    fetchUsername: (...jids: string[]) => Promise<WAUsernameInfo[]>;
    fetchAccountReachoutTimelock: () => Promise<ReachoutTimelockState>;
    fetchNewChatMessageCap: () => Promise<NewChatMessageCap>;
};
//# sourceMappingURL=socket.d.ts.map