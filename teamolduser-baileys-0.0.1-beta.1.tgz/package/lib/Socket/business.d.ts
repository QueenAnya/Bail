import type { GetCatalogOptions, ProductCreate, ProductUpdate, SocketConfig, WAMediaUpload } from '../Types/index.js';
import type { UpdateBussinesProfileProps } from '../Types/Bussines.js';
import { type BinaryNode } from '../WABinary/index.js';
export declare const makeBusinessSocket: (config: SocketConfig) => {
    logger: import("../Utils/logger.js").ILogger;
    getOrderDetails: (orderId: string, tokenBase64: string, jid?: string) => Promise<import("../index.js").OrderDetails>;
    getCatalog: ({ jid, limit, cursor }: GetCatalogOptions) => Promise<{
        products: import("../index.js").Product[];
        nextPageCursor: string | undefined;
    }>;
    getCollections: (jid?: string, limit?: number) => Promise<{
        collections: import("../index.js").CatalogCollection[];
    }>;
    productCreate: (create: ProductCreate) => Promise<import("../index.js").Product>;
    productDelete: (productIds: string[]) => Promise<{
        deleted: number;
    }>;
    productUpdate: (productId: string, update: ProductUpdate) => Promise<import("../index.js").Product>;
    updateBussinesProfile: (args: UpdateBussinesProfileProps) => Promise<any>;
    updateBusinessProfile: (args: UpdateBussinesProfileProps) => Promise<any>;
    updateCoverPhoto: (photo: WAMediaUpload) => Promise<number>;
    removeCoverPhoto: (id: string) => Promise<any>;
    sendMessageAck: (node: BinaryNode, errorCode?: number) => Promise<void>;
    sendRetryRequest: (node: BinaryNode, forceIncludeKeys?: boolean) => Promise<void>;
    offerCall: (toJid: string, isVideo?: boolean) => Promise<{
        id: string;
        to: string;
    }>;
    WAInitiateCall: (jid: string, options?: import("../index.js").WAInitiateCallOptions) => Promise<import("../index.js").WAInitiateCallResult>;
    cancelCall: (callId: string, callTo: string) => Promise<void>;
    rejectCall: (callId: string, callFrom: string) => Promise<void>;
    acceptCall: (callId: string, callFrom: string, isVideo?: boolean) => Promise<void>;
    preacceptCall: (callId: string, callCreator: string, isVideo?: boolean) => Promise<void>;
    terminateCall: (callId: string, callTo: string, callCreator?: string, reason?: string, duration?: number) => Promise<void>;
    sendRelayLatency: (callId: string, callCreator: string, relays: Array<{
        relayName?: string;
        latency: number;
        relayId?: string;
        dlBw?: number;
        ulBw?: number;
    }>, transactionId?: string) => Promise<void>;
    sendTransport: (callId: string, callCreator: string, to: string, candidates: Array<{
        priority: string;
        data: Uint8Array;
    }>, round?: number) => Promise<void>;
    sendCallDuration: (callId: string, callCreator: string, peer: string, audioDuration: number, callType?: string) => Promise<void>;
    muteCall: (callId: string, callCreator: string, to: string, muted: boolean) => Promise<void>;
    unmuteCall: (callId: string, callCreator: string, to: string) => Promise<void>;
    sendHeartbeat: (callId: string, callCreator: string) => Promise<void>;
    sendEncRekey: (callId: string, callCreator: string, to: string, transactionId: string) => Promise<void>;
    sendVideoState: (callId: string, callCreator: string, to: string, enabled: boolean, orientation?: string) => Promise<void>;
    queryCallLink: (token: string, media?: string) => Promise<any>;
    joinCallLink: (token: string, media?: string) => Promise<any>;
    fetchMessageHistory: (count: number, oldestMsgKey: import("../index.js").WAMessageKey, oldestMsgTimestamp: number | import("long").default) => Promise<string>;
    requestPlaceholderResend: (messageKey: import("../index.js").WAMessageKey, msgData?: Partial<import("../index.js").WAMessage>) => Promise<string | undefined>;
    messageRetryManager: import("../index.js").MessageRetryManager | null;
    userDevicesCache: import("../index.js").PossiblyExtendedCacheStore | import("@cacheable/node-cache").NodeCache<import("../index.js").JidWithDevice[]>;
    outboundResendCache: import("../index.js").PossiblyExtendedCacheStore | import("@cacheable/node-cache").NodeCache<{
        jid: string;
        message: import("../index.js").proto.IMessage;
    }>;
    devicesMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    issuePrivacyTokens: (jids: string[], timestamp?: number) => Promise<any>;
    assertSessions: (jids: string[], force?: boolean) => Promise<boolean>;
    relayMessage: (jid: string, message: import("../index.js").proto.IMessage, { messageId: msgId, participant, additionalAttributes, additionalNodes, useUserDevicesCache, useCachedGroupMetadata, statusJidList, AI, secureMetaServiceLabel }: import("../index.js").MessageRelayOptions & {
        AI?: boolean;
        secureMetaServiceLabel?: boolean;
    }) => Promise<string>;
    sendReceipt: (jid: string, participant: string | undefined, messageIds: string[], type: import("../index.js").MessageReceiptType) => Promise<void>;
    profilePictureUrl: (jid: string, type?: "preview" | "image", timeoutMs?: number) => Promise<string | undefined>;
    getEphemeralGroup: (jid: string) => Promise<number | string>;
    sendReceipts: (keys: import("../index.js").WAMessageKey[], type: import("../index.js").MessageReceiptType) => Promise<void>;
    readMessages: (keys: import("../index.js").WAMessageKey[]) => Promise<void>;
    markIdentityChanged: (jid: string) => void;
    recentlyChangedIdentities: Map<string, NodeJS.Timeout>;
    refreshMediaConn: (forceGet?: boolean) => Promise<import("../index.js").MediaConnInfo>;
    getMediaHost: () => string;
    waUploadToServer: import("../index.js").WAMediaUploadFunction;
    fetchPrivacySettings: (force?: boolean) => Promise<{
        [_: string]: string;
    }>;
    sendPeerDataOperationMessage: (pdoMessage: import("../index.js").proto.Message.IPeerDataOperationRequestMessage) => Promise<string>;
    requestPhoneLinkPreview: (url: string) => Promise<string>;
    createParticipantNodes: (recipientJids: string[], message: import("../index.js").proto.IMessage, extraAttrs?: BinaryNode["attrs"], dsmMessage?: import("../index.js").proto.IMessage) => Promise<{
        nodes: BinaryNode[];
        shouldIncludeDeviceIdentity: boolean;
    }>;
    getUSyncDevices: (jids: string[], useCache: boolean, ignoreZeroDevices: boolean) => Promise<(import("../index.js").JidWithDevice & {
        jid: string;
    })[]>;
    updateMemberLabel: (jid: string, memberLabel: string) => Promise<string>;
    updateMediaMessage: (message: import("../index.js").WAMessage) => Promise<import("../index.js").WAMessage>;
    sendGroupStatus: (groupJid: string, content: Record<string, any>, options?: Record<string, any>) => Promise<import("../index.js").WAMessage>;
    sendGroupStatusV2: (groupJid: string, content: import("../index.js").AnyMessageContent, options?: Record<string, any>) => Promise<import("../index.js").WAMessage>;
    sendGroupV4Invite: (groupJid: string, participant: string, inviteCode: string, inviteExpiration?: number, groupName?: string, caption?: string, jpegThumbnail?: Buffer, options?: import("../index.js").MiscMessageGenerationOptions) => Promise<import("../index.js").WAMessage>;
    sendGroupInviteV4: (groupJid: string, participant: string, inviteCode: string, inviteExpiration?: number, groupName?: string, caption?: string, jpegThumbnail?: Buffer, options?: import("../index.js").MiscMessageGenerationOptions) => Promise<import("../index.js").WAMessage>;
    sendGroupInvite: (groupJid: string, user: string) => Promise<import("../index.js").GroupInviteAttemptResult[]>;
    monitorPresence: (targets: string | string[], options?: import("../index.js").PresenceMonitorOptions) => import("../index.js").PresenceMonitor;
    sendMessage: (jid: string | string[], content: import("../index.js").AnyMessageContent, options?: import("../index.js").MiscMessageGenerationOptions) => Promise<import("../index.js").WAMessage | undefined>;
    sendStickerPack: (jid: string, stickerPack: import("../index.js").StickerPackInput, options?: import("../index.js").MiscMessageGenerationOptions & {
        mediaCache?: import("../index.js").StickerPackOptions["mediaCache"];
    }) => Promise<string>;
    resize: (media: WAMediaUpload | string, width?: number, height?: number) => Promise<Buffer>;
    copyNForward: (jid: string, message: import("../index.js").WAMessage, forceForward?: boolean | number, options?: import("../index.js").MiscMessageGenerationOptions) => Promise<any>;
    sendStatusMentions: (content: import("../index.js").AnyMessageContent, jids?: string[]) => Promise<import("../index.js").WAMessage>;
    sendTable: (jid: string, title: string, headers: string[], rows: string[][], quoted?: any, options?: {
        headerText?: string;
        footer?: string;
    }) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendList: (jid: string, title: string, items: string[] | string[][], quoted?: any, options?: {
        headerText?: string;
        footer?: string;
    }) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendCodeBlock: (jid: string, code: string, quoted?: any, options?: {
        title?: string;
        footer?: string;
        language?: string;
    }) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendRichHtml: (jid: string, htmlOrOptions: string | (import("../index.js").GenerateRichHtmlOptions & {
        html: string;
    }), quoted?: any, options?: import("../index.js").GenerateRichHtmlOptions) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendLatex: (jid: string, quoted: any, options: {
        text?: string;
        expressions: import("../index.js").LatexExpression[];
        headerText?: string;
        footer?: string;
    }) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendLatexImage: (jid: string, quoted?: any, options?: any, renderLatexToPng?: (latexExpr: string) => Promise<{
        buffer: Buffer;
        width: number;
        height: number;
    }>, uploadFn?: (buffer: Buffer, type: string) => Promise<{
        url?: string;
        directPath?: string;
    }>) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendLatexNativeImage: (jid: string, quoted?: any, options?: any, renderLatexToPng?: (latexExpr: string) => Promise<{
        buffer: Buffer;
        width: number;
        height: number;
    }>, uploadFn?: (buffer: Buffer, type: string) => Promise<{
        url?: string;
        directPath?: string;
    }>) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendLatexInlineImage: (jid: string, quoted?: any, options?: any, renderLatexToPng?: (latexExpr: string) => Promise<{
        buffer: Buffer;
        width: number;
        height: number;
    }>, uploadFn?: (buffer: Buffer, type: string) => Promise<{
        url?: string;
        directPath?: string;
    }>) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendMarkdown: (jid: string, markdown: string, quoted?: any, options?: import("../index.js").ExtractOptions) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    sendLinkPreviewFor: (jid: string, url: string, textOrOptions?: string | ({
        text?: string;
    } & Partial<import("../index.js").WAUrlInfo>), sendOptions?: import("../index.js").MiscMessageGenerationOptions) => Promise<any>;
    sendRichMessage: (jid: string, submessages: import("../index.js").RichSubMessage[], quoted?: any, options?: import("../index.js").GenerateRichMessageOptions) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    extractUnifiedResponse: (msg: import("../index.js").proto.IMessage | null | undefined) => import("../index.js").CapturedUnifiedResponse | null;
    captureUnifiedResponse: (msg: import("../index.js").proto.IMessage | null | undefined) => import("../index.js").CapturedUnifiedResponse | null;
    sendUnifiedResponse: (jid: string, quoted: any, captured: import("../index.js").CapturedUnifiedResponse) => Promise<{
        message: import("../index.js").proto.IMessage;
        messageId: string;
    }>;
    GroupStatus: (groupJid: string, content: Record<string, any>, options?: Record<string, any>) => Promise<import("../index.js").WAMessage>;
    GroupStatusV2: (groupJid: string, content: import("../index.js").AnyMessageContent, options?: Record<string, any>) => Promise<import("../index.js").WAMessage>;
    newsletterWMexQuery: (variables: Record<string, unknown> | undefined, queryId: string, options: Record<string, unknown>) => Promise<BinaryNode>;
    newsletterCreate: (name: string, description?: string) => Promise<import("../index.js").NewsletterMetadata>;
    newsletterUpdate: (jid: string, updates: import("../index.js").NewsletterUpdate) => Promise<unknown>;
    newsletterFetchAllParticipating: () => Promise<unknown>;
    newsletterSubscribers: (jid: string, options?: {
        count?: number;
    }) => Promise<{
        id: string | undefined;
        phoneNumber: string | undefined;
        displayName: string | undefined;
        username: string | undefined;
        role: string | undefined;
        followTime: string | undefined;
    }[]>;
    newsletterMetadata: (type: "invite" | "jid", key: string, options?: {
        fetchCreationTime?: boolean;
        fetchFullImage?: boolean;
        fetchViewerMetadata?: boolean;
        fetchPinnedMessages?: boolean;
        fetchStatusMetadata?: boolean;
        fetchWamoSub?: boolean;
        viewRole?: string;
    }) => Promise<import("../index.js").NewsletterMetadata | null>;
    newsletterAction: (jid: string, type: keyof typeof import("../index.js").QueryIds) => Promise<void>;
    newsletterFollow: (jid: string) => Promise<unknown>;
    newsletterUnfollow: (jid: string) => Promise<unknown>;
    newsletterMute: (jid: string) => Promise<{
        id: string;
        state: string | undefined;
    }>;
    newsletterUnmute: (jid: string) => Promise<{
        id: string;
        state: string | undefined;
    }>;
    newsletterMuteLegacy: (jid: string) => Promise<unknown>;
    newsletterUnmuteLegacy: (jid: string) => Promise<unknown>;
    newsletterUpdateName: (jid: string, name: string) => Promise<unknown>;
    newsletterUpdateDescription: (jid: string, description: string) => Promise<unknown>;
    newsletterUpdatePicture: (jid: string, content: WAMediaUpload) => Promise<unknown>;
    newsletterRemovePicture: (jid: string) => Promise<unknown>;
    newsletterReactMessage: (jid: string, serverId: string, reaction?: string) => Promise<void>;
    newsletterFetchMessages: (jid: string, count: number, since: number, after: number) => Promise<any>;
    subscribeNewsletterUpdates: (jid: string) => Promise<{
        duration: string;
    } | null>;
    newsletterAdminCount: (jid: string) => Promise<number>;
    newsletterChangeOwner: (jid: string, newOwnerJid: string) => Promise<void>;
    newsletterDemote: (jid: string, userJid: string) => Promise<void>;
    newsletterDelete: (jid: string) => Promise<void>;
    newsletterSubscribed: (options?: {
        fetchStatusMetadata?: boolean;
        fetchWamoSub?: boolean;
    }) => Promise<unknown>;
    newsletterReactionMode: (jid: string, mode: string) => Promise<void>;
    newsletterUpdateUserSetting: (jid: string, type: string, value: boolean) => Promise<{
        id: string;
        state: string | undefined;
    }>;
    newsletterUpdateReactions: (jid: string, setting: string) => Promise<unknown>;
    newsletterFetchMessageUpdates: (jid: string, options?: Record<string, any>) => Promise<{
        jid: string;
        messages: any[];
    }>;
    newsletterQuestionResponses: (jid: string, serverId: string, options?: Record<string, any>) => Promise<{
        jid: any;
        serverId: number;
        responses: {
            id: string | undefined;
            t: number | undefined;
            isSender: boolean;
            responseServerId: string | undefined;
            sender: {
                lid: string | undefined;
                notifyName: string | undefined;
                pictureDirectPath: string | undefined;
            };
            replied: boolean;
            starred: boolean;
            message: any;
        }[];
    }>;
    newsletterMyAddOns: (options?: Record<string, any>) => Promise<any[]>;
    newsletterStatusMyAddOns: (options?: Record<string, any>) => Promise<any[]>;
    newsletterAdminCapabilities: (jid: string) => Promise<any>;
    newsletterEnforcements: (jid: string, locale?: string) => Promise<{
        adminProfiles: any;
        profilePictureDeletions: any;
        suspensions: any;
        violatingMessages: any[];
        geoSuspensions: any[];
    }>;
    newsletterReports: (locale?: string) => Promise<any>;
    newsletterAppealReport: (reportId: string, reason: string) => Promise<unknown>;
    newsletterCanPostStatus: (jid: string) => Promise<{
        canPost: any;
        canPostMusic: any;
        capabilities: any;
    }>;
    newsletterAdminInfo: (jid: string) => Promise<{
        id: any;
        adminCount: any;
        adminProfile: {
            id: any;
            name: any;
            picture: {
                id: any;
                directPath: any;
            } | undefined;
        } | undefined;
        adminProfilesEnabled: any;
    }>;
    newsletterPollVoters: (jid: string, serverId: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterReactionSenders: (jid: string, serverId: string) => Promise<unknown>;
    newsletterPinMessages: (jid: string, serverIds: string | string[]) => Promise<unknown>;
    newsletterUnpinMessages: (jid: string, serverIds: string | string[]) => Promise<unknown>;
    newsletterLabelAiContent: (jid: string, serverId: string, messageType?: string) => Promise<unknown>;
    newsletterLabelPaidPartnership: (jid: string, serverId: string, messageType?: string) => Promise<unknown>;
    newsletterCreateAdminInvite: (jid: string, userJid: string) => Promise<unknown>;
    newsletterRevokeAdminInvite: (jid: string, userJid: string) => Promise<unknown>;
    newsletterAcceptAdminInvite: (jid: string) => Promise<unknown>;
    newsletterDirectoryList: (options?: Record<string, any>) => Promise<unknown>;
    newsletterDirectorySearch: (searchText: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterDirectoryCategories: (options?: Record<string, any>) => Promise<unknown>;
    newsletterSendPollVote: (jid: string, parentServerId: string, options: Record<string, any>) => Promise<{
        id: string;
    }>;
    newsletterInsights: (jid: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterFollowers: (jid: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterPendingAdminInvites: (jid: string) => Promise<any>;
    newsletterQuestionResponseState: (jid: string, serverId: string, responseServerId: string, state: string) => Promise<unknown>;
    newsletterRecommended: (options?: Record<string, any>) => Promise<unknown>;
    newsletterSimilar: (jid: string, options?: Record<string, any>) => Promise<unknown>;
    newsletterFetchUpdates: (jid: string, count: number, after?: number, since?: number) => Promise<any>;
    groupMetadata: (jid: string) => Promise<import("../index.js").GroupMetadata>;
    groupCreate: (subject: string, participants: string[]) => Promise<import("../index.js").GroupMetadata>;
    groupLeave: (id: string) => Promise<void>;
    groupUpdateSubject: (jid: string, subject: string) => Promise<void>;
    groupRequestParticipantsList: (jid: string) => Promise<{
        [key: string]: string;
    }[]>;
    groupRequestParticipantsUpdate: (jid: string, participants: string[], action: "approve" | "reject") => Promise<{
        status: string;
        jid: string | undefined;
    }[]>;
    groupParticipantsUpdate: (jid: string, participants: string[], action: import("../index.js").ParticipantAction) => Promise<{
        status: string;
        jid: string | undefined;
        content: BinaryNode;
    }[]>;
    groupUpdateDescription: (jid: string, description?: string) => Promise<void>;
    groupInviteCode: (jid: string) => Promise<string | undefined>;
    groupRevokeInvite: (jid: string) => Promise<string | undefined>;
    groupAcceptInvite: (code: string) => Promise<string | undefined>;
    groupRevokeInviteV4: (groupJid: string, invitedJid: string) => Promise<boolean>;
    groupAcceptInviteV4: (key: string | import("../index.js").WAMessageKey, inviteMessage: import("../index.js").proto.Message.IGroupInviteMessage) => Promise<any>;
    groupGetInviteInfo: (code: string) => Promise<import("../index.js").GroupMetadata>;
    groupToggleEphemeral: (jid: string, ephemeralExpiration: number) => Promise<void>;
    groupSettingUpdate: (jid: string, setting: "announcement" | "not_announcement" | "locked" | "unlocked") => Promise<void>;
    groupMemberAddMode: (jid: string, mode: "admin_add" | "all_member_add") => Promise<void>;
    groupJoinApprovalMode: (jid: string, mode: "on" | "off") => Promise<void>;
    groupFetchAllParticipating: () => Promise<{
        [_: string]: import("../index.js").GroupMetadata;
    }>;
    serverProps: {
        privacyTokenOn1to1: boolean;
        profilePicPrivacyToken: boolean;
        lidTrustedTokenIssueToLid: boolean;
    };
    createCallLink: (type: "audio" | "video", event?: {
        startTime: number;
    }, timeoutMs?: number) => Promise<string | undefined>;
    getBotListV2: () => Promise<import("../index.js").BotListInfo[]>;
    messageMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    receiptMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    appStatePatchMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    notificationMutex: {
        mutex<T>(code: () => Promise<T> | T): Promise<T>;
    };
    upsertMessage: (msg: import("../index.js").WAMessage, type: import("../index.js").MessageUpsertType) => Promise<void>;
    appPatch: (patchCreate: import("../index.js").WAPatchCreate) => Promise<void>;
    sendPresenceUpdate: (type: import("../index.js").WAPresence, toJid?: string) => Promise<void>;
    presenceSubscribe: (toJid: string) => Promise<void>;
    fetchBlocklist: () => Promise<(string | undefined)[]>;
    fetchStatus: (...jids: string[]) => Promise<import("../index.js").USyncQueryResultList[] | undefined>;
    fetchTextStatus: (...jids: string[]) => Promise<import("../index.js").USyncQueryResultList[] | undefined>;
    fetchDisappearingDuration: (...jids: string[]) => Promise<import("../index.js").USyncQueryResultList[] | undefined>;
    updateProfilePicture: (jid: string, content: WAMediaUpload, dimensions?: {
        width: number;
        height: number;
    }) => Promise<void>;
    findUserId: (pnOrLid: string) => Promise<import("../index.js").UserIdLookup>;
    updatePanoramaProfilePicture: (jid: string, content: WAMediaUpload, opts?: {
        maxWidth?: number;
        quality?: number;
    }) => Promise<void>;
    removeProfilePicture: (jid: string) => Promise<void>;
    updateProfileStatus: (status: string | import("../index.js").TextStatusInput) => Promise<void>;
    updateProfileAbout: (status: string | import("../index.js").TextStatusInput) => Promise<void>;
    updateProfileName: (name: string) => Promise<void>;
    updateBlockStatus: (jid: string, action: "block" | "unblock") => Promise<void>;
    updateDisableLinkPreviewsPrivacy: (isPreviewsDisabled: boolean) => Promise<void>;
    updateCallPrivacy: (value: import("../index.js").WAPrivacyCallValue) => Promise<void>;
    updateMessagesPrivacy: (value: import("../index.js").WAPrivacyMessagesValue) => Promise<void>;
    updateLastSeenPrivacy: (value: import("../index.js").WAPrivacyValue) => Promise<void>;
    updateOnlinePrivacy: (value: import("../index.js").WAPrivacyOnlineValue) => Promise<void>;
    updateProfilePicturePrivacy: (value: import("../index.js").WAPrivacyValue) => Promise<void>;
    updateStatusPrivacy: (value: import("../index.js").WAPrivacyValue) => Promise<void>;
    updateReadReceiptsPrivacy: (value: import("../index.js").WAReadReceiptsValue) => Promise<void>;
    updateGroupsAddPrivacy: (value: import("../index.js").WAPrivacyGroupAddValue) => Promise<void>;
    updateDefaultDisappearingMode: (duration: number | string) => Promise<void>;
    updateDefaultDisappearing: (duration: number | string) => Promise<void>;
    updateDisappearingDuration: (duration: number | string) => Promise<void>;
    getBusinessProfile: (jid: string) => Promise<import("../index.js").WABusinessProfile | void>;
    getBroadcastListInfo: (jid: string) => Promise<{
        name?: string;
        recipients: string[];
    }>;
    resyncAppState: (collections: readonly ("critical_unblock_low" | "regular_high" | "regular_low" | "critical_block" | "regular")[], isInitialSync: boolean) => Promise<void>;
    chatModify: (mod: import("../index.js").ChatModification, jid: string) => Promise<void>;
    clearMessage: (jid: string, key: import("../index.js").WAMessageKey, timeStamp: number | import("long").default) => Promise<void>;
    deleteChat: (jid: string, key: import("../index.js").WAMessageKey, timeStamp: number | import("long").default) => Promise<void>;
    cleanDirtyBits: (type: "account_sync" | "groups", fromTimestamp?: number | string) => Promise<void>;
    addOrEditContact: (jid: string, contact: import("../index.js").proto.SyncActionValue.IContactAction) => Promise<void>;
    removeContact: (jid: string) => Promise<void>;
    placeholderResendCache: import("../index.js").CacheStore;
    addLabel: (jid: string, labels: import("../Types/Label.js").LabelActionBody) => Promise<void>;
    addChatLabel: (jid: string, labelId: string) => Promise<void>;
    removeChatLabel: (jid: string, labelId: string) => Promise<void>;
    addMessageLabel: (jid: string, messageId: string, labelId: string) => Promise<void>;
    removeMessageLabel: (jid: string, messageId: string, labelId: string) => Promise<void>;
    star: (jid: string, messages: {
        id: string;
        fromMe?: boolean;
    }[], star: boolean) => Promise<void>;
    addOrEditQuickReply: (quickReply: import("../Types/Bussines.js").QuickReplyAction) => Promise<void>;
    removeQuickReply: (timestamp: string) => Promise<void>;
    type: "md";
    ws: import("./Client/index.js").WebSocketClient;
    ev: import("../index.js").BaileysEventEmitter & {
        process(handler: (events: Partial<import("../index.js").BaileysEventMap>) => void | Promise<void>): () => void;
        buffer(): void;
        createBufferedFunction<A extends any[], T>(work: (...args: A) => Promise<T>): (...args: A) => Promise<T>;
        flush(): boolean;
        isBuffering(): boolean;
        destroy(): void;
        once<T extends keyof import("../index.js").BaileysEventMap>(event: T, listener: (arg: import("../index.js").BaileysEventMap[T]) => void): void;
        addListener<T extends keyof import("../index.js").BaileysEventMap>(event: T, listener: (arg: import("../index.js").BaileysEventMap[T]) => void): void;
        removeListener<T extends keyof import("../index.js").BaileysEventMap>(event: T, listener: (arg: import("../index.js").BaileysEventMap[T]) => void): void;
        setMaxListeners(count: number): void;
        getMaxListeners(): number;
        listenerCount(event: import("../index.js").BaileysEvent): number;
        listeners(event: import("../index.js").BaileysEvent): Function[];
        rawListeners(event: import("../index.js").BaileysEvent): Function[];
        eventNames(): (string | symbol)[];
    };
    authState: {
        creds: import("../index.js").AuthenticationCreds;
        keys: import("../index.js").SignalKeyStoreWithTransaction;
    };
    signalRepository: import("../index.js").SignalRepositoryWithLIDStore;
    user: import("../index.js").Contact | undefined;
    connectionHealth: {
        lastMessageReceived: Date;
        consecutivePingFailures: number;
    };
    getLidUser: (jid: string) => Promise<{
        id: string;
        lid?: string;
    }[] | undefined>;
    generateMessageTag: () => string;
    query: (node: BinaryNode, timeoutMs?: number) => Promise<any>;
    waitForMessage: <T>(msgId: string, timeoutMs?: number | undefined) => Promise<T | undefined>;
    waitForSocketOpen: () => Promise<void>;
    sendRawMessage: (data: Uint8Array | Buffer) => Promise<void>;
    sendNode: (frame: BinaryNode) => Promise<void>;
    logout: (msg?: string) => Promise<void>;
    end: (error: Error | undefined) => Promise<void>;
    registerSocketEndHandler: (handler: (error: Error | undefined) => void | Promise<void>) => void;
    onUnexpectedError: (err: Error | import("@hapi/boom").Boom, msg: string) => void;
    uploadPreKeys: (count?: number) => Promise<void>;
    uploadPreKeysToServerIfRequired: () => Promise<void>;
    digestKeyBundle: () => Promise<void>;
    rotateSignedPreKey: () => Promise<void>;
    requestPairingCode: (phoneNumber: string, customPairingCode?: string) => Promise<string>;
    cancelPairingCode: () => boolean;
    updateServerTimeOffset: ({ attrs }: BinaryNode) => void;
    sendUnifiedSession: () => Promise<void>;
    wamBuffer: import("../index.js").BinaryInfo;
    waitForConnectionUpdate: (check: (u: Partial<import("../index.js").ConnectionState>) => Promise<boolean | undefined>, timeoutMs?: number) => Promise<void>;
    sendWAMBuffer: (wamBuffer: Buffer) => Promise<any>;
    executeUSyncQuery: (usyncQuery: import("../index.js").USyncQuery) => Promise<import("../index.js").USyncQueryResult | undefined>;
    onWhatsApp: (...targets: any[]) => Promise<(import("../index.js").WAUsernameLookupResult | {
        jid: string;
        exists: boolean;
        lid: string | undefined;
        pn?: string;
    })[]>;
    onWhatsAppUsername: (...queries: import("../index.js").WAUsernameQuery[]) => Promise<import("../index.js").WAUsernameLookupResult[]>;
    usernameLookupOverride: {
        fn: ((...queries: import("../index.js").WAUsernameQuery[]) => Promise<import("../index.js").WAUsernameLookupResult[]>) | null;
    };
    fetchUsername: (...jids: string[]) => Promise<import("../index.js").WAUsernameInfo[]>;
    fetchAccountReachoutTimelock: () => Promise<import("../index.js").ReachoutTimelockState>;
    fetchNewChatMessageCap: () => Promise<import("../index.js").NewChatMessageCap>;
};
//# sourceMappingURL=business.d.ts.map