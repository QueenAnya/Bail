/**
 * Mobile Country Codes by international dialing prefix (`'1-684'` style keys for NANP territories).
 * Ported from @innovatorssoft/baileys (`Defaults/phonenumber-mcc.json`); kept as a TS module so it works
 * in native ESM output without JSON import attributes.
 */
export declare const PHONENUMBER_MCC: Record<string, number>;
//# sourceMappingURL=phonenumber-mcc.d.ts.map