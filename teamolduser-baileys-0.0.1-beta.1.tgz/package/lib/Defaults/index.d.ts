import { proto } from '../../WAProto/index.js';
import type { SocketConfig } from '../Types/index.js';
export { PHONENUMBER_MCC } from './phonenumber-mcc.js';
export declare const UNAUTHORIZED_CODES: number[];
export declare const DEFAULT_ORIGIN = "https://web.whatsapp.com";
export declare const CALL_VIDEO_PREFIX = "https://call.whatsapp.com/video/";
export declare const CALL_AUDIO_PREFIX = "https://call.whatsapp.com/voice/";
export declare const DEF_CALLBACK_PREFIX = "CB:";
export declare const DEF_TAG_PREFIX = "TAG:";
export declare const PHONE_CONNECTION_CB = "CB:Pong";
export declare const WA_ADV_ACCOUNT_SIG_PREFIX: Buffer<ArrayBuffer>;
export declare const WA_ADV_DEVICE_SIG_PREFIX: Buffer<ArrayBuffer>;
export declare const WA_ADV_HOSTED_ACCOUNT_SIG_PREFIX: Buffer<ArrayBuffer>;
export declare const WA_ADV_HOSTED_DEVICE_SIG_PREFIX: Buffer<ArrayBuffer>;
export declare const WA_DEFAULT_EPHEMERAL: number;
/** Status messages older than 24 hours are considered expired */
export declare const STATUS_EXPIRY_SECONDS: number;
/** WA Web enforces a 14-day maximum age for placeholder resend requests */
export declare const PLACEHOLDER_MAX_AGE_SECONDS: number;
export declare const NOISE_MODE = "Noise_XX_25519_AESGCM_SHA256\0\0\0\0";
export declare const DICT_VERSION = 3;
export declare const KEY_BUNDLE_TYPE: Buffer<ArrayBuffer>;
export declare const NOISE_WA_HEADER: Buffer<ArrayBuffer>;
/** from: https://stackoverflow.com/questions/3809401/what-is-a-good-regular-expression-to-match-a-url */
export declare const URL_REGEX: RegExp;
/** Fallback link used when a caller triggers an offer/ad-reply feature
 *  (native-flow limited-time-offer, externalAdReply shorthand) without
 *  supplying their own URL. Point this at your own project/site — update
 *  freely. */
export declare const FALLBACK_LINK_URL = "https://github.com/Teamolduser/Baileys/";
export declare const WA_CERT_DETAILS: {
    SERIAL: number;
    ISSUER: string;
    PUBLIC_KEY: Buffer<ArrayBuffer>;
};
export declare const PROCESSABLE_HISTORY_TYPES: proto.HistorySync.HistorySyncType[];
export declare const DEFAULT_CACHE_TTLS: {
    SIGNAL_STORE: number;
    MSG_RETRY: number;
    CALL_OFFER: number;
    USER_DEVICES: number;
    USERNAME: number;
    USERNAME_NEGATIVE: number;
    OUTBOUND_RESEND: number;
};
/** Default max keys for TTL/LRU caches */
export declare const DEFAULT_CACHE_MAX_KEYS = 20000;
/** Max number of recently sent messages kept for resending after a retryable nack */
export declare const MAX_OUTBOUND_RESEND_ENTRIES = 512;
/** Max length (chars) of a group member label */
export declare const MEMBER_LABEL_MAX_LENGTH = 30;
/** How long to keep waiting for the pairing response after the phone confirms a pairing code */
export declare const PAIRING_RESPONSE_GRACE_MS = 30000;
export declare const DEFAULT_CONNECTION_CONFIG: SocketConfig;
export declare const MEDIA_PATH_MAP: {
    [T in MediaType]?: string;
};
export declare const NEWSLETTER_MEDIA_PATH_MAP: {
    [T in MediaType]?: string;
};
export declare const MEDIA_HKDF_KEY_MAPPING: {
    audio: string;
    document: string;
    gif: string;
    image: string;
    ppic: string;
    product: string;
    ptt: string;
    sticker: string;
    'sticker-pack': string;
    'thumbnail-sticker-pack': string;
    video: string;
    'thumbnail-document': string;
    'thumbnail-image': string;
    'thumbnail-video': string;
    'thumbnail-link': string;
    'md-msg-hist': string;
    'md-app-state': string;
    'product-catalog-image': string;
    'payment-bg-image': string;
    ptv: string;
    'biz-cover-photo': string;
};
export type MediaType = keyof typeof MEDIA_HKDF_KEY_MAPPING;
export declare const MEDIA_KEYS: MediaType[];
/** 120s timeout for history sync stall detection, same as WA Web's handleChunkProgress / restartPausedTimer (g = 120) */
export declare const HISTORY_SYNC_PAUSED_TIMEOUT_MS = 120000;
export declare const MIN_PREKEY_COUNT = 5;
/** Minimum time (ms) between two pre-key uploads — see Socket/socket.ts uploadPreKeys. */
export declare const MIN_UPLOAD_INTERVAL = 5000;
export declare const INITIAL_PREKEY_COUNT = 812;
export declare const UPLOAD_TIMEOUT = 30000;
export declare const TimeMs: {
    Minute: number;
    Hour: number;
    Day: number;
    Week: number;
};
/** Library name shown in fallback texts */
export declare const LIBRARY_NAME = "Baileys";
/**
 * Regex lexer for syntax highlighting in rich-message code blocks.
 * Matches: line comments | strings/template literals | call-site identifiers
 *          | plain identifiers | numbers | whitespace/punctuation
 */
export declare const LEXER_REGEX: RegExp;
/** Fallback donate/reference URL used by rich-message link entities. */
export declare const DONATE_URL = "https://github.com/Teamolduser/Baileys";
/**
 * Support payload for AI/Bot messages — injected into messageContextInfo.supportPayload.
 * Signals to WA servers that this is an AI bot message.
 */
export declare const BIZ_BOT_SUPPORT_PAYLOAD = "{\"version\":1,\"is_ai_message\":true,\"should_upload_client_logs\":false,\"should_show_system_message\":false,\"ticket_id\":\"7004947587700716\",\"citation_items\":[],\"ticket_locale\":\"us\"}";
//# sourceMappingURL=index.d.ts.map