import type { BinaryNode } from '../WABinary/index.js';
export type OfflineNodeType = 'message' | 'call' | 'receipt' | 'notification';
/** upstream (WhiskeySockets) name for the same union — kept so code written against their exports compiles here */
export type MessageType = OfflineNodeType;
export type OfflineNodeProcessorDeps = {
    isWsOpen: () => boolean;
    onUnexpectedError: (error: Error, msg: string) => void;
    yieldToEventLoop: () => Promise<void>;
};
/**
 * Creates a processor for offline stanza nodes that:
 * - Queues nodes for sequential processing
 * - Yields to the event loop periodically to avoid blocking
 * - Catches handler errors to prevent the processing loop from crashing
 */
export declare function makeOfflineNodeProcessor(nodeProcessorMap: Map<OfflineNodeType, (node: BinaryNode) => Promise<void>>, deps: OfflineNodeProcessorDeps, batchSize?: number): {
    enqueue: (type: OfflineNodeType, node: BinaryNode) => void;
};
//# sourceMappingURL=offline-node-processor.d.ts.map