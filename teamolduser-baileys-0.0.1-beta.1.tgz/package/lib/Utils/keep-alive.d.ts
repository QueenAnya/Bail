import type { ILogger } from './logger.js';
export type KeepAliveOptions = {
    intervalMs: number;
    maxFailures?: number;
    isClosed: () => boolean;
    isOpen: () => boolean;
    /** last time anything was received from the server */
    getLastRecv: () => Date | undefined;
    setLastRecv: (d: Date) => void;
    /** send one ping; must reject on failure */
    ping: () => Promise<unknown>;
    /** called once when the connection is considered dead */
    onDead: (reason: 'silent' | 'ping-failures') => void;
    logger?: ILogger;
};
/**
 * Keepalive using recursive setTimeout (pings never overlap). Declares the
 * connection dead after `maxFailures` consecutive failed pings, or when the
 * socket has been silent for > 2x interval.
 */
export declare const makeKeepAlive: (opts: KeepAliveOptions) => {
    start: () => void;
    stop: () => void;
    readonly consecutiveFailures: number;
};
//# sourceMappingURL=keep-alive.d.ts.map