export type UsernameKeyOptions = {
    /** Defaults to 4, matching WhatsApp's current username key shape. */
    length?: number;
};
export type RepeatedDigitUsernameKeyOptions = UsernameKeyOptions & {
    digit: string | number;
};
export declare const isValidUsernameKey: (key: string, { length }?: UsernameKeyOptions) => boolean;
export declare const isRepeatedDigitUsernameKey: (key: string, { length }?: UsernameKeyOptions) => boolean;
export declare const makeRepeatedDigitUsernameKey: ({ digit, length }: RepeatedDigitUsernameKeyOptions) => string;
export declare const makeRandomUsernameKey: ({ length }?: UsernameKeyOptions) => string;
/** Normalize a WhatsApp username: strip @, trim and lowercase. */
export declare const normalizeUsername: (username: string) => string;
/**
 * `true` when the text has the *shape* of a WhatsApp username (3-35 letters, digits, `_` and `.`, at least one
 * letter, no leading/trailing/double `.`). Reserved words and domain-like endings are not checked here, so this stays
 * usable to tell a username apart from a phone number; `validateUsername` applies the full rules.
 */
export declare const isValidUsername: (username: string) => boolean;
/** Normalizes the username and throws `UsernameInvalidError` (with the reason) when WhatsApp would reject it. */
export declare const validateUsername: (username: string) => string;
export declare const isUsernameTarget: (target: unknown) => boolean;
export declare const isJidTarget: (target: unknown) => boolean;
export declare const resolveMessageTarget: (target: import("../Types/Username.js").MessageTarget) => {
    type: "username";
    username: string;
    jid?: undefined;
} | {
    type: "jid";
    jid: any;
    username?: undefined;
};
export declare const USERNAME_MIN_LENGTH = 3;
export declare const USERNAME_MAX_LENGTH = 35;
export declare const USERNAME_PIN_LENGTH = 4;
export declare const UsernameValidationError: {
    readonly INVALID_CHARACTER: "INVALID_CHARACTER";
    readonly INVALID_LENGTH: "INVALID_LENGTH";
    readonly INVALID_NO_LETTERS: "INVALID_NO_LETTERS";
    readonly INVALID_PERIODS: "INVALID_PERIODS";
    readonly INVALID_DOMAIN_SUFFIX: "INVALID_DOMAIN_SUFFIX";
    readonly INVALID_WWW_PREFIX: "INVALID_WWW_PREFIX";
    readonly INVALID_WORD: "INVALID_WORD";
};
export type UsernameValidationErrorType = (typeof UsernameValidationError)[keyof typeof UsernameValidationError];
export declare const stripUsernamePrefix: (username: string) => string;
export declare const displayUsername: (username: string) => string;
/**
 * Detailed username format check (returns the failure reason instead of throwing).
 * Distinct from `validateUsername`, which throws on invalid input.
 */
export declare const validateUsernameFormat: (username: string) => {
    isValid: true;
} | {
    isValid: false;
    errorType: UsernameValidationErrorType;
};
/** Throws a 400 Boom when WhatsApp would reject the username; returns it without the `@`. */
export declare const assertUsername: (username: string) => string;
export declare const isUsernamePin: (pin: string) => boolean;
//# sourceMappingURL=username.d.ts.map