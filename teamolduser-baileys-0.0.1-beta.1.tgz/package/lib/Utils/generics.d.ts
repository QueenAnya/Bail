import type Long from 'long';
import { proto } from '../../WAProto/index.js';
import type { BaileysEventEmitter, BaileysEventMap, ConnectionState, WACallUpdateType, WAMessageKey, WAVersion } from '../Types/index.js';
import { type BinaryNode } from '../WABinary/index.js';
import type { ILogger } from './logger.js';
export declare const BufferJSON: {
    replacer: (k: any, value: any) => any;
    reviver: (_: any, value: any) => any;
};
export declare const getKeyAuthor: (key: WAMessageKey | undefined | null, meId?: string) => string;
export declare const isStringNullOrEmpty: (value: string | null | undefined) => value is null | undefined | "";
export declare const writeRandomPadMax16: (msg: Uint8Array) => Buffer<ArrayBuffer>;
export declare const unpadRandomMax16: (e: Uint8Array | Buffer) => Uint8Array<ArrayBuffer>;
export declare const generateParticipantHashV2: (participants: string[]) => string;
export declare const encodeWAMessage: (message: proto.IMessage) => Buffer<ArrayBuffer>;
export declare const generateRegistrationId: () => number;
export declare const encodeBigEndian: (e: number, t?: number) => Uint8Array<ArrayBuffer>;
export declare const toNumber: (t: Long | number | null | undefined) => number;
/** unix timestamp of a date in seconds */
export declare const unixTimestampSeconds: (d?: Date | number | string) => number;
export type DebouncedTimeout = ReturnType<typeof debouncedTimeout>;
export declare const debouncedTimeout: (intervalMs?: number, task?: () => void) => {
    start: (newIntervalMs?: number, newTask?: () => void) => void;
    cancel: () => void;
    setTask: (newTask: () => void) => () => void;
    setInterval: (newInterval: number) => number;
};
export declare const delay: (ms: number) => Promise<void>;
export declare const delayCancellable: (ms: number) => {
    delay: Promise<void>;
    cancel: () => void;
};
export declare function promiseTimeout<T>(ms: number | undefined, promise: (resolve: (v: T) => void, reject: (error: any) => void) => void): Promise<T>;
export declare const generateMessageIDV2: (userId?: string) => string;
export declare const generateMessageID: () => string;
export declare function bindWaitForEvent<T extends keyof BaileysEventMap>(ev: BaileysEventEmitter, event: T): (check: (u: BaileysEventMap[T]) => Promise<boolean | undefined>, timeoutMs?: number) => Promise<void>;
export declare const bindWaitForConnectionUpdate: (ev: BaileysEventEmitter) => (check: (u: Partial<ConnectionState>) => Promise<boolean | undefined>, timeoutMs?: number) => Promise<void>;
/**
 * Generate the key.uuid field for an outgoing message — a purely local
 * tracking identifier (never sent in the wire stanza), useful for bots that
 * need their own idempotency/dedup key separate from the WA message ID.
 * If `userUuid` is supplied it is returned verbatim; otherwise a random
 * 15-character string prefixed with `qa3#69` is generated.
 */
export declare const generateKeyUuid: (userUuid?: string) => string;
export declare const printQRIfNecessaryListener: (ev: BaileysEventEmitter, logger: ILogger) => void;
/**
 * utility that fetches latest baileys version from the master branch.
 * Use to ensure your WA connection is always on the latest version
 */
export declare const fetchLatestBaileysVersion: (options?: RequestInit) => Promise<{
    version: WAVersion;
    isLatest: boolean;
    error?: undefined;
} | {
    version: WAVersion;
    isLatest: boolean;
    error: unknown;
}>;
export declare const fetchLatestBaileysVersion2: (options?: RequestInit) => Promise<{
    version: WAVersion;
    isLatest: boolean;
    error?: undefined;
} | {
    version: WAVersion;
    isLatest: boolean;
    error: unknown;
}>;
/**
 * Latest (alpha-channel) WA Web version from wppconnect-team/wa-version.
 * Previously this fetched versions.json but parsed it like a TypeScript source file
 * (line 7 regex), so it could never succeed and always returned the fallback version.
 */
export declare const fetchAlphaWaWebVersion: (options?: RequestInit) => Promise<{
    version: WAVersion;
    isLatest: boolean;
    error?: undefined;
} | {
    version: WAVersion;
    isLatest: boolean;
    error: unknown;
}>;
/**
 * A utility that fetches the latest web version of whatsapp.
 * Use to ensure your WA connection is always on the latest version
 */
export declare const fetchLatestWaWebVersion: (options?: RequestInit) => Promise<{
    version: WAVersion;
    isLatest: boolean;
    error?: undefined;
} | {
    version: WAVersion;
    isLatest: boolean;
    error: unknown;
}>;
/** unique message tag prefix for MD clients */
export declare const generateMdTagPrefix: () => string;
/**
 * Given a type of receipt, returns what the new status of the message should be
 * @param type type from receipt
 */
export declare const getStatusFromReceiptType: (type: string | undefined) => proto.WebMessageInfo.Status | undefined;
/**
 * Stream errors generally provide a reason, map that to a baileys DisconnectReason
 * @param reason the string reason given, eg. "conflict"
 */
export declare const getErrorCodeFromStreamError: (node: BinaryNode) => {
    reason: string;
    statusCode: number;
};
export declare const getCallStatusFromNode: ({ tag, attrs }: BinaryNode) => WACallUpdateType;
export declare const getCodeFromWSError: (error: Error) => number;
/**
 * Is the given platform WA business
 * @param platform AuthenticationCreds.platform
 */
export declare const isWABusinessPlatform: (platform: string) => platform is "smba" | "smbi";
export declare function trimUndefined(obj: {
    [_: string]: any;
}): {
    [_: string]: any;
};
export declare function bytesToCrockford(buffer: Buffer): string;
export declare function encodeNewsletterMessage(message: proto.IMessage): Uint8Array;
/** Escapes every character of a string into its `\uXXXX` unicode form */
export declare function toUnicodeEscape(text: string): string;
/** Reverses {@link toUnicodeEscape} — decodes `\uXXXX` sequences back into characters */
export declare function fromUnicodeEscape(escapedText: string): string;
/** Encodes a string into an array of char codes (ASCII values) */
export declare function asciiEncode(text: string): number[];
/** Decodes an array (or spread) of char codes back into a string */
export declare function asciiDecode(...codes: number[] | [number[]]): string;
//# sourceMappingURL=generics.d.ts.map