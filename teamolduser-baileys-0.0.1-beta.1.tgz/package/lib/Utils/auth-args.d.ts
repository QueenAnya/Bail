/**
 * Argument normalisation shared by the auth adapters.
 *
 * Every adapter accepts its arguments two ways, so callers never have to remember which style a given backend uses:
 *
 *   useXAuthState(a)              // one positional value
 *   useXAuthState(a, b, c)        // positional, in the order documented for that adapter
 *   useXAuthState({ a })          // one option
 *   useXAuthState({ a, b, c })    // the full option object
 *
 * `a` is where the data lives (filename, foldername, dbPath, url, uri, connectionString), `b` is the second level
 * (token, collection, table, connection name) and `c` is the session.
 */
/** True for a plain options object — not a class instance, client, pool or collection handle. */
export declare const isOptionsObject: (value: unknown) => value is Record<string, unknown>;
/**
 * Turns the accepted call shapes into one options object.
 *
 * - `keys` are the positional names in order, e.g. `['folder', 'session']`.
 * - A plain object first argument is treated as the options object when it carries at least one of `keys`; anything
 *   else (a pool, a collection, a client) is the positional `a`.
 * - A positional slot whose value is a plain object is spread, so `(folder, { session })` still works.
 */
export declare const normalizeAuthArgs: <T extends object>(args: unknown[], keys: readonly string[], 
/** every key that marks an argument as an options bag (defaults to `keys`) */
optionKeys?: readonly string[]) => T;
/** Normalises `a` when it may also arrive as `{ foldername }` / `{ filename }` / `{ dbpath }`. */
export declare const pickAlias: <T>(source: object, names: readonly string[]) => T | undefined;
/**
 * When a positional first argument is a live handle (a client, a pool, a collection, a database) it lands in the
 * "location" key, which expects a string. Move it to the key the adapter actually reads for that handle.
 */
export declare const promoteHandle: <T extends object>(opts: T, from: readonly string[], to: string, 
/** decides whether the value really is a live handle (a client, pool, collection, database) */
looksLikeHandle?: (value: unknown) => boolean) => T;
//# sourceMappingURL=auth-args.d.ts.map