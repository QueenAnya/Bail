/**
 * ffmpeg binary to spawn: the bundled `ffmpeg-static` binary when it was downloaded (so nothing has to be
 * installed on the machine or added to PATH), otherwise the system `ffmpeg`.
 *
 * `ffmpeg-static` downloads its binary in its install script; if your package manager skipped that script,
 * run `yarn rebuild ffmpeg-static` once.
 */
export declare const getFfmpegBin: () => string;
//# sourceMappingURL=ffmpeg-path.d.ts.map