/**
 * Re-exports message-composer from addons (canonical location).
 */
export * from '../Addons/message-composer.js';
//# sourceMappingURL=message-composer.d.ts.map