import type { OrderDetails } from '../Types/Product.js';
/**
 * Parse the `xwa_checkout_get_order_info` MEX response into the same
 * `OrderDetails` shape the legacy thrift-based `getOrderDetails` returns.
 */
export declare const parseMexOrderDetails: (value: unknown) => OrderDetails;
//# sourceMappingURL=business-mex.d.ts.map