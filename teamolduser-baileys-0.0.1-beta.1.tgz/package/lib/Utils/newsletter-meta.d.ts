import type { BinaryNode } from '../WABinary/index.js';
export interface NewsletterMessageMeta {
    adminProfile?: {
        id?: string;
        name?: string;
        pictureId?: string;
        pictureDirectPath?: string;
    };
    paidPartnership?: boolean;
    aiContent?: boolean;
    editTimestamp?: number;
    originalTimestamp?: number;
}
/** Reads the `<meta>` child of a newsletter `<message>` (admin profile, AI / paid-partnership labels, edit times). */
export declare const extractNewsletterMessageMeta: (stanza: BinaryNode) => NewsletterMessageMeta | undefined;
//# sourceMappingURL=newsletter-meta.d.ts.map