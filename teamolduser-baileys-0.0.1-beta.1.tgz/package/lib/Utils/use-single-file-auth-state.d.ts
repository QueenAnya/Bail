/**
 * use-single-file-auth-state.ts
 * Advanced single-file auth state with:
 *   - LRUCache (max 20000) for fast in-memory reads
 *   - Mutex to prevent race conditions on concurrent writes
 *   - Debounced atomic write (temp → rename) with 3s flush timeout
 *     so disk I/O is batched, not triggered on every key change
 */
import type { AuthenticationStateWithListing } from '../Types/index.js';
export interface SingleFileAuthStateOptions {
    /**
     * Namespace this session inside the file: keys are stored as `<session>:<key>`.
     *
     * Omit it (or pass `default`) and the file layout is exactly what it always was. Set it and several bots can share
     * one file without seeing each other's keys.
     */
    session?: string;
}
export declare const useSingleFileAuthState: (
/**
 * The file, or an options object. Accepted shapes:
 * `(file)`, `(file, { session })`, `({ filename })`, `({ filename, session })`.
 */
a: string | (SingleFileAuthStateOptions & {
    filename?: string;
    fileName?: string;
}), b?: SingleFileAuthStateOptions) => Promise<{
    state: AuthenticationStateWithListing;
    saveCreds: () => Promise<void>;
    saveState: () => Promise<void>;
    clearAuth: () => Promise<void>;
    /** writes immediately instead of waiting for the 3s debounce */
    flush: () => Promise<void>;
}>;
//# sourceMappingURL=use-single-file-auth-state.d.ts.map