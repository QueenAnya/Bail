import { type NewChatMessageCap, type NewChatMessageCapInfo } from '../Types/index.js';
/**
 * Turns the raw `xwa2_message_capping_info` reply into the object returned by `sock.fetchNewChatMessageCap()`.
 * No quota (or a negative one) means the account has nothing to count down, so it is reported as `unlimited`.
 */
export declare const parseNewChatMessageCap: (response: NewChatMessageCapInfo | null | undefined) => NewChatMessageCap;
//# sourceMappingURL=new-chat-cap.d.ts.map