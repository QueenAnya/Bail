export declare const PROTO_COMPAT_APPLIED: boolean;
/** true when every legacy field name resolves to its replacement */
export declare const FIELD_ALIASES_APPLIED: boolean;
//# sourceMappingURL=proto-compat.d.ts.map