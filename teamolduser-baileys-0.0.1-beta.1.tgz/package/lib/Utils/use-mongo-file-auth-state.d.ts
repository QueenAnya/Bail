import type { AuthenticationStateWithListing } from '../Types/index.js';
type MongoCollection = {
    findOne(filter: object): Promise<any>;
    /** optional: only needed for `list`/`listIds` (the migrator's source side) */
    find?(filter: object): {
        toArray?: () => Promise<any[]>;
    } | AsyncIterable<any>;
    updateOne(filter: object, update: object, options?: object): Promise<any>;
    deleteOne(filter: object): Promise<any>;
};
export interface MongoFileAuthStateOptions {
    /**
     * Namespace this session inside the collection: `_id`s become `<session>:<key>`.
     *
     * Omit it (or pass `default`) and the ids are exactly what they always were — one bot per collection. Set it and
     * several bots can share one collection, each with its own credentials.
     */
    session?: string;
}
/**
 * MongoDB auth state — stores Baileys credentials in a MongoDB collection.
 * Pass a MongoDB collection instance (e.g. from mongoose or native driver).
 */
export declare const useMongoFileAuthState: (
/**
 * The collection, or an options object. Accepted shapes:
 * `(collection)`, `(collection, { session })`, `({ collection, session })`.
 */
a: MongoCollection | (MongoFileAuthStateOptions & {
    collection?: MongoCollection;
}), b?: MongoFileAuthStateOptions) => Promise<{
    state: AuthenticationStateWithListing;
    saveCreds: () => Promise<void>;
}>;
/**
 * The name every fork uses, and the one that has to accept everything.
 *
 * Two adapters live behind it:
 * - a **collection** (this file's `useMongoFileAuthState`), the original Anya API;
 * - a **connection URI** (`useMongoAuthState2` from `Extras`), which creates and owns its own client.
 *
 * The two are told apart by what `a` is: a string, or a bag with `uri` / `url`, is a connection; anything with a
 * `collection` (or a collection-looking object) is a handle. The URI path is imported lazily so this file keeps no
 * module-level dependency on `Extras`.
 */
export declare const useMongoAuthState: (a: Parameters<typeof useMongoFileAuthState>[0] | string | {
    uri?: string;
    url?: string;
}, b?: Parameters<typeof useMongoFileAuthState>[1] | string, c?: string) => Promise<{
    state: AuthenticationStateWithListing;
    saveCreds: () => Promise<void>;
}>;
export {};
//# sourceMappingURL=use-mongo-file-auth-state.d.ts.map