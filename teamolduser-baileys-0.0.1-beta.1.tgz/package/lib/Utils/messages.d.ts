import { type Transform } from 'stream';
import './proto-compat.js';
import { proto } from '../../WAProto/index.js';
import type { AnyMediaMessageContent, AnyMessageContent, MessageContentGenerationOptions, MessageGenerationOptions, MessageGenerationOptionsFromContent, MessageUserReceipt, WAMessage, WAMessageContent, WAMessageKey } from '../Types/index.js';
import type { ILogger } from './logger.js';
import { type MediaDownloadOptions } from './messages-media.js';
type ExtractByKey<T, K extends PropertyKey> = T extends Record<K, any> ? T : never;
type RequireKey<T, K extends keyof T> = T & {
    [P in K]-?: Exclude<T[P], null | undefined>;
};
type WithKey<T, K extends PropertyKey> = T extends unknown ? (K extends keyof T ? RequireKey<T, K> : never) : never;
/**
 * Uses a regex to test whether the string contains a URL, and returns the URL if it does.
 * @param text eg. hello https://google.com
 * @returns the URL, eg. https://google.com
 */
export declare const extractUrlFromText: (text: string) => string | undefined;
export declare const generateLinkPreviewIfRequired: (text: string, getUrlInfo: MessageGenerationOptions["getUrlInfo"], logger: MessageGenerationOptions["logger"]) => Promise<import("../index.js").WAUrlInfo | undefined>;
/**
 * Hash that ties a photo-poll option to its picture: sha256(sha256(name) hex + base64(fileSha256)) hex.
 */
export declare const getPollOptionHash: (optionName: string, fileSha256?: Uint8Array | null) => string;
export declare const prepareWAMessageMedia: (message: AnyMediaMessageContent, options: MessageContentGenerationOptions) => Promise<proto.Message>;
export declare const prepareDisappearingMessageSettingContent: (ephemeralExpiration?: number) => proto.Message;
/**
 * Generate forwarded message content like WA does
 * @param message the message to forward
 * @param options.forceForward will show the message as forwarded even if it is from you
 */
export declare const generateForwardMessageContent: (message: WAMessage, forceForward?: boolean) => proto.Message.$Properties;
export declare const hasNonNullishProperty: <K extends PropertyKey>(message: AnyMessageContent, key: K) => message is ExtractByKey<AnyMessageContent, K>;
export declare function hasOptionalProperty<T, K extends PropertyKey>(obj: T, key: K): obj is WithKey<T, K>;
export declare const generateWAMessageContent: (message: AnyMessageContent, options: MessageContentGenerationOptions) => Promise<proto.Message>;
export declare const generateWAMessageFromContent: (jid: string, message: WAMessageContent, options: MessageGenerationOptionsFromContent) => WAMessage;
export declare const generateWAMessage: (jid: string, content: AnyMessageContent, options: MessageGenerationOptions) => Promise<WAMessage>;
/** Get the key to access the true type of content */
export declare const getContentType: (content: proto.IMessage | undefined) => keyof proto.IMessage | undefined;
/**
 * Message fields that wrap another message (`{ message: ... }`) and have to be unwrapped before the real content
 * (`conversation`, `imageMessage`, ...) can be read. Without a key listed here, `normalizeMessageContent` leaves that
 * message wrapped and its text/media looks empty.
 */
export declare const FUTURE_PROOF_MESSAGE_KEYS: readonly ["acp2SettingMessage", "associatedChildMessage", "audioStickerMessage", "botForwardedMessage", "botGroupParticipantMessage", "botInvokeMessage", "botPlatformRegistrationSuccessMessage", "botTaskMessage", "documentWithCaptionMessage", "editedMessage", "ephemeralMessage", "eventCoverImage", "groupMentionedMessage", "groupStatusMentionMessage", "groupStatusMessage", "groupStatusMessageV2", "limitSharingMessage", "lottieStickerMessage", "newsletterAdminProfileMessage", "newsletterAdminProfileMessageV2", "newsletterAdminProfileStatusMessage", "newsletterScheduledMessage", "pollCreationMessageV4", "pollCreationOptionImageMessage", "questionMessage", "questionReplyMessage", "spoilerMessage", "statusAddYours", "statusMentionMessage", "viewOnceMessage", "viewOnceMessageV2", "viewOnceMessageV2Extension"];
type FutureProofWrapper = {
    message?: WAMessageContent | null;
} | null | undefined;
/**
 * Normalizes ephemeral, view once (and every other wrapper in `FUTURE_PROOF_MESSAGE_KEYS`) messages to regular
 * message content
 * Eg. image messages in ephemeral messages, in view once messages etc.
 * @param content
 * @returns
 */
export declare const normalizeMessageContent: (content: WAMessageContent | null | undefined) => WAMessageContent | undefined;
/**
 * Elaina's spelling of the wrapper lookup above, with the doubled `e`.
 *
 * The literal Elaina function is kept below as a comment; the alias under it is what runs. It returns the same
 * wrapper object as `getFutureProofMessage`, so ported code that imports the misspelled name keeps working without
 * a second copy of the wrapper chain.
 */
export declare const getFutureProofMessagee: (message: WAMessageContent | null | undefined) => FutureProofWrapper;
/**
 * Extract the true message content from a message
 * Eg. extracts the inner message from a disappearing message/view once message
 */
export declare const extractMessageContent: (content: WAMessageContent | undefined | null) => WAMessageContent | undefined;
/**
 * Returns the device predicted by message ID
 */
export declare const getDevice: (id: string) => "web" | "unknown" | "android" | "ios" | "desktop";
/** Upserts a receipt in the message */
export declare const updateMessageWithReceipt: (msg: Pick<WAMessage, "userReceipt">, receipt: MessageUserReceipt) => void;
/** Update the message with a new reaction */
export declare const updateMessageWithReaction: (msg: Pick<WAMessage, "reactions">, reaction: proto.IReaction) => void;
/** Update the message with a new poll update */
export declare const updateMessageWithPollUpdate: (msg: Pick<WAMessage, "pollUpdates">, update: proto.IPollUpdate) => void;
/** Update the message with a new event response */
export declare const updateMessageWithEventResponse: (msg: Pick<WAMessage, "eventResponses">, update: proto.IEventResponse) => void;
type VoteAggregation = {
    name: string;
    voters: string[];
};
/**
 * Aggregates all poll updates in a poll.
 * @param msg the poll creation message
 * @param meId your jid
 * @returns A list of options & their voters
 */
export declare function getAggregateVotesInPollMessage({ message, pollUpdates }: Pick<WAMessage, 'pollUpdates' | 'message'>, meId?: string): VoteAggregation[];
type ResponseAggregation = {
    response: string;
    responders: string[];
};
/**
 * Aggregates all event responses in an event message.
 * @param msg the event creation message
 * @param meId your jid
 * @returns A list of response types & their responders
 */
export declare function getAggregateResponsesInEventMessage({ eventResponses }: Pick<WAMessage, 'eventResponses'>, meId?: string): ResponseAggregation[];
/** Given a list of message keys, aggregates them by chat & sender. Useful for sending read receipts in bulk */
export declare const aggregateMessageKeysNotFromMe: (keys: WAMessageKey[]) => {
    jid: string;
    participant: string | undefined;
    messageIds: string[];
}[];
type DownloadMediaMessageContext = {
    reuploadRequest: (msg: WAMessage) => Promise<WAMessage>;
    logger: ILogger;
};
/**
 * Downloads the given message. Throws an error if it's not a media message
 */
export declare const downloadMediaMessage: <Type extends "buffer" | "stream">(message: WAMessage, type: Type, options: MediaDownloadOptions, ctx?: DownloadMediaMessageContext) => Promise<Type extends "buffer" ? Buffer<ArrayBufferLike> : Transform>;
/**
 * Checks whether a message has valid album media (image or video).
 * Used in album send pipeline to validate individual album items.
 */
export declare const hasValidAlbumMedia: (message: proto.IMessage | null | undefined) => boolean;
/**
 * Checks whether a message has valid interactive header media.
 * Used to validate carousel/interactive message headers.
 */
export declare const hasValidInteractiveHeader: (message: proto.IMessage | null | undefined) => boolean;
/**
 * Checks whether a carousel card header carries valid media.
 * Ported from itsliaaa/baileys; additionally accepts `documentMessage`, which this fork's
 * carousel cards support (`document` slides). A card with no media at all is still allowed
 * (empty header, `hasMediaAttachment: false`); `generateWAMessageContent` only throws a 400
 * for a header that carries content which is not one of these media types.
 */
export declare const hasValidCarouselHeader: (message: proto.IMessage | null | undefined) => boolean;
/** Checks whether the given message is a media message; if it is returns the inner content */
export declare const assertMediaContent: (content: proto.IMessage | null | undefined) => proto.Message.DocumentMessage.$Properties | proto.Message.ImageMessage.$Properties | proto.Message.VideoMessage.$Properties | proto.Message.AudioMessage.$Properties | proto.Message.StickerMessage.$Properties;
export {};
//# sourceMappingURL=messages.d.ts.map