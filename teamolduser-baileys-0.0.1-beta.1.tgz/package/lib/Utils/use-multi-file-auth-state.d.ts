import type { AuthenticationStateWithListing } from '../Types/index.js';
/** number of file paths currently tracked by the per-file lock map (idle entries are removed) */
export declare const countAuthFileLocks: () => number;
/**
 * stores the full authentication state in a single folder.
 * Far more efficient than singlefileauthstate
 *
 * Again, I wouldn't endorse this for any production level use other than perhaps a bot.
 * Would recommend writing an auth state for use with a proper SQL or No-SQL DB
 * */
export interface MultiFileAuthStateOptions {
    /**
     * Namespace this session inside the folder: files live in `<folder>/<session>`.
     *
     * Omit it (or pass `default`) and the layout is exactly what it always was — one folder, one session. Set it and
     * several bots can share one folder, each in its own subdirectory.
     */
    session?: string;
}
export declare const useMultiFileAuthState: (
/**
 * The folder, or an options object. Accepted shapes:
 * `(folder)`, `(folder, { session })`, `({ foldername })`, `({ foldername, session })`.
 */
a: string | (MultiFileAuthStateOptions & {
    foldername?: string;
    folder?: string;
}), b?: MultiFileAuthStateOptions) => Promise<{
    state: AuthenticationStateWithListing;
    saveCreds: () => Promise<void>;
    clearAuth: () => Promise<void>;
}>;
//# sourceMappingURL=use-multi-file-auth-state.d.ts.map