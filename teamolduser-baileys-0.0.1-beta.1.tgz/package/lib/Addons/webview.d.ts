/** the bot JID the forwarded-AI styling is attributed to */
export declare const HTML_WEBVIEW_BOT_JID = "867051314767696@bot";
/** forwardOrigin value for a Meta-AI forwarded bot message */
export declare const FORWARD_ORIGIN_META_AI = 4;
/** botEntryPointOrigin value for a Meta-AI forward */
export declare const BOT_ENTRY_POINT_META_AI_FORWARD = 31;
export interface WebViewOptions {
    /** the page — sent byte-for-byte as given */
    html: string;
    /** disclaimer text and notification preview */
    title?: string;
    /** preview line on the card */
    label?: string;
    /** `true` (default) = Meta-AI forward styling, `false` = clean origin without the "Forwarded" badge */
    forwarded?: boolean;
    /** quote an existing message */
    quoted?: {
        key?: {
            id?: string;
            remoteJid?: string;
            participant?: string;
        };
        message?: any;
        id?: string;
        participant?: string;
    };
    /** reuse a specific message id instead of generating one */
    messageId?: string;
}
export interface WebViewResult {
    key: {
        remoteJid?: string | null;
        fromMe?: boolean;
        id: string;
    };
    messageId: string;
}
/** the only two things this needs from the socket */
export interface HtmlWebviewSocket {
    relayMessage: (jid: string, message: any, options?: any) => Promise<unknown>;
    user?: {
        id?: string;
    };
}
/**
 * @example
 * await webView(sock, jid, { html: '<!DOCTYPE html>…', title: 'Order status' })
 * await web(sock, jid, { html })            // same function
 */
export declare function webView(sock: HtmlWebviewSocket, chatId: string, options: WebViewOptions): Promise<WebViewResult>;
/** short alias — `web(sock, jid, { html })` */
export declare const web: typeof webView;
/** the name this shipped under first; kept so existing code keeps working */
export declare const sendHtmlWebview: typeof webView;
//# sourceMappingURL=webview.d.ts.map