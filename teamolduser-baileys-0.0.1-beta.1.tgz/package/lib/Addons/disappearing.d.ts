/**
 * Shorthand values accepted by `sock.updateDefaultDisappearingMode` / `updateDefaultDisappearing` /
 * `updateDisappearingDuration`:
 *
 * | value   | meaning                | seconds   |
 * | ------- | ---------------------- | --------- |
 * | `0`     | off                    | `0`       |
 * | `1`/`24`| 24 hours (1 day)       | `86400`   |
 * | `7`     | 7 days                 | `604800`  |
 * | `30`    | 30 days                | `2592000` |
 * | `90`    | 90 days                | `7776000` |
 *
 * Any other number is taken as a number of seconds (so `86400`, `604800`, ... keep working as before).
 */
export declare const DISAPPEARING_SHORTHANDS: Readonly<Record<number, number>>;
/** Converts `24` / `1` / `7` / `30` / `90` (hours / days) to seconds; every other value is returned as seconds. */
export declare const normalizeDisappearingDuration: (duration: number | string) => number;
//# sourceMappingURL=disappearing.d.ts.map