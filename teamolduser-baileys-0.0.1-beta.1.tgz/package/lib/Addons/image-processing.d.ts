/** Returns `{ sharp }`, `{ image }` or `{ jimp }` (first one installed). Cached after first load. */
export declare const getImageProcessingLibrary: () => Promise<{
    sharp: {
        default: typeof import("sharp");
        cache(options?: boolean | import("sharp").CacheOptions): import("sharp").CacheResult;
        concurrency(concurrency?: number): number;
        counters(): import("sharp").SharpCounters;
        simd(enable?: boolean): boolean;
        block(options: {
            operation: string[];
        }): void;
        unblock(options: {
            operation: string[];
        }): void;
        format: import("sharp").FormatEnum;
        versions: {
            aom?: string | undefined;
            archive?: string | undefined;
            cairo?: string | undefined;
            cgif?: string | undefined;
            exif?: string | undefined;
            expat?: string | undefined;
            ffi?: string | undefined;
            fontconfig?: string | undefined;
            freetype?: string | undefined;
            fribidi?: string | undefined;
            glib?: string | undefined;
            harfbuzz?: string | undefined;
            heif?: string | undefined;
            highway?: string | undefined;
            imagequant?: string | undefined;
            lcms?: string | undefined;
            mozjpeg?: string | undefined;
            pango?: string | undefined;
            pixman?: string | undefined;
            png?: string | undefined;
            "proxy-libintl"?: string | undefined;
            rsvg?: string | undefined;
            sharp: string;
            spng?: string | undefined;
            tiff?: string | undefined;
            vips: string;
            webp?: string | undefined;
            xml?: string | undefined;
            "zlib-ng"?: string | undefined;
        };
        interpolators: import("sharp").Interpolators;
        queue: NodeJS.EventEmitter;
        gravity: import("sharp").GravityEnum;
        strategy: import("sharp").StrategyEnum;
        kernel: import("sharp").KernelEnum;
        fit: import("sharp").FitEnum;
        bool: import("sharp").BoolEnum;
    };
    image?: undefined;
    jimp?: undefined;
} | {
    image: {
        default: typeof import("@napi-rs/image");
        compressJpeg(input: Uint8Array, options?: import("@napi-rs/image").JpegCompressOptions | undefined | null, signal?: AbortSignal | undefined | null): Promise<Buffer>;
        compressJpegSync(input: Uint8Array, options?: import("@napi-rs/image").JpegCompressOptions | undefined | null): Buffer;
        losslessCompressPng(input: Uint8Array, options?: import("@napi-rs/image").PNGLosslessOptions | undefined | null, signal?: AbortSignal | undefined | null): Promise<Buffer>;
        losslessCompressPngSync(input: Buffer, options?: import("@napi-rs/image").PNGLosslessOptions | undefined | null): Buffer;
        pngQuantize(input: Uint8Array, options?: import("@napi-rs/image").PngQuantOptions | undefined | null, signal?: AbortSignal | undefined | null): Promise<Buffer>;
        pngQuantizeSync(input: Uint8Array, options?: import("@napi-rs/image").PngQuantOptions | undefined | null): Buffer;
        __napiBindingTarget: "native" | "wasm32-wasi" | "wasm32-wasip1";
        Transformer: typeof import("@napi-rs/image").Transformer;
        BlendMode: typeof import("@napi-rs/image").BlendMode;
        ChromaSubsampling: typeof import("@napi-rs/image").ChromaSubsampling;
        CompressionType: typeof import("@napi-rs/image").CompressionType;
        FastResizeFilter: typeof import("@napi-rs/image").FastResizeFilter;
        FilterType: typeof import("@napi-rs/image").FilterType;
        Gravity: typeof import("@napi-rs/image").Gravity;
        JsColorType: typeof import("@napi-rs/image").JsColorType;
        Orientation: typeof import("@napi-rs/image").Orientation;
        PngRowFilter: typeof import("@napi-rs/image").PngRowFilter;
        ResizeFilterType: typeof import("@napi-rs/image").ResizeFilterType;
        ResizeFit: typeof import("@napi-rs/image").ResizeFit;
    };
    sharp?: undefined;
    jimp?: undefined;
} | {
    jimp: typeof import("jimp");
    sharp?: undefined;
    image?: undefined;
}>;
/** Forget the cached library (mainly for tests). */
export declare const clearImageProcessingLibraryCache: () => void;
/** Name of the active library — 'sharp' | 'image' | 'jimp'. */
export declare const getImageProcessingLibraryName: () => Promise<"sharp" | "image" | "jimp">;
//# sourceMappingURL=image-processing.d.ts.map