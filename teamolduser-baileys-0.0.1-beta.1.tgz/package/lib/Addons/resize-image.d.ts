import type { WAMediaUpload } from '../Types/index.js';
/**
 * `sock.resize(image, width, height)` — resizes an image (Buffer, `{ url }`, `{ stream }`, http(s) URL or
 * local file path) to exactly `width` x `height` and returns it as a JPEG Buffer; typically used for
 * `jpegThumbnail`, e.g. `jpegThumbnail: await sock.resize('https://example.com/pic.jpg', 320, 320)`.
 * (Documented in the @innovatorssoft/baileys README.)
 */
export declare const resizeImage: (media: WAMediaUpload | string, width?: number, height?: number) => Promise<Buffer>;
//# sourceMappingURL=resize-image.d.ts.map