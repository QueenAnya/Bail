import { proto } from '../../WAProto/index.js';
import type { MessageContentGenerationOptions } from '../Types/index.js';
import type { AdminInviteInfo, CallCreationInfo, PaymentInviteInfo, PaymentMessageOptions, StickerPack } from '../Types/Message.js';
/**
 * Build newsletterAdminInviteMessage from adminInvite content
 */
export declare function buildAdminInviteMessage(adminInvite: AdminInviteInfo, contextInfo: any, options: MessageContentGenerationOptions): Promise<proto.Message.INewsletterAdminInviteMessage>;
/**
 * Build scheduledCallCreationMessage from call content, including the
 * 'Call Creation' default title.
 */
export declare function buildCallMessage(call: CallCreationInfo): proto.Message.IScheduledCallCreationMessage;
/**
 * Build paymentInviteMessage from paymentInvite content
 */
export declare function buildPaymentInviteMessage(paymentInvite: PaymentInviteInfo): proto.Message.IPaymentInviteMessage;
/**
 * Build requestPaymentMessage from payment content. `amount` is in the
 * currency's smallest unit (e.g. cents) — both the legacy `amount1000`
 * field and the modern `Money` shape are populated for compatibility.
 */
export declare function buildPaymentMessage(payment: PaymentMessageOptions): proto.Message.IRequestPaymentMessage;
/**
 * Check if buffer is a valid WebP file (magic bytes: RIFF....WEBP)
 * Source: PR #84 rsalcara/InfiniteAPI
 */
export declare function isWebPBuffer(buffer: Buffer): boolean;
/**
 * Detect animated WebP by checking VP8X chunk animation flag
 * Source: PR #84 rsalcara/InfiniteAPI
 */
export declare function isAnimatedWebP(buffer: Buffer): boolean;
/**
 * Detect Lottie/WAS format (gzip-compressed or raw Lottie JSON)
 * WAS = WhatsApp Animated Sticker = gzip-compressed Lottie JSON
 * Source: PR #260 rsalcara/InfiniteAPI
 */
export declare function isLottieBuffer(buffer: Buffer): boolean;
/**
 * How many stickers are converted at the same time. Set `concurrency` on the sticker pack to change it
 * (lower = less RAM/CPU, higher = potentially faster); invalid values fall back to the default (15).
 * Decimals are rounded down, anything below 1 becomes 1.
 */
export declare const resolveStickerPackConcurrency: (value?: number | null) => number;
/** Options for converting a non-WebP sticker (all optional; defaults = original size, original quality = lossless WebP). */
export type StickerWebpOptions = {
    /** pad to a transparent square (longest side) */
    square?: boolean;
    /** longest side in px - the image is only ever scaled DOWN to it (never upscaled) */
    maxSize?: number;
    /** `'original'` (default) = LOSSLESS WebP (original quality); a number 1-100 = lossy WebP of that quality */
    quality?: number | 'original';
};
/**
 * Sticker-pack images keep their ORIGINAL size by default (no cap). Set `maxSize` on the sticker pack to scale the longest
 * side DOWN to that many px (never upscaled), e.g. `512` = WhatsApp's own sticker size.
 * `undefined` / `false` / `0` / invalid -> keep the original size (`undefined`), a number >= 1 -> that many px (rounded down).
 */
export declare const resolveStickerPackMaxSize: (value?: number | false | null) => number | undefined;
/** `'original'`/`undefined`/invalid -> `undefined` = LOSSLESS WebP (original quality); a number is clamped to 1-100 (lossy WebP). */
export declare const resolveStickerQuality: (value?: number | "original" | null) => number | undefined;
/**
 * Convert any image/GIF to a WebP sticker. By default (no options) at its ORIGINAL size and quality: no cap, no upscaling,
 * lossless WebP (original quality). `maxSize` scales the longest side DOWN (never up), `quality` (1-100) switches to lossy WebP
 * (`'original'` = the default, lossless). The sticker pack builders pass the pack's own `maxSize` / `quality`. Quality is NEVER lowered automatically.
 * `square: true` pads to a transparent square whose side is the image's longest side (aspect kept;
 * WhatsApp's pack viewer squeezes non-square stickers).
 * Animated inputs (GIF/APNG/animated WebP) stay animated.
 */
export declare const sharpToStickerWebp: (sharpDefault: any, buffer: Buffer, opts?: StickerWebpOptions) => Promise<Buffer>;
/**
 * Anything → WebP sticker, itsliaaa-style auto conversion with innovatorssoft-style fidelity:
 *   - already WebP            → bytes untouched (original size, quality, EXIF, animation)
 *   - PNG / JPG / GIF / ...   → WebP, lossless / original quality (never lowered automatically); original size unless `maxSize` is given
 *   - video (mp4/webm/mkv...) → animated WebP via ffmpeg, original size
 * Never resized or padded unless the caller passes `square: true` (opt-in, not used by packs).
 */
export declare const toStickerWebp: (buffer: Buffer, opts?: StickerWebpOptions) => Promise<Buffer>;
export declare function buildStickerPackMessage(stickerPack: StickerPack, options: MessageContentGenerationOptions): Promise<proto.Message.IStickerPackMessage>;
//# sourceMappingURL=from-messages.d.ts.map