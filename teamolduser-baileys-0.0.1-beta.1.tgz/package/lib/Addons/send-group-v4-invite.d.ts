/**
 * send-group-v4-invite.ts
 * Source: src/Socket/messages-send.ts
 *
 * `sendGroupV4Invite` (+ `sendGroupInviteV4` alias) — sends a WhatsApp v4
 * group-invite message directly to a participant, and `sendGroupInvite` —
 * adds a participant via `groupParticipantsUpdate`, automatically falling
 * back to a v4 invite when WhatsApp refuses the direct add (status 403).
 * Imported back into makeMessagesSocket.
 */
import type { GroupInviteAttemptResult, MiscMessageGenerationOptions, WAMessage } from '../Types/index.js';
import type { ParticipantAction } from '../Types/GroupMetadata.js';
import { generateWAMessageFromContent } from '../Utils/messages.js';
import type { BinaryNode } from '../WABinary/index.js';
export interface GroupParticipantUpdateResult {
    status: string;
    jid: string | undefined;
    content: BinaryNode;
}
export interface SendGroupV4InviteDeps {
    /** `authState.creds.me!.id` — the sender's own jid. */
    meId: string;
    relayMessage: (jid: string, message: any, opts: any) => Promise<any>;
    groupMetadata: (jid: string) => Promise<{
        subject: string;
    }>;
    profilePictureUrl: (jid: string, type: 'image' | 'preview') => Promise<string | undefined>;
    groupParticipantsUpdate: (jid: string, participants: string[], action: ParticipantAction) => Promise<GroupParticipantUpdateResult[]>;
    httpRequestOptions?: any;
    /** Override for tests; defaults to the real `generateWAMessageFromContent`. */
    generateWAMessageFromContentFn?: typeof generateWAMessageFromContent;
}
/**
 * Sends a WhatsApp v4 group-invite message directly to `participant`
 * (not to the group itself). Lower-level than `content.groupInvite`:
 * it doesn't auto-fetch a group profile picture — pass `jpegThumbnail`
 * yourself if you want one shown. Shared implementation behind
 * `sock.sendGroupV4Invite`, `sock.sendGroupInviteV4`, and the
 * `sendMessage(jid, { sendGroupV4Invite / sendGroupInviteV4 })` content keys.
 */
export declare function sendGroupV4Invite(deps: SendGroupV4InviteDeps, groupJid: string, participant: string, inviteCode: string, inviteExpiration?: number, groupName?: string, caption?: string, jpegThumbnail?: Buffer, options?: MiscMessageGenerationOptions): Promise<WAMessage>;
/**
 * Adds `user` to `groupJid` via `groupParticipantsUpdate`. If WhatsApp
 * refuses the direct add (status 403 — e.g. the group requires an
 * invite), automatically falls back to sending that participant a v4
 * group-invite message (`sendGroupV4Invite` above) using the invite
 * code/expiration WhatsApp returned in the 403 response, with the
 * group's own display picture as the thumbnail. Any other non-200 status
 * (401, 404, 408, 409, 500, ...) is reported as-is via `GROUP_ADD_STATUS_MESSAGES`,
 * with `invited: false` — no invite is sent for those.
 */
export declare function sendGroupInvite(deps: SendGroupV4InviteDeps, groupJid: string, user: string): Promise<GroupInviteAttemptResult[]>;
//# sourceMappingURL=send-group-v4-invite.d.ts.map