import type { AuthenticationStateWithListing } from '../Types/index.js';
/** Minimal interface compatible with any cache-manager v5 store */
export type CacheManagerStore = {
    set(key: string, value: string, ttl?: number): Promise<void>;
    get(key: string): Promise<string | undefined | null>;
    del(key: string): Promise<void>;
    keys(pattern?: string): Promise<string[]>;
};
export declare const useCacheManagerAuthState: (
/**
 * Accepted shapes: `(store, sessionKey)`, `({ store, sessionKey })`, `({ store, session })`.
 */
a: CacheManagerStore | {
    store?: CacheManagerStore;
    sessionKey?: string;
    session?: string;
}, b?: string | {
    sessionKey?: string;
    session?: string;
}) => Promise<{
    state: AuthenticationStateWithListing;
    saveCreds: () => Promise<void>;
    clearState: () => Promise<void>;
}>;
/** Alias of {@link useCacheManagerAuthState}, kept for naming compatibility with the innovatorssoft fork. */
export declare const makeCacheManagerAuthState: (a: CacheManagerStore | {
    store?: CacheManagerStore;
    sessionKey?: string;
    session?: string;
}, b?: string | {
    sessionKey?: string;
    session?: string;
}) => Promise<{
    state: AuthenticationStateWithListing;
    saveCreds: () => Promise<void>;
    clearState: () => Promise<void>;
}>;
//# sourceMappingURL=use-cache-manager-auth-state.d.ts.map