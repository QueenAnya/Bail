import type { AnyMessageContent } from '../Types/Message.js';
import type { MessageGenerationOptions } from '../Types/Message.js';
/**
 * Alternate implementation of the Group Status (groupStatusMessageV2) helper,
 * kept alongside `sendGroupStatus` (send-group-status.ts) rather than
 * replacing it. Differs from `sendGroupStatus` in a few ways:
 *   - Requires `sock.user` to already be set (throws otherwise) instead of
 *     passing a possibly-undefined `userJid` through to `generateWAMessage`.
 *   - Mutates the plain `generateWAMessage` result object directly (no
 *     `proto.Message.create()` re-wrap).
 *   - Assigns its own `4NY4W3B`-prefixed message ID (matching the ID shape a
 *     real WhatsApp client uses for group-status messages) instead of
 *     reusing whatever ID `generateWAMessage` generated, unless the caller
 *     already supplied one via `options.messageId`.
 *
 * Usage: await sock.sendGroupStatusV2(groupJid, { text: 'Hello group!' })
 */
export declare function GroupStatusV2(sock: any, jid: string, content: AnyMessageContent, options?: Partial<MessageGenerationOptions>): Promise<import("../index.js").WAMessage>;
//# sourceMappingURL=group-status-v2.d.ts.map