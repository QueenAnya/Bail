/**
 * presence-monitor.ts
 * Source: @innovatorssoft/baileys fork (lib/Utils/presence-monitor.js + .d.ts)
 *
 * Monitors online/offline presence transitions for one or more WhatsApp
 * contacts. Consumes the existing `presence.update` event emitted by the
 * socket and automatically calls `sock.presenceSubscribe` on start (and on
 * reconnect, if `autoResubscribe` is enabled). No polling, no duplicate
 * low-level WS listeners.
 *
 * PN/LID behavior:
 *   - Tries PN subscription first.
 *   - If a `signalRepository.lidMapping` is available, uses `getLIDForPN(pn)`
 *     as the documented fallback mechanism for PN→LID resolution, falling
 *     back further to `onWhatsApp` if that cache misses.
 *   - Also listens for `lid-mapping.update` events to re-subscribe with the
 *     newly resolved LID when a mapping arrives asynchronously.
 *   - Matches presence event participants with `areJidsSameUser` so updates
 *     arrive for the same user whether emitted as a PN or a LID.
 *
 * Last-seen:
 *   - Only exposed via `lastSeen` when the underlying `PresenceData`
 *     actually includes a numeric `lastSeen` value (WhatsApp protocol /
 *     privacy permitting). `offlineAt` is NEVER reported as `lastSeen`.
 *
 * Session semantics:
 *   - A session is `available → unavailable` only.
 *   - Duplicate `available` or `unavailable` events are idempotent (no
 *     duplicate online/offline/session emissions).
 *   - Receiving `unavailable` with no prior online state is a no-op for
 *     session bookkeeping (status updates to offline but no fake duration /
 *     no session event).
 *   - Socket reconnects do NOT fabricate fake transitions; subscriptions are
 *     renewed (if configured) and the monitor waits for the next real event.
 *
 * @example
 * ```ts
 * const monitor = monitorPresence(sock, '923001234567@s.whatsapp.net', {
 *     logToConsole: true,
 *     autoResubscribe: true,
 *     timezone: '+05:00'
 * })
 *
 * monitor.on('online',  data => console.log('ONLINE ', data))
 * monitor.on('offline', data => console.log('OFFLINE', data))
 * monitor.on('session', s    => console.log('SESSION', s))
 * monitor.on('error',   err  => console.error(err))
 *
 * // Later:
 * // monitor.stop()
 * ```
 */
import type { LIDMappingStore } from '../Signal/lid-mapping.js';
import type { BaileysEventEmitter } from '../Types/Events.js';
export type PresenceStatus = 'online' | 'offline';
export interface PresenceMonitorOptions {
    /**
     * Log transitions to console in the format:
     * `[Presence] <jid> is ONLINE/OFFLINE at <time>` / `[Presence] Online duration: HH:MM:SS`
     *
     * @default false
     */
    logToConsole?: boolean;
    /**
     * Automatically re-subscribe presence after the socket reconnects
     * (when `connection.update` fires with `connection === 'open'`).
     *
     * @default false
     */
    autoResubscribe?: boolean;
    /**
     * Optional timezone for display formatting, e.g. `'+05:00'` or `'-03:00'`.
     * Only affects presentation formatting; timestamps remain as reliable epoch values.
     */
    timezone?: string;
    /**
     * Treat an incoming message from a watched contact as an `available` presence signal
     * (useful when WhatsApp does not push presence updates for that contact).
     *
     * @default false
     */
    trackMessagesAsPresence?: boolean;
}
export interface PresenceOnlineEvent {
    /** The JID as originally requested by the caller */
    jid: string;
    status: 'online';
    /** Epoch ms when the online transition was observed */
    onlineAt: number;
    /**
     * If the underlying presence payload carried an actual WhatsApp `lastSeen` timestamp
     * (unix seconds), it is exposed here. Otherwise the property is omitted.
     *
     * This field is controlled by WhatsApp privacy settings and may not be available.
     * It is NEVER inferred from `offlineAt`.
     */
    lastSeen?: number;
}
export interface PresenceOfflineEvent {
    /** The JID as originally requested by the caller */
    jid: string;
    status: 'offline';
    onlineAt: number;
    /** Epoch ms when the offline transition was observed */
    offlineAt: number;
    /** Session duration in milliseconds */
    durationMs: number;
    /** Session duration formatted as `HH:MM:SS` (hours do not wrap at 24) */
    duration: string;
    /** Actual WhatsApp lastSeen if present on the underlying event; otherwise omitted */
    lastSeen?: number;
}
export interface PresenceSessionSummary extends PresenceOfflineEvent {
    status: 'offline';
}
export interface PresenceStateView {
    jid: string;
    status: PresenceStatus;
    onlineAt: number | null;
    offlineAt: number | null;
    durationMs: number | null;
    duration: string | null;
    lastSeen: number | null;
}
/** Session as returned by {@link PresenceMonitor.getStatus} (timestamps as `Date`). */
export interface PresenceTrackerSession {
    jid: string;
    onlineAt: Date;
    offlineAt: Date;
    durationMs: number;
    duration: string;
}
/** Rich per-contact status returned by {@link PresenceMonitor.getStatus}. */
export interface PresenceTrackerStatus {
    jid: string;
    lid?: string;
    currentStatus: 'online' | 'offline' | 'unknown';
    currentSessionStart?: Date;
    lastSeen?: Date;
    serverLastSeen?: Date;
    lastOfflineAt?: Date;
    lastDurationMs?: number;
    lastDuration?: string;
    sessions: PresenceTrackerSession[];
}
export type PresenceMonitorEvents = {
    online: PresenceOnlineEvent;
    offline: PresenceOfflineEvent;
    session: PresenceSessionSummary;
    error: Error;
};
export interface MinimalSocket {
    ev: Pick<BaileysEventEmitter, 'on' | 'off'>;
    presenceSubscribe?: (toJid: string, tcToken?: Buffer | undefined) => Promise<void> | void;
    signalRepository?: {
        lidMapping?: LIDMappingStore;
    };
    /** Used as a fallback PN→LID resolver when `signalRepository.lidMapping` misses. */
    onWhatsApp?: (...phoneNumber: string[]) => Promise<Array<{
        jid: string;
        lid?: string;
        pn?: string;
    }> | undefined>;
}
/**
 * Format a duration in milliseconds as `HH:MM:SS`. Hours are not wrapped at 24,
 * so a 27-hour session is correctly formatted as `27:15:04`.
 *
 * @param durationMs Duration in milliseconds
 */
export declare const formatDuration: (durationMs: number) => string;
/** Current global default timezone, used whenever no per-monitor/per-call timezone is given. */
export declare const getDefaultTimezone: () => string | number;
/**
 * Set the global default timezone (`'+05:00'`, `'+5'`, `5`, `'Asia/Karachi'`, `'UTC'`).
 * Ported from @innovatorssoft/baileys; unlike that fork the initial default is `'UTC'`.
 */
export declare const setDefaultTimezone: (zone: string | number) => void;
/** `HH:MM:SS` in the given timezone (falls back to the global default, see {@link setDefaultTimezone}). */
export declare const formatTime: (date: Date | number | null | undefined, zone?: string | number | null) => string;
/** `YYYY-MM-DD HH:MM:SS` in the given timezone (falls back to the global default). */
export declare const formatDateTime: (date: Date | number | null | undefined, zone?: string | number | null) => string;
/** Human-readable relative time, e.g. `45s ago`, `3m ago`, `2h ago`, `4d ago`. */
export declare const formatTimeAgo: (value: Date | number | null | undefined) => string;
/**
 * Normalize user input (`923001234567`, `...@c.us`, `...@whatsapp.net`, a LID, ...) into a
 * valid WhatsApp user JID. Returns `''` for empty / non-string input.
 */
export declare const normalizeContactJid: (jid: string) => string;
/**
 * Monitor online/offline presence transitions for one or more WhatsApp contacts.
 * See the module doc comment above for full behavior notes.
 */
export declare class PresenceMonitor {
    private readonly sock;
    private readonly options;
    private readonly requestedJids;
    private readonly states;
    private readonly sessions;
    private readonly subscribedJids;
    private readonly listeners;
    /** Bidirectional PN↔LID mapping for cross-JID presence correlation. */
    private readonly pnLidPairs;
    private started;
    private stopped;
    private listenersAttached;
    private timezone;
    constructor(sock: MinimalSocket, targets: string | string[], options?: PresenceMonitorOptions);
    /** Register an event listener */
    on<E extends keyof PresenceMonitorEvents>(event: E, listener: (arg: PresenceMonitorEvents[E]) => void): this;
    /** Remove an event listener */
    off<E extends keyof PresenceMonitorEvents>(event: E, listener: (arg: PresenceMonitorEvents[E]) => void): this;
    /** Remove all listeners (optionally scoped to a single event) */
    removeAllListeners(event?: keyof PresenceMonitorEvents): this;
    /** @internal — used by monitorPresence() below; not part of the public API surface. */
    emit<E extends keyof PresenceMonitorEvents>(event: E, payload: PresenceMonitorEvents[E]): void;
    private notifyErrorListeners;
    private logOnline;
    private logOffline;
    /**
     * Start monitoring: attach listeners and subscribe presence for the target JIDs.
     * Called implicitly by the `monitorPresence(...)` factory.
     */
    start(): Promise<this>;
    /**
     * Stop monitoring: detach all socket event listeners and clear subscription bookkeeping.
     * After `stop()` the monitor cannot be restarted — create a new instance instead.
     */
    stop(): void;
    private attachListeners;
    private detachListeners;
    private subscribeAll;
    /**
     * Subscribe to presence for a contact, proactively resolving and subscribing
     * to both PN and LID (mirroring the working reference implementation).
     */
    private subscribeOne;
    /** Store bidirectional PN↔LID mapping for cross-JID presence correlation */
    private recordPnLidPair;
    private mirrorStateForAlternateJid;
    /** Find the canonical (requested) JID for a participant matching by user or PN↔LID pair */
    private findCanonicalForParticipant;
    private onConnectionUpdate;
    private onLidMappingUpdate;
    private resolvePublicJid;
    private isWatched;
    private onPresenceUpdate;
    private onMessagesUpsert;
    private handlePresenceForParticipant;
    private transitionOnline;
    private transitionOffline;
    /**
     * Return the current presence state for a single monitored JID, or `null` if unknown.
     * If called without arguments, returns a map `{ [jid]: PresenceStateView }` keyed by
     * the originally requested JIDs.
     */
    getState(jid?: string): PresenceStateView | null | Record<string, PresenceStateView>;
    private findStateByUser;
    private publicState;
    /**
     * Return the most recent completed session for `jid`, or `null` if no session has
     * completed yet.
     */
    getSession(jid: string): PresenceSessionSummary | null;
    /**
     * Return all completed sessions for `jid`, or — if `jid` is omitted — a map
     * `{ [jid]: PresenceSessionSummary[] }` for every monitored contact.
     */
    getSessions(jid?: string): PresenceSessionSummary[] | Record<string, PresenceSessionSummary[]>;
    private resolveSessions;
    /** True if the given JID (or its user) is being monitored */
    isMonitoring(jid: string): boolean;
    /** Change the display timezone (`'+05:00'`, `'+5'`, `5`, `'Asia/Karachi'`, `'UTC'`). */
    setTimezone(zone: string | number): void;
    /** The display timezone currently used by `formatTime` / `formatDateTime`. */
    getTimezone(): string;
    /** `HH:MM:SS` in this monitor's timezone. Accepts a `Date`, epoch ms or epoch seconds. */
    formatTime(date: Date | number | null | undefined): string;
    /** `YYYY-MM-DD HH:MM:SS` in this monitor's timezone. Accepts a `Date`, epoch ms or epoch seconds. */
    formatDateTime(date: Date | number | null | undefined): string;
    /**
     * Rich status for one contact (`currentStatus` is `'unknown'` until the first presence
     * signal arrives), or `undefined` if the JID is not monitored.
     */
    getStatus(jid: string): PresenceTrackerStatus | undefined;
    /** Rich status for every monitored contact, keyed by the originally requested JID. */
    getAllStatuses(): Map<string, PresenceTrackerStatus>;
    /** Re-send the presence subscription for a contact (and its paired LID, if known). */
    resubscribe(jid: string): Promise<void>;
    /** Start monitoring one or more additional contacts and subscribe to their presence. */
    subscribe(jid: string | string[]): Promise<void>;
    /** The list of JIDs originally passed to `monitorPresence(...)` */
    getMonitoredJids(): string[];
}
/**
 * Factory helper. Creates a {@link PresenceMonitor} and begins monitoring
 * (async subscriptions fire in the microtask queue so errors route to the
 * `error` event rather than throwing synchronously at the call-site).
 */
export declare const monitorPresence: (sock: MinimalSocket, targets: string | string[], options?: PresenceMonitorOptions) => PresenceMonitor;
/** `true` for any WA presence that means the contact is active (`available`, `composing`, `recording`, `paused`). */
export declare const isOnlinePresence: (presence: string | null | undefined) => boolean;
/** `true` when the WA presence is `unavailable`. */
export declare const isOfflinePresence: (presence: string | null | undefined) => boolean;
/** Name used by @innovatorssoft/baileys — same class as {@link PresenceMonitor}. */
export { PresenceMonitor as PresenceTracker };
/** Name used by @innovatorssoft/baileys — same function as {@link monitorPresence}. */
export declare const createPresenceTracker: (sock: MinimalSocket, targets: string | string[], options?: PresenceMonitorOptions) => PresenceMonitor;
//# sourceMappingURL=presence-monitor.d.ts.map