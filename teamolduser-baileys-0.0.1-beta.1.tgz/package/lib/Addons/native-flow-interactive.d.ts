import type { proto } from '../../WAProto/index.js';
type AnyRecord = Record<string, any>;
/**
 * Resolves a button label across the spellings accepted by Baileys helpers.
 * Priority: display_text, text, displayText, displaytext, then buttonText.
 */
export declare const resolveButtonText: (b: AnyRecord | null | undefined) => string | undefined;
/**
 * Builds the `messageParamsJson` blob for a native-flow message:
 * `limited_time_offer` (offerText/offerCode/offerUrl/offerExpiration) and
 * `bottom_sheet` (optionText/optionTitle).
 *
 * WhatsApp reads `limited_time_offer` as `{ text, url, copy_code,
 * expiration_time }` — the key names every working fork uses. `offerExpiration`
 * is accepted in milliseconds (e.g. `Date.now() + 3_600_000`) and converted to
 * epoch seconds.
 *
 * Returns `undefined` when neither an offer nor an option sheet was requested.
 */
export declare const buildNativeFlowMessageParamsJson: (offerText: string | undefined, offerCode: string | undefined, offerUrl: string | undefined, offerExpiration: number | undefined, optionText: string | undefined, optionTitle: string | undefined, buttonCount: number) => string | undefined;
/**
 * Converts shorthand buttons into native_flow `{ name, buttonParamsJson }`.
 *
 *  - `{ text, id }`       → quick_reply
 *  - `{ text, copy }`     → cta_copy
 *  - `{ text, url }`      → cta_url (`useWebview` supported)
 *  - `{ text, call }`     → cta_call
 *  - `{ text, sections }` → single_select
 *  - `{ name, buttonParamsJson }` (or `{ name, ...params }`) → passed through
 *
 * `buttonText` is accepted as an alias of `text`.
 */
export declare const convertNativeFlowButtons: (rawButtons: AnyRecord[]) => proto.Message.InteractiveMessage.NativeFlowMessage.INativeFlowButton[];
/**
 * Builds a full `nativeFlowMessage` (`{ buttons, messageParamsJson }`) from a
 * message/card carrying `nativeFlow` (or `interactiveButtons`/`buttons`) plus
 * the optional offer/option fields.
 *
 * `messageParamsJson` always defaults to `'{}'`; WhatsApp clients (iOS in
 * particular) drop the buttons when it is missing.
 */
export declare const prepareNativeFlowMessage: (source: AnyRecord, rawButtons?: AnyRecord[] | {
    buttons?: AnyRecord[];
}) => proto.Message.InteractiveMessage.INativeFlowMessage;
/** True when `m` holds a media/location/product item usable as an interactive header. */
export declare const hasValidInteractiveHeader: (m: AnyRecord) => boolean;
/** Picks only the header-capable fields out of an already-prepared content object. */
export declare const pickInteractiveHeaderMedia: (m: AnyRecord) => proto.Message.InteractiveMessage.IHeader;
export interface NativeFlowInteractiveDeps {
    /** `prepareWAMessageMedia` — injected to avoid a circular import */
    prepareMedia: (content: any, options: any) => Promise<proto.IMessage>;
    options: any;
}
/**
 * Builds the `{ interactiveMessage }` for `nativeFlow` / `interactiveButtons`.
 *
 * `m` is the already-prepared base content (`imageMessage`, `videoMessage`,
 * `documentMessage`, `locationMessage`, `productMessage`, or a plain text
 * message) — its media becomes the interactive header.
 */
export declare const buildNativeFlowInteractiveMessage: (message: AnyRecord, m: AnyRecord, rawButtons: AnyRecord[] | {
    buttons?: AnyRecord[];
}, deps: NativeFlowInteractiveDeps) => Promise<{
    interactiveMessage: proto.Message.IInteractiveMessage;
}>;
/** True when the payload carries a raw WhatsApp interactive-family message. */
export declare const hasRawInteractiveContent: (message: AnyRecord) => boolean;
/**
 * Pass-through for raw `interactiveMessage` / `buttonsMessage` /
 * `listMessage` / `templateMessage` payloads (innovatorssoft style). The raw
 * object is normalised with the matching proto `fromObject` and picks up
 * mention/context info.
 */
export declare const prepareRawInteractiveContent: (message: AnyRecord) => proto.IMessage;
export {};
//# sourceMappingURL=native-flow-interactive.d.ts.map