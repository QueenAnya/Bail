/**
 * VoIP compatibility layer for @innovatorssoft/baileys naming.
 *
 * Everything here sits on top of this fork's own socket-integrated VoIP engine
 * (`sock.initiateCall()`, exposed by the merged `Voip` facade) — nothing here starts a second engine.
 *
 *  - `CallDirection`, `CallMediaType`  — string-literal constants
 *  - `CallSession`                      — alias of `ActiveCall` (innovatorssoft exports it under both names)
 *  - `CallManager`                      — concurrency limit + `onLimit: 'queue'` waiting queue
 *  - `VoipResourceManager`, `resolvePthreadPoolSize` — counters, WASM module cache, memory stats
 *  - `ensureWasmAssets`                 — copy/verify the bundled WASM assets
 */
export { CallManager } from '../Voip/call-manager.js';
export type { CallManagerConfig, CallManagerSocket, WaitingCallSummary } from '../Voip/call-manager.js';
export { resolvePthreadPoolSize, VoipResourceManager } from '../Voip/resource-manager.js';
export type { VoipMemoryStatsInput } from '../Voip/resource-manager.js';
export { CallDirection, CallMediaType } from '../Voip/types.js';
export { ensureWasmAssets } from '../Voip/wasm-assets.js';
export { ActiveCall as CallSession } from '../Voip/voip-engine.js';
//# sourceMappingURL=voip-compat.d.ts.map