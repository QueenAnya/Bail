export declare const getMathJax: () => any;
export declare const scaleMap: Record<string, number>;
export declare const unsupportedCommands: string[];
export declare const convertLatexToSvg: (latexInput: string, scale?: number | string) => any;
export interface LatexRenderOptions {
    scale?: number | string;
    outputScale?: number | string;
    density?: number;
    background?: any;
    transparent?: boolean;
}
export declare const renderLatexToPng: (latexExpr: string, options?: number | string | LatexRenderOptions) => Promise<{
    buffer: Buffer;
    width: number;
    height: number;
}>;
export declare const renderLatexToPngg: (latexExpr: string) => Promise<{
    buffer: Buffer;
    width: number;
    height: number;
}>;
export declare const convertLatexToPng: (latexExpr: string, options?: number | string | LatexRenderOptions) => Promise<{
    buffer: Buffer;
    width: number;
    height: number;
}>;
//# sourceMappingURL=mathjax.d.ts.map