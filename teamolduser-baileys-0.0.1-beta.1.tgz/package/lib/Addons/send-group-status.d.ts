import type { WAMessage } from '../Types/Message.js';
/**
 * Generate and relay a Group Status (groupStatusMessageV2) using the
 * official WhiskeySockets message-generation/relay primitives.
 *
 * This is the extracted helper form of the `groupStatus: true` shorthand:
 *
 *   await sock.sendMessage(groupJid, { text: 'Hello', groupStatus: true })
 *
 * The normal `sendMessage(..., { groupStatus: true })` API remains supported.
 * This helper is useful when callers want an explicit socket method.
 */
export declare function sendGroupStatus(sock: any, groupJid: string, content: Record<string, any>, options?: Record<string, any>): Promise<WAMessage>;
//# sourceMappingURL=send-group-status.d.ts.map