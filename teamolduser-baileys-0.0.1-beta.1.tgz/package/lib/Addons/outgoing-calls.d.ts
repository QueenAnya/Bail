/**
 * addon: outgoing-calls
 * Source patch: Baileys-feature-outgoing-calls
 *
 * Adds:
 *   - WAInitiateCallOptions / WAInitiateCallResult types
 *   - createCallLink() — creates an audio or video call invite link via WA servers
 *   - initiateCall()   — initiates a direct 1-on-1 or group call (binary node send)
 *   - rejectCall()     — rejects an incoming call by call-id
 *
 * createCallLink is wired directly into chats.ts; initiateCall and rejectCall
 * are implemented here as standalone helpers that require a `sendNode` / `query` ref.
 */
import type { BinaryNode } from '../WABinary/index.js';
export type WAInitiateCallOptions = {
    /** Whether to start a video call (default: false = audio) */
    isVideo?: boolean;
};
export type WAInitiateCallResult = {
    callId: string;
    to: string;
    isVideo: boolean;
};
export type WACallUpdateType = 'offer' | 'ringing' | 'timeout' | 'reject' | 'accept' | 'terminate';
/**
 * Creates an audio or video call invite link via WA servers.
 * Returns the invite token string, or undefined on failure.
 *
 * Must be called with the socket's `query` and `generateMessageTag` functions.
 *
 * @example
 * const token = await createCallLink(query, generateMessageTag, 'video')
 * // Share: https://call.whatsapp.com/voice/token/<token>
 */
export declare const createCallLink: (query: (node: BinaryNode, timeoutMs?: number) => Promise<BinaryNode>, type: "audio" | "video", event?: {
    startTime: number;
}, timeoutMs?: number) => Promise<string | undefined>;
/**
 * Initiate a direct 1-on-1 or group call.
 * Sends a `call` binary node with an `offer` child to the recipient JID.
 * Returns the generated callId.
 *
 * @param sendNode  — socket's raw sendNode function
 * @param meJid     — our own JID
 * @param toJid     — recipient / group JID
 * @param opts      — { isVideo?: boolean }
 */
export declare const initiateCall: (sendNode: (node: BinaryNode) => Promise<void>, meJid: string, toJid: string, opts?: WAInitiateCallOptions) => Promise<WAInitiateCallResult>;
/**
 * Reject an incoming call.
 * Sends a `call` binary node with a `reject` child.
 *
 * @param sendNode    — socket's raw sendNode function
 * @param meJid       — our own JID
 * @param fromJid     — caller's JID
 * @param callId      — the call-id from the incoming offer
 * @param callCreator — who created the call (usually same as fromJid)
 */
export declare const rejectCall: (sendNode: (node: BinaryNode) => Promise<void>, meJid: string, fromJid: string, callId: string, callCreator?: string) => Promise<void>;
/**
 * Terminate / end an ongoing call.
 */
export declare const endCall: (sendNode: (node: BinaryNode) => Promise<void>, meJid: string, toJid: string, callId: string, callCreator?: string) => Promise<void>;
//# sourceMappingURL=outgoing-calls.d.ts.map