/**
 * addon: stickerpack
 * Source patch: Baileys-feat-add-stickerpack-support (shell/metadata functions)
 * + itsliaaa `prepareStickerPackMessage` (lib/Utils/messages.js), based on
 *   https://github.com/WhiskeySockets/Baileys/pull/1561 (field validity work by @jlucaso1).
 *
 * Adds support for sending WhatsApp Sticker Pack messages.
 * Sticker and StickerPack types are the canonical definitions in Types/Message.ts.
 *
 * This addon exports:
 *   - prepareStickerPackMessage() — full pipeline (convert, ZIP, encrypt, upload, thumbnail) returning a
 *     ready-to-send stickerPackMessage; the alternate builder next to `buildStickerPackMessage()` in from-messages.ts
 *   - buildStickerPackProto() — builds the proto payload for a StickerPackMessage
 *   - generateStickerPackId() — generates a random pack ID
 *   - STICKER_PACK_MESSAGE_TYPE — the message type string 'sticker_pack'
 *   - convertToWebP()  converts a Buffer, URL string, or Stream into a WebP
 *     sticker buffer at its original size (WebP passthrough; PNG/JPG/GIF/video converted).
 *
 * Media rules (same as `buildStickerPackMessage`): WebP is sent untouched; PNG/JPG/GIF/video are converted to WebP at the
 * ORIGINAL size and ORIGINAL quality (lossless WebP) by default. Optional `maxSize` (longest side in px, never upscaled),
 * `quality` (`'original'` = default / lossless, or 1-100 = lossy) and `concurrency` are available on the pack; the cover / tray icon
 * always stays original. Lottie (`.was` / raw Lottie JSON) stickers are kept as Lottie.
 * No sticker-count limit and no per-sticker / pack size limit.
 */
import { proto } from '../../WAProto/index.js';
import type { WAMediaUpload } from '../Types/index.js';
import type { ILogger } from '../Utils/logger.js';
export type { Sticker, StickerPack } from '../Types/index.js';
/**
 * Convert a Buffer, URL string, or Stream into a WebP sticker buffer.
 *
 * Same rules as the sticker packs (see `toStickerWebp` in from-messages.ts):
 *   - already WebP            -> returned untouched (original size, quality, EXIF, animation)
 *   - PNG / JPG / GIF / ...   -> WebP at the ORIGINAL size (no 512 resize) and ORIGINAL quality (lossless),
 *                                never lowered automatically
 *   - video (mp4/webm/mkv)    -> animated WebP via ffmpeg, original size
 * Needs `sharp` or `@napi-rs/image` for images (ffmpeg for video); a clear error is thrown otherwise.
 *
 * @example
 * const { buffer, isAnimated } = await convertToWebP('https://example.com/pic.png')
 * const { buffer: b2 } = await convertToWebP(fs.readFileSync('./sticker.jpg'))
 */
export declare const convertToWebP: (input: WAMediaUpload) => Promise<{
    buffer: Buffer;
    isAnimated: boolean;
}>;
/**
 * Generate a random sticker pack ID (16 hex chars).
 */
export declare const generateStickerPackId: () => string;
/**
 * Build the proto-level stickerPackMessage payload.
 * The result can be passed directly as the stickerPackMessage field in a proto.IMessage.
 */
export declare const buildStickerPackProto: (pack: {
    name: string;
    publisher: string;
    packId?: string;
    description?: string;
}) => {
    name: string;
    publisher: string;
    packId: string;
    description: string;
};
/**
 * stickerPack message type marker — getMediaType() returns this for stickerPackMessage.
 */
export declare const STICKER_PACK_MESSAGE_TYPE: "sticker_pack";
export type StickerInput = {
    /** sticker media (Buffer / `{ url }` / stream / path) */
    data?: WAMediaUpload;
    /** alias of `data` (the field name used by @innovatorssoft/baileys) */
    sticker?: WAMediaUpload;
    /** emoji tags for this sticker (default ['✨']) */
    emojis?: string[];
    /** accessibility label */
    accessibilityLabel?: string;
    /** override animated-WebP auto detection */
    isAnimated?: boolean;
    /** override Lottie (.was / raw Lottie JSON) auto detection */
    isLottie?: boolean;
};
export type StickerPackInput = {
    cover: WAMediaUpload;
    stickers: StickerInput[];
    /** fixed pack id; a random one is generated when omitted */
    packId?: string;
    /** stickers converted at the same time (default 15) - lower it on low-RAM hosts */
    concurrency?: number;
    /**
     * longest side (px) for stickers that have to be CONVERTED to WebP (PNG/JPG/GIF/video); never upscaled, WebP stickers
     * are never touched. Default: the original size (no cap) - `false` / omitted keeps it, e.g. `512` = WhatsApp's own size
     */
    maxSize?: number | false;
    /** `'original'` (default) = lossless WebP / original quality for converted stickers; a number 1-100 = lossy WebP of that quality */
    quality?: number | 'original';
    name?: string;
    publisher?: string;
    description?: string;
};
export type StickerPackOptions = {
    logger?: ILogger;
    upload: (filePath: string, opts: {
        fileEncSha256B64: string;
        mediaType: string;
        timeoutMs?: number;
    }) => Promise<{
        directPath: string;
    }>;
    options?: RequestInit;
    mediaUploadTimeoutMs?: number;
    mediaCache?: {
        get: (key: string) => Promise<Buffer | undefined>;
        set: (key: string, value: Buffer) => void;
    };
};
/**
 * Build a complete, ready-to-send stickerPackMessage (ZIP built, encrypted,
 * and uploaded). Sticker-pack field validity work credited to @jlucaso1,
 * based on PR #1561.
 */
export declare const prepareStickerPackMessage: (message: StickerPackInput, options: StickerPackOptions) => Promise<proto.Message.IStickerPackMessage>;
//# sourceMappingURL=stickerpack.d.ts.map