/**
 * SQLite-backed Authentication State
 *
 * Clean TypeScript with full types and JSDoc.
 *
 * Uses `better-sqlite3` for synchronous, transactional key storage.
 * `better-sqlite3` is a hard dependency of this package (pulled in for the
 * Framework's SQLiteStore/StatsManager) — no separate install needed.
 *
 * Two tables:
 *   - `creds`        — stores the authentication credentials (single row `__creds__`)
 *   - `signal_keys`  — stores Signal Protocol session/pre-keys (type + id composite PK)
 *
 * @example
 * import { makeWASocket, useSqliteAuthState } from '@teamolduser/baileys'
 *
 * const { state, saveCreds } = await useSqliteAuthState({ dbPath: './auth.db' })
 * const sock = makeWASocket({ auth: state })
 * sock.ev.on('creds.update', saveCreds)
 */
import type BetterSqlite3 from 'better-sqlite3';
import type { AuthenticationStateWithListing } from '../Types/index.js';
export type SqliteAuthStateOptions = {
    /** Path to the SQLite database file (will be created if it does not exist). */
    dbPath: string;
    database?: undefined;
} | {
    dbPath?: undefined;
    /** Pass an existing better-sqlite3 Database instance. */
    database: BetterSqlite3.Database;
};
export type SqliteAuthStateResult = {
    state: AuthenticationStateWithListing;
    saveCreds: () => Promise<void>;
};
/**
 * Create a SQLite-backed auth state.
 * WAL journal mode is enabled for reliable concurrent-read performance.
 */
export declare function useSqliteAuthState(
/**
 * Options object, or positional arguments. Accepted shapes:
 * `(dbPath)`, `(dbPath, session)`, `({ dbPath })`, `({ database })`.
 */
a: string | SqliteAuthStateOptions, b?: string | SqliteAuthStateOptions, c?: string): Promise<SqliteAuthStateResult>;
//# sourceMappingURL=use-sqlite-auth-state.d.ts.map