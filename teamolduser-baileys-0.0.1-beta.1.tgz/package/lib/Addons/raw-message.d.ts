import { proto } from '../../WAProto/index.js';
export declare const RAW_MODE_HELPER_KEYS: Set<string>;
/** Builds a `proto.Message` from a `{ ...protoKeys, raw: true }` payload, validating the keys. */
export declare const buildRawMessageContent: (message: Record<string, unknown>) => proto.IMessage;
//# sourceMappingURL=raw-message.d.ts.map