import type { Readable } from 'stream';
import type { URL } from 'url';
import { proto } from '../../WAProto/index.js';
import type { RichContent } from '../Addons/rich-message-utils.js';
import type { MediaType } from '../Defaults/index.js';
import type { BinaryNode } from '../WABinary/index.js';
import type { GroupMetadata } from './GroupMetadata.js';
import type { CacheStore } from './Socket.js';
export { proto as WAProto };
export type WAMessage = proto.IWebMessageInfo & {
    key: WAMessageKey;
    messageStubParameters?: any;
    category?: string;
    retryCount?: number;
};
export type WAMessageContent = proto.IMessage;
export type WAContactMessage = proto.Message.IContactMessage;
export type WAContactsArrayMessage = proto.Message.IContactsArrayMessage;
export type WAMessageKey = proto.IMessageKey & {
    remoteJidAlt?: string;
    remoteJidUsername?: string;
    participantAlt?: string;
    participantUsername?: string;
    server_id?: string;
    /** newsletter message sent by this account (stanza is_sender='true') */
    isNewsletterSender?: boolean;
    addressingMode?: string;
    isViewOnce?: boolean;
};
export type WATextMessage = proto.Message.IExtendedTextMessage;
export type WAContextInfo = proto.IContextInfo;
export type WALocationMessage = proto.Message.ILocationMessage;
export type WAGenericMediaMessage = proto.Message.IVideoMessage | proto.Message.IImageMessage | proto.Message.IAudioMessage | proto.Message.IDocumentMessage | proto.Message.IStickerMessage;
export declare const WAMessageStubType: typeof proto.WebMessageInfo.StubType;
export declare const WAMessageStatus: typeof proto.WebMessageInfo.Status;
/** Convenience aliases for commonly-used proto enums — same values as
 *  e.g. `WAProto.Message.ButtonsMessage.HeaderType`, just shorter to type. */
export declare const ButtonHeaderType: typeof proto.Message.ButtonsMessage.HeaderType;
export declare const ButtonType: typeof proto.Message.ButtonsMessage.Button.Type;
export declare const CarouselCardType: typeof proto.Message.InteractiveMessage.CarouselMessage.CarouselCardType;
export declare const ProtocolType: typeof proto.Message.ProtocolMessage.Type;
export declare const ListType: typeof proto.Message.ListMessage.ListType;
/** font ids accepted for text statuses / styled text */
export declare const StatusFont: typeof proto.Message.ExtendedTextMessage.FontType;
export declare const StatusNotificationType: Readonly<{
    STATUS_GROUP_STATUS_REPLY: 4;
    UNKNOWN: proto.Message.StatusNotificationMessage.StatusNotificationType.UNKNOWN;
    STATUS_ADD_YOURS: proto.Message.StatusNotificationMessage.StatusNotificationType.STATUS_ADD_YOURS;
    STATUS_RESHARE: proto.Message.StatusNotificationMessage.StatusNotificationType.STATUS_RESHARE;
    STATUS_QUESTION_ANSWER_RESHARE: proto.Message.StatusNotificationMessage.StatusNotificationType.STATUS_QUESTION_ANSWER_RESHARE;
}>;
import type { ILogger } from '../Utils/logger.js';
export type WAMediaPayloadURL = {
    url: URL | string;
};
export type WAMediaPayloadStream = {
    stream: Readable;
};
export type WAMediaUpload = Buffer | WAMediaPayloadStream | WAMediaPayloadURL;
/** Set of message types that are supported by the library */
export type MessageType = keyof proto.Message;
export declare enum WAMessageAddressingMode {
    PN = "pn",
    LID = "lid"
}
export type MessageWithContextInfo = 'imageMessage' | 'contactMessage' | 'locationMessage' | 'extendedTextMessage' | 'documentMessage' | 'audioMessage' | 'videoMessage' | 'call' | 'contactsArrayMessage' | 'liveLocationMessage' | 'templateMessage' | 'stickerMessage' | 'groupInviteMessage' | 'templateButtonReplyMessage' | 'productMessage' | 'listMessage' | 'orderMessage' | 'listResponseMessage' | 'buttonsMessage' | 'buttonsResponseMessage' | 'interactiveMessage' | 'interactiveResponseMessage' | 'pollCreationMessage' | 'requestPhoneNumberMessage' | 'messageHistoryBundle' | 'eventMessage' | 'newsletterAdminInviteMessage' | 'albumMessage' | 'stickerPackMessage' | 'pollResultSnapshotMessage' | 'messageHistoryNotice';
export type DownloadableMessage = {
    mediaKey?: Uint8Array | null;
    directPath?: string | null;
    url?: string | null;
};
export type MessageReceiptType = 'read' | 'read-self' | 'hist_sync' | 'peer_msg' | 'sender' | 'inactive' | 'played' | undefined;
export type MediaConnInfo = {
    auth: string;
    ttl: number;
    hosts: {
        hostname: string;
        maxContentLengthBytes: number;
    }[];
    fetchDate: Date;
};
export interface WAUrlInfo {
    'canonical-url': string;
    'matched-text': string;
    title: string;
    description?: string;
    jpegThumbnail?: Buffer;
    highQualityThumbnail?: proto.Message.IImageMessage;
    originalThumbnailUrl?: string;
    linkPreviewMetadata?: proto.Message.ILinkPreviewMetadata;
    /** e.g. request video playback for the preview instead of a static image; defaults to 0 (NONE) */
    previewType?: proto.Message.ExtendedTextMessage.PreviewType;
}
type Mentionable = {
    /** groups mentioned in the accompanying text (`@<group id>` is appended to the text when missing) */
    groupMentions?: {
        groupJid: string;
        groupSubject?: string;
    }[];
    /** forward a channel (newsletter) post: shows the "Forwarded from channel" header */
    forwardedNewsletter?: {
        newsletterJid: string;
        serverMessageId?: number;
        newsletterName?: string;
        contentType?: proto.ContextInfo.ForwardedNewsletterMessageInfo.ContentType;
        accessibilityText?: string;
    };
    /** list of jids that are mentioned in the accompanying text */
    mentions?: string[];
    /** mention all */
    mentionAll?: boolean;
};
type Contextable = {
    /** add contextInfo to the message */
    contextInfo?: proto.IContextInfo;
};
type ViewOnce = {
    viewOnce?: boolean;
};
type Editable = {
    edit?: WAMessageKey;
};
/** Send image/video at HD quality */
type HDable = {
    hd?: boolean;
};
/** Attach classic buttons (up to 3) to a text or media message */
type Buttonable = {
    buttons?: proto.Message.ButtonsMessage.IButton[];
};
/** Attach template buttons (quickReply / url / call) to a message */
type Templatable = {
    /**
     * Either fully-formed `IHydratedTemplateButton`s, or shorthand objects:
     * `{ text, id }` → quickReplyButton, `{ text, url }` → urlButton,
     * `{ text, call }` → callButton.
     */
    templateButtons?: (proto.IHydratedTemplateButton | {
        text?: string;
        buttonText?: string;
        id?: string;
        url?: string;
        call?: string;
    })[];
    footer?: string;
};
/** Attach native-flow interactive buttons to a message */
type NativeFlowShorthandButton = {
    text?: string;
    buttonText?: string;
    icon?: string;
    id?: string;
    copy?: string;
    url?: string;
    useWebview?: boolean;
    call?: string;
    sections?: unknown[];
};
type Interactiveable = {
    interactiveButtons?: (proto.Message.InteractiveMessage.NativeFlowMessage.INativeFlowButton | NativeFlowShorthandButton)[];
    /** shorthand native-flow buttons: { text, id | url | copy | call | sections } or raw { name, buttonParamsJson } */
    nativeFlow?: (proto.Message.InteractiveMessage.NativeFlowMessage.INativeFlowButton | NativeFlowShorthandButton)[];
    /** wrap the built interactiveMessage into a templateMessage */
    interactiveAsTemplate?: boolean;
    /** custom templateId for interactiveAsTemplate / hydrated templates */
    id?: string;
    body?: string | proto.Message.InteractiveMessage.IBody;
    title?: string;
    subtitle?: string;
    footer?: string;
    hasMediaAttachment?: boolean;
    /** limited-time-offer banner shown above the buttons */
    offerText?: string;
    offerCode?: string;
    offerUrl?: string;
    /** offer expiry, in ms (converted to epoch seconds on send) */
    offerExpiration?: number;
    /** adds a "view more" bottom sheet listing the buttons */
    optionText?: string;
    optionTitle?: string;
    /** audio footer instead of a text footer */
    audioFooter?: WAMediaUpload;
};
/** Attach a single-select list to a text message */
type Listable = {
    sections?: proto.Message.ListMessage.ISection[];
    /** Title shown above the list */
    title?: string;
    /** Label on the button that opens the list (required) */
    buttonText?: string;
    footer?: string;
};
/** Attach a WhatsApp Shop storefront to a message */
type Shopable = {
    shop?: proto.Message.InteractiveMessage.IShopMessage;
    title?: string;
    subtitle?: string;
    footer?: string;
    hasMediaAttachment?: boolean;
};
/** Attach a WhatsApp Collection to a message */
type Collectionable = {
    collection?: proto.Message.InteractiveMessage.ICollectionMessage;
    title?: string;
    subtitle?: string;
    footer?: string;
    hasMediaAttachment?: boolean;
};
/** Attach a carousel of cards to a message */
type Cardsable = {
    cards?: Carousel[];
    title?: string;
    subtitle?: string;
    footer?: string;
};
type WithDimensions = {
    width?: number;
    height?: number;
};
export type AlbumMessageOptions = {
    /** Number of images expected in the album */
    expectedImageCount?: number;
    /** Number of videos expected in the album */
    expectedVideoCount?: number;
};
export type KeepMessageOptions = {
    /** The message key to keep */
    key: proto.IMessageKey;
    /** Keep duration in seconds (86400 = 24h, 604800 = 7d, 0 = unkeep) */
    keepDurationSeconds?: number;
};
export type ButtonContent = {
    /** Button display text */
    displayText: string;
    /** Button ID */
    id: string;
    /** Button type */
    type?: 'reply' | 'url' | 'call' | 'copy';
    /** URL for url-type buttons */
    url?: string;
    /** Phone number for call-type buttons */
    phoneNumber?: string;
    /** Text to copy for copy-type buttons */
    copyCode?: string;
};
export type ButtonsMessageOptions = {
    /** Message body text */
    text: string;
    /** Footer text */
    footer?: string;
    /** Header text */
    headerText?: string;
    /** Buttons to display */
    buttons: ButtonContent[];
    /** Header type: text | image | video | document */
    headerType?: 'text' | 'image' | 'video' | 'document';
    /** Media for header */
    headerMedia?: WAMediaUpload;
};
export type ListMessageSection = {
    title: string;
    rows: {
        title: string;
        rowId: string;
        description?: string;
    }[];
};
export type ListMessageOptions = {
    text: string;
    footer?: string;
    title?: string;
    buttonText: string;
    sections: ListMessageSection[];
};
export type TemplateButtonContent = {
    index: number;
    urlButton: {
        displayText: string;
        url: string;
    };
} | {
    index: number;
    callButton: {
        displayText: string;
        phoneNumber: string;
    };
} | {
    index: number;
    quickReplyButton: {
        displayText: string;
        id: string;
    };
};
export type TemplateMessageOptions = {
    text: string;
    footer?: string;
    templateButtons: TemplateButtonContent[];
    /** Optional header: text, image, video, document */
    header?: string;
    headerMedia?: WAMediaUpload;
};
type InteractiveButton = {
    type: 'reply';
    displayText: string;
    id: string;
} | {
    type: 'url';
    displayText: string;
    url: string;
    merchantUrl?: string;
} | {
    type: 'cta_call';
    displayText: string;
    phoneNumber: string;
} | {
    type: 'cta_copy';
    displayText: string;
    copyCode: string;
};
export type CarouselCard = {
    body: string;
    footer?: string;
    headerImage?: WAMediaUpload;
    headerVideo?: WAMediaUpload;
    buttons: InteractiveButton[];
};
export type InteractiveMessageOptions = {
    body: string;
    footer?: string;
    /** Header options */
    header?: {
        title?: string;
        subtitle?: string;
        hasMediaAttachment?: boolean;
    };
    /** Buttons (for native-flow / button-list style) */
    buttons?: InteractiveButton[];
    /** Carousel cards */
    cards?: CarouselCard[];
    /** Products list */
    shop?: {
        id: string;
        thumbnail?: WAMediaUpload;
        title?: string;
    };
};
export type InteractiveMessagePIXOptions = InteractiveMessageOptions & {
    /** PIX payment key */
    pixKey: string;
    /** Payment amount in cents */
    amount: number;
    /** Merchant name */
    merchantName: string;
};
export type InteractiveMessagePAYOptions = InteractiveMessageOptions & {
    /** Payment amount */
    amount: number;
    /** Currency code, e.g. "INR"; defaults to "INR" */
    currency?: string;
    /** Reference ID */
    referenceId?: string;
    /** Payment note */
    note?: string;
};
export type PaymentMessageOptions = {
    /** Amount in smallest currency unit (e.g. cents); a numeric string is accepted too */
    amount: number | string;
    /** Currency code (e.g. "INR", "BRL"); defaults to "INR" */
    currency?: string;
    /** innovatorssoft alias of `receiverJid` */
    from?: string;
    /** Amount offset (default 100) */
    offset?: number;
    /** Payment bubble colours (ARGB numbers) → `background` */
    image?: {
        placeholderArgb?: number;
        textArgb?: number;
        subtextArgb?: number;
    };
    /** Note/memo for the payment */
    note?: string;
    /** Who this payment is being requested from — optional; defaults to the
     *  chat this message is sent to (the `jid` passed to `sendMessage`) */
    receiverJid?: string;
    /** Request or send */
    type?: 'request' | 'send';
    /** Background color (hex) */
    backgroundColor?: string;
    /** Expiry timestamp (ms since epoch) */
    expiry?: number;
};
export type PaymentInviteInfoo = {
    type?: number;
    expiry?: number;
};
export type PaymentInviteMessageOptions = {
    /** Type of payment service */
    serviceType: 'UNKNOWN' | 'FACEBOOK_PAY' | 'NOVI' | 'UPI' | 'PAYTM' | 'BR_GPY' | 'BR_PIX';
    /** Expiry timestamp (ms since epoch) */
    expiryTimestamp?: number;
};
export type OrderMessageOptions = {
    /** Order ID */
    orderId: string;
    /** Thumbnail image of an order item */
    thumbnail?: WAMediaUpload;
    /** Item count */
    itemCount: number;
    /** Order status */
    status?: 'INQUIRY' | 'ACCEPTED' | 'DECLINED' | 'EXPIRED' | 'CANCELED';
    /** Surface (e.g. 1 = catalog, 2 = message) */
    surface?: number;
    /** Message associated with the order */
    message?: string;
    /** Order title */
    title?: string;
    /** Seller JID */
    sellerJid?: string;
    /** Token */
    token?: string;
};
/**
 * Individual sticker within a sticker pack (V1 style)
 */
export type Sticker = {
    /** Sticker media source */
    data: WAMediaUpload;
    /** Emoji tags for this sticker */
    emojis?: string[];
    /** Accessibility label */
    accessibilityLabel?: string;
};
/**
 * Full sticker pack definition (Merged V1/V2)
 */
export type StickerPackFull = {
    /** All stickers in the pack (V1 uses Sticker[], V2 uses StickerPackSticker[]) */
    stickers: StickerPackSticker[] | Sticker[];
    /** Cover sticker shown in the tray */
    cover: WAMediaUpload;
    /** Display name of the pack */
    name: string;
    /** Publisher name */
    publisher: string;
    /** Optional description */
    description?: string;
    /** Pack ID — auto-generated if not provided */
    packId?: string;
};
export type StickerPackMessageOptions = {
    /** Pack name */
    packName: string;
    /** Pack publisher */
    publisher?: string;
    /** Pack ID */
    packId?: string;
    /** Sticker count */
    stickerCount?: number;
};
export type StatusMentionOptions = {
    /** Status JIDs to mention */
    statusJidList: string[];
    /** Text to accompany */
    text: string;
    /** Background color */
    backgroundColor?: string;
    /** text colour of a text status, `#rrggbb`, `#aarrggbb` or an ARGB number */
    textColor?: string | number;
    /** Font */
    font?: number;
};
export type ShopMessageOptions = {
    /** Surface: 1=unknown, 2=catalog */
    surface?: number;
    /** Message */
    message?: string;
};
export type CollectionMessageOptions = {
    /** Business JID owning the collection */
    bizJid: string;
    /** Collection ID */
    id: string;
    /** Message version */
    messageVersion?: number;
};
export type RichTextTable = {
    /** Table data rows (first row = header if headerRow=true) */
    rows: string[][];
    /** Whether first row is a header */
    headerRow?: boolean;
    /** Optional title */
    title?: string;
};
export type RichTextList = {
    /** List items */
    items: string[];
    /** Ordered (numbered) list */
    ordered?: boolean;
    /** Optional title */
    title?: string;
};
export type CodeBlockOptions = {
    /** Code string */
    code: string;
    /** Language hint */
    language?: string;
};
export type LatexOptions = {
    /** LaTeX expression */
    expression: string;
};
export type RichMessageOptions = {
    /** Rich text content parts */
    parts: ({
        type: 'text';
        text: string;
    } | {
        type: 'table';
        table: RichTextTable;
    } | {
        type: 'list';
        list: RichTextList;
    } | {
        type: 'code';
        code: CodeBlockOptions;
    } | {
        type: 'latex';
        latex: LatexOptions;
    })[];
    /** Optional caption */
    caption?: string;
};
/** A poll option with an optional picture ("photo poll"). */
export type PollPhotoOption = {
    name: string;
    /** picture shown with the option; uploaded when the poll is sent */
    image?: WAMediaUpload;
    /** hash of an option picture that was already uploaded (see getPollOptionHash) */
    optionHash?: string;
};
export type PollMessageOptions = {
    name: string;
    selectableCount?: number;
    /** option names; use `{ name, image }` entries to make a photo poll */
    values: (string | PollPhotoOption)[];
    /** 32 byte message secret to encrypt poll selections */
    messageSecret?: Uint8Array;
    toAnnouncementGroup?: boolean;
    /**
     * Poll content type — used for newsletter polls meta node.
     * 1 = TEXT (default), 2 = IMAGE
     */
    pollContentType?: 1 | 2;
    /**
     * Hide voter names — when true, poll uses V6 format and shows 'Names hidden' badge.
     * PR #2725 — reverse-engineered from live WhatsApp.
     */
    hideParticipantName?: boolean;
    /** @deprecated elaina/upstream name is `hideParticipantName`; kept so existing callers keep compiling */
    hideVoterNames?: boolean;
    /** alias of `hideParticipantName` */
    hideVoter?: boolean;
    /** poll expiration timestamp; after this the poll can no longer be voted on */
    endDate?: Date;
    /** allow participants to add their own options to the poll */
    canAddOption?: boolean;
    /**
     * makes this a quiz poll instead of a regular poll — requires
     * `correctAnswer`, and is only supported when sending to a newsletter.
     */
    pollType?: 1;
    /** the option text that is the correct answer, required when pollType is 1 (quiz) */
    correctAnswer?: string;
};
/**
 * Send a poll-results summary message — e.g. a bot posting the final tally
 * of an earlier poll. This is a standalone display message, not an actual
 * connection to the original poll's live vote state.
 */
export type PollResultOptions = {
    name: string;
    /** `votes` or the innovatorssoft form `values: [[name, count], ...]` */
    votes?: {
        name: string;
        voteCount: number | string;
    }[];
    values?: [string, number | string][];
    /** makes this a quiz-result snapshot instead of a regular poll result */
    pollType?: 1;
};
/**
 * Send a raw, already-encrypted poll vote update. Advanced/low-level API —
 * the caller is responsible for producing a valid encrypted `vote` payload
 * themselves (see `Utils/crypto.ts` `encryptPollVote` for the encryption
 * this mirrors on the receiving side).
 */
export type PollUpdateOptions = {
    /** the key of the original poll creation message being voted on */
    key: WAMessageKey;
    /** the encrypted vote payload */
    vote: proto.Message.IPollEncValue;
    metadata?: proto.Message.IPollUpdateMessageMetadata;
};
export type EventMessageOptions = {
    name: string;
    description?: string;
    /** `startDate` (Date) or the innovatorssoft form `startTime` (unix seconds / ms); defaults to tomorrow */
    startDate?: Date;
    endDate?: Date;
    startTime?: number;
    endTime?: number;
    /** innovatorssoft spelling of `isCancelled` */
    isCanceled?: boolean;
    location?: WALocationMessage;
    call?: 'audio' | 'video';
    isCancelled?: boolean;
    isScheduleCall?: boolean;
    extraGuestsAllowed?: boolean;
    messageSecret?: Uint8Array<ArrayBufferLike>;
};
type SharePhoneNumber = {
    sharePhoneNumber: boolean;
};
type RequestPhoneNumber = {
    requestPhoneNumber: boolean;
};
export type AnyMediaMessageContent = (({
    image: WAMediaUpload;
    caption?: string;
    jpegThumbnail?: string;
} & Mentionable & Contextable & Buttonable & Templatable & Interactiveable & Shopable & Collectionable & HDable & WithDimensions) | ({
    video: WAMediaUpload;
    caption?: string;
    gifPlayback?: boolean;
    jpegThumbnail?: string;
    /** if set to true, will send as a `video note` */
    ptv?: boolean;
} & Mentionable & Contextable & Buttonable & Templatable & Interactiveable & Shopable & Collectionable & HDable & WithDimensions) | {
    audio: WAMediaUpload;
    /** if set to true, will send as a `voice note` */
    ptt?: boolean;
    /** optionally tell the duration of the audio */
    seconds?: number;
} | ({
    sticker: WAMediaUpload;
    isAnimated?: boolean;
    /** wrap the sticker into a lottieStickerMessage */
    isLottie?: boolean;
} & WithDimensions) | ({
    document: WAMediaUpload;
    mimetype: string;
    fileName?: string;
    caption?: string;
} & Contextable & Buttonable & Templatable & Interactiveable & Shopable & Collectionable)) & {
    mimetype?: string;
} & Editable & {
    /** key of the parent albumMessage to associate this media with */
    albumParentKey?: WAMessageKey;
};
/** Info for replying to a button */
export type ButtonReplyInfo = {
    displayText?: string;
    id?: string;
    index?: number;
    title?: string;
    description?: string;
    rowId?: string;
    nativeFlows?: {
        name: string;
        paramsJson: string;
        version?: number;
    };
};
export type GroupInviteInfo = {
    inviteCode: string;
    inviteExpiration: number;
    text: string;
    jid: string;
    subject: string;
    jpegThumbnail?: Buffer | Uint8Array;
} | {
    /** innovatorssoft form */
    jid: string;
    code: string;
    expiration?: number;
    caption?: string;
    name?: string;
    jpegThumbnail?: Buffer | Uint8Array;
};
/**
 * Payload for the low-level v4 group-invite message, sent directly to a
 * single participant (bypasses the auto profile-picture fetch that
 * `content.groupInvite` does — pass `jpegThumbnail` yourself here).
 * Used by `sock.sendGroupV4Invite` / `sock.sendGroupInviteV4`, and by
 * `sock.sendMessage(jid, { sendGroupV4Invite: ... })` /
 * `sock.sendMessage(jid, { sendGroupInviteV4: ... })`.
 */
export type GroupV4InviteContent = {
    groupJid: string;
    inviteCode: string;
    inviteExpiration?: number;
    groupName?: string;
    caption?: string;
    jpegThumbnail?: Buffer;
};
/** Per-participant outcome of `sock.sendGroupInvite(groupJid, user)`. */
export type GroupInviteAttemptResult = {
    jid: string;
    /** Raw status code from `groupParticipantsUpdate` ('200' on success, '403' when refused, etc.) */
    status: string;
    /** true if a v4 group invite was sent as a fallback instead of a direct add. */
    invited: boolean;
    message: string;
};
export type WASendableProduct = Omit<proto.Message.ProductMessage.IProductSnapshot, 'productImage'> & {
    productImage: WAMediaUpload;
};
/** One card / slide in a carousel message */
export type Carousel = {
    image?: WAMediaUpload;
    video?: WAMediaUpload;
    document?: WAMediaUpload;
    mimetype?: string;
    fileName?: string;
    product?: WASendableProduct;
    title?: string;
    body?: string;
    caption?: string;
    footer?: string;
    buttons?: proto.Message.InteractiveMessage.NativeFlowMessage.INativeFlowButton[];
    nativeFlow?: (proto.Message.InteractiveMessage.NativeFlowMessage.INativeFlowButton | NativeFlowShorthandButton)[];
    offerText?: string;
    offerCode?: string;
    offerUrl?: string;
    offerExpiration?: number;
    optionText?: string;
    optionTitle?: string;
};
/** Product entry for productList messages */
export type ProductListEntry = {
    productId: string;
};
export type ProductListSection = {
    title: string;
    products: ProductListEntry[];
};
export type StickerPackSticker = {
    /** sticker media (WebP kept as is; PNG/JPG/GIF/video are converted to WebP) */
    data?: WAMediaUpload;
    /** @deprecated use `data` instead — kept for backward compatibility */
    sticker?: WAMediaUpload;
    /** emoji tags for this sticker (default ['✨']) */
    emojis?: string[];
    /** accessibility label */
    accessibilityLabel?: string;
    /** override animated-WebP auto detection */
    isAnimated?: boolean;
    /** override Lottie (.was / raw Lottie JSON) auto detection */
    isLottie?: boolean;
};
export type StickerPack = {
    /** any number of stickers (at least 1) — no count or size limit */
    stickers: StickerPackSticker[];
    /** cover shown as the pack tray icon / thumbnail */
    cover: WAMediaUpload;
    /** pack name (default '📦 Sticker Pack') */
    name?: string;
    /** publisher name (default '@teamolduser/baileys') */
    publisher?: string;
    /** pack description */
    description?: string;
    /** pack id — random if omitted */
    packId?: string;
    /** stickers converted at the same time while the pack is built (default 15; lower = less RAM) */
    concurrency?: number;
    /**
     * Longest side (px) for stickers that have to be CONVERTED to WebP (PNG/JPG/GIF/video). Default: the ORIGINAL size
     * (no cap) — `false`, `0` or omitted keeps it. A number (e.g. `512`, WhatsApp's own sticker size) scales bigger images
     * DOWN to that longest side; smaller images are never upscaled and WebP stickers you pass in are never touched.
     * Note: huge images (e.g. phone screenshots) may show as empty boxes in the pack viewer — set `maxSize` for those.
     */
    maxSize?: number | false;
    /**
     * WebP quality of CONVERTED stickers. `'original'` (default) = lossless WebP = original quality; a number 1-100 = lossy
     * WebP of that quality (smaller files). WebP stickers you pass in are never touched; the cover / tray icon always stays original.
     */
    quality?: number | 'original';
};
export type AdminInviteInfo = {
    jid: string;
    name: string;
    caption?: string;
    expiration?: number;
};
export type CallCreationInfo = {
    name?: string;
    time?: number;
    type?: number;
};
export type PaymentInviteInfo = {
    type?: number;
    expiry?: number;
};
export type AnyRegularMessageContent = (({
    text: string;
    /** Pass a `WAUrlInfo` to use it as-is, a bare URL string to
     *  fetch+generate a preview for that URL specifically (instead of
     *  whatever URL is in `text`), `true` or omit for auto-detection
     *  from `text`, or `null` to force no preview at all. */
    linkPreview?: WAUrlInfo | string | true | null;
    /** small icon shown alongside the link preview, e.g. a site favicon */
    favicon?: WAMediaUpload;
    /** social-media post metadata attached to the link preview (see Extras/link-preview-metadata) */
    socialPreview?: Record<string, any>;
    /** status link-preview style (non-negative integer) */
    statusLinkPreview?: number | {
        style: number;
    };
} & Mentionable & Contextable & Buttonable & Templatable & Interactiveable & Shopable & Collectionable & Cardsable & Listable & Editable) | AnyMediaMessageContent | ({
    /** link card message with a custom title/description/picture */
    richLink: {
        url: string;
        text?: string;
        title?: string;
        description?: string;
        image?: WAMediaUpload;
        large?: boolean;
        previewType?: number;
        thumbnailWidth?: number;
    } & Record<string, any>;
} & Mentionable & Contextable & Editable) | ({
    /** audio with a music-style card (artwork/title/author) */
    song: {
        audio: WAMediaUpload;
        artwork?: WAMediaUpload;
        title?: string;
        author?: string;
        url?: string;
        largeThumbnail?: boolean;
        thumbnailWidth?: number;
        mediaType?: number;
    } & Record<string, any>;
} & Mentionable & Contextable & Editable) | ({
    /** raw WhatsApp interactive-family message, passed through via proto fromObject */
    interactiveMessage?: proto.Message.IInteractiveMessage;
    buttonsMessage?: proto.Message.IButtonsMessage;
    listMessage?: proto.Message.IListMessage;
    templateMessage?: proto.Message.ITemplateMessage;
    interactiveAsTemplate?: boolean;
    id?: string;
} & Mentionable & Contextable) | {
    event: EventMessageOptions;
} | ({
    poll: PollMessageOptions;
} & Mentionable & Contextable & Buttonable & Templatable & Interactiveable & Shopable & Collectionable & Cardsable & Listable & Editable) | {
    pollResult: PollResultOptions;
} | {
    pollUpdate: PollUpdateOptions;
} | ({
    album: AlbumMessageOptions;
} & Contextable & Mentionable) | {
    contacts: {
        displayName?: string;
        contacts: proto.Message.IContactMessage[];
    };
} | {
    location: WALocationMessage;
    /** send as a live-location message */
    live?: boolean;
} | {
    react: proto.Message.IReactionMessage;
} | {
    buttonReply: ButtonReplyInfo;
    type: 'template' | 'plain' | 'list' | 'interactive';
} | {
    groupInvite: GroupInviteInfo;
} | {
    sendGroupV4Invite: GroupV4InviteContent;
} | {
    sendGroupInviteV4: GroupV4InviteContent;
} | {
    listReply: Omit<proto.Message.IListResponseMessage, 'contextInfo'>;
} | {
    /** reply to a native-flow interactive message */
    flowReply: {
        text: string;
        name: string;
        paramsJson: string;
        format?: proto.Message.InteractiveResponseMessage.Body.Format;
        version?: number;
    };
} | {
    /** the message key, or the innovatorssoft form `{ key, type, time }` */
    pin: WAMessageKey | {
        key: WAMessageKey;
        type?: proto.PinInChat.Type;
        time?: number;
    };
    type?: proto.PinInChat.Type;
    /**
     * 24 hours, 7 days, 30 days
     */
    time?: 86400 | 604800 | 2592000;
} | {
    product: WASendableProduct;
    businessOwnerJid?: string;
    body?: string;
    footer?: string;
    /** attach interactive buttons to a product message */
    interactiveButtons?: proto.Message.InteractiveMessage.NativeFlowMessage.INativeFlowButton[];
    title?: string;
    subtitle?: string;
    hasMediaAttachment?: boolean;
} | {
    /** productList — renders as a List Message with products */
    productList: ProductListSection[];
    text?: string;
    title?: string;
    buttonText?: string;
    footer?: string;
    businessOwnerJid?: string;
    thumbnail?: WAMediaUpload | string;
} | SharePhoneNumber | RequestPhoneNumber | ({
    album: AlbumMessageOptions;
} & Contextable & Mentionable) | StickerPack | {
    stickerPack: StickerPack;
} | {
    adminInvite: AdminInviteInfo;
} | {
    call: CallCreationInfo;
} | {
    paymentInvite: PaymentInviteInfo;
}
/** Payment invite (flat style) — service type: 1=Facebook Pay, 2=Apple Pay, 3=Stripe */
 | {
    paymentInviteServiceType: 1 | 2 | 3;
    expiry?: number;
}
/** Request payment from another user */
 | {
    requestPaymentFrom: string;
    amount1000?: number;
    currencyCodeIso4217?: string;
}
/** Send an order message (flat style) */
 | {
    orderText: string;
    thumbnail?: Buffer;
    currency?: string;
    orderId?: string;
} | {
    keep: KeepMessageOptions;
} | {
    order: OrderMessageOptions;
} | {
    payment: PaymentMessageOptions;
} | {
    paymentInvite: PaymentInviteInfo | PaymentInviteMessageOptions;
} | {
    interactive: InteractiveMessageOptions;
} | {
    interactivePIX: InteractiveMessagePIXOptions;
} | {
    interactivePAY: InteractiveMessagePAYOptions;
} | {
    statusMention: StatusMentionOptions;
} | {
    collection: CollectionMessageOptions;
} | {
    hdImage: WAMediaUpload;
    caption?: string;
    mimetype?: string;
} | {
    hdVideo: WAMediaUpload;
    caption?: string;
    mimetype?: string;
} | {
    callMessage: proto.Message.IScheduledCallCreationMessage;
} | RichContent) & ViewOnce;
export type AnyMessageContent = AnyRegularMessageContent | {
    forward: WAMessage;
    force?: boolean;
} | {
    /** Delete your message or anyone's message in a group (admin required) */
    delete: WAMessageKey;
} | {
    disappearingMessagesInChat: boolean | number;
} | {
    limitSharing: boolean;
} | {
    /**
     * Send as a group status (story visible to group members).
     * Set to `true` to wrap the message in groupStatusMessageV2.
     * The jid should be a group JID (e.g. `120363xxxxxxxx@g.us`).
     * Can also be set via `options.groupStatus` instead.
     * @example
     * await sock.sendMessage('120363xxx@g.us', { text: 'Hello group!', groupStatus: true })
     */
    groupStatus: boolean;
} | {
    /** Attach an external-ad-reply preview to the message, without
     *  needing to build `contextInfo` yourself first.
     *  @example
     *  await sock.sendMessage(jid, { text: 'Hi', externalAdReply: { title: 'Ad', thumbnail, sourceApp: 'whatsapp' } })
     */
    externalAdReply: proto.ContextInfo.IExternalAdReplyInfo & {
        /** Shorthand for mediaUrl + sourceUrl + thumbnailUrl (any of those set explicitly wins over this) */
        url?: string;
        /** Shorthand for renderLargerThumbnail */
        largeThumbnail?: boolean;
    };
} | {
    /**
     * If true, show the AI icon on the message bubble. Only supported
     * in private (1:1) chats. Can also be set via `options.ai` instead.
     * @example
     * await sock.sendMessage(jid, { image: {...}, ai: true })
     */
    ai: boolean;
} | {
    /**
     * Attach a "secure" Meta service label badge to the message.
     * Can also be set via `options.secureMetaServiceLabel` instead.
     * @example
     * await sock.sendMessage(jid, { text: 'Label', secureMetaServiceLabel: true })
     */
    secureMetaServiceLabel: boolean;
} | {
    /**
     * Attach an invoice note to an image or document message.
     * Only valid alongside `image` or `document` content.
     * @example
     * await sock.sendMessage(jid, { image: {...}, invoiceNote: '🏷️ Invoice' })
     */
    invoiceNote: string;
} | {
    /**
     * Send as a disappearing message using the default expiration.
     * Same as `options.ephemeral` / `options.ephemeralExpiration`.
     * @example
     * await sock.sendMessage(jid, { image: {...}, ephemeral: true })
     */
    ephemeral: boolean;
} | {
    /**
     * Blur the attached media until the recipient taps to reveal it.
     * Can also be set via `options.spoiler` instead.
     * @example
     * await sock.sendMessage(jid, { image: {...}, spoiler: true })
     */
    spoiler: boolean;
} | {
    /**
     * Bypass content generation entirely and send a manually-built
     * proto.IMessage as-is. Useful for constructing message types
     * that don't have a dedicated AnyMessageContent shape yet.
     * @example
     * await sock.sendMessage(jid, { raw: { extendedTextMessage: { text: 'hi' } } })
     */
    raw: proto.IMessage;
} | (proto.IMessage & {
    raw: true;
});
export type GroupMetadataParticipants = Pick<GroupMetadata, 'participants'>;
type MinimalRelayOptions = {
    /** override the message ID with a custom provided string */
    messageId?: string;
    /** override the message key's uuid with a custom provided string (falls back to a generated one if omitted) */
    uuid?: string;
    /** should we use group metadata cache, or fetch afresh from the server; default assumed to be "true" */
    useCachedGroupMetadata?: boolean;
};
export type MessageRelayOptions = MinimalRelayOptions & {
    /** only send to a specific participant; used when a message decryption fails for a single user */
    participant?: {
        jid: string;
        count: number;
    };
    /** additional attributes to add to the WA binary node */
    additionalAttributes?: {
        [_: string]: string;
    };
    additionalNodes?: BinaryNode[];
    /** should we use the devices cache, or fetch afresh from the server; default assumed to be "true" */
    useUserDevicesCache?: boolean;
    /** jid list of participants for status@broadcast */
    statusJidList?: string[];
};
export type MiscMessageGenerationOptions = MinimalRelayOptions & {
    /** optional, if you want to manually set the timestamp of the message */
    timestamp?: Date;
    /** the message you want to quote */
    quoted?: WAMessage;
    /** disappearing messages settings */
    ephemeralExpiration?: number | string;
    /** timeout for media upload to WA server */
    mediaUploadTimeoutMs?: number;
    /** jid list of participants for status@broadcast */
    statusJidList?: string[];
    /** backgroundcolor for status */
    backgroundColor?: string;
    /** font type for status */
    font?: number;
    /** if it is broadcast */
    broadcast?: boolean;
    /** if the message is for a newsletter */
    newsletter?: boolean;
    /** additional binary nodes to attach to the message */
    additionalNodes?: BinaryNode[];
    /** if true, show AI icon on the message bubble. Same as content-level `ai` */
    ai?: boolean;
    /** attach a "secure" Meta service label badge to the message (e.g. for
     *  verified-business / official-service style bubbles). Same as
     *  content-level `secureMetaServiceLabel` */
    secureMetaServiceLabel?: boolean;
    /** wrap the message in `groupStatusMessageV2` (group chats only). Same as
     *  content-level `groupStatus` */
    groupStatus?: boolean;
    /** mark a sticker message as a Lottie/animated sticker. Same as
     *  content-level `isLottie` */
    isLottie?: boolean;
    /** blur the attached media until the recipient taps to reveal it. Same as
     *  content-level `spoiler` */
    spoiler?: boolean;
    /** shorthand for `ephemeralExpiration` using the default expiration —
     *  set to `true` to send as a disappearing message. Same as content-level
     *  `ephemeral`. Ignored if `ephemeralExpiration` is also given. */
    ephemeral?: boolean;
};
export type MessageGenerationOptionsFromContent = MiscMessageGenerationOptions & {
    userJid: string;
    /** used to log that a `quoted` message had nothing quotable */
    logger?: ILogger;
};
export type WAMediaUploadFunctionOpts = {
    fileEncSha256B64: string;
    mediaType: MediaType;
    newsletter?: boolean;
    timeoutMs?: number;
};
export type WAMediaUploadFunction = (encFilePath: string, opts: WAMediaUploadFunctionOpts) => Promise<{
    mediaUrl: string;
    directPath: string;
    thumbnailDirectPath?: string;
    thumbnailSha256?: string;
    handle?: string;
    meta_hmac?: string;
    ts?: number;
    fbid?: number;
}>;
export type MediaGenerationOptions = {
    logger?: ILogger;
    mediaTypeOverride?: MediaType;
    upload: WAMediaUploadFunction;
    /** cache media so it does not have to be uploaded again */
    mediaCache?: CacheStore;
    mediaUploadTimeoutMs?: number;
    options?: RequestInit;
    backgroundColor?: string;
    font?: number;
};
export type MessageContentGenerationOptions = MediaGenerationOptions & {
    getUrlInfo?: (text: string) => Promise<WAUrlInfo | undefined>;
    getProfilePicUrl?: (jid: string, type: 'image' | 'preview') => Promise<string | undefined>;
    getCallLink?: (type: 'audio' | 'video', event?: {
        startTime: number;
    }) => Promise<string | undefined>;
    jid?: string;
    /** Sender's own jid — used to auto-populate `statusAttributions[0].groupStatus.authorJid`
     *  when building a `groupStatus` message (already flows through from
     *  `generateWAMessage`/`generateWAMessageFromContent`'s options; declared
     *  here too so this layer can read it without an `any` cast). */
    userJid?: string;
};
export type MessageGenerationOptions = MessageContentGenerationOptions & MessageGenerationOptionsFromContent;
/**
 * Type of message upsert
 * 1. notify => notify the user, this message was just received
 * 2. append => append the message to the chat history, no notification required
 */
export type MessageUpsertType = 'append' | 'notify';
export type MessageUserReceipt = proto.IUserReceipt;
export type WAMessageUpdate = {
    update: Partial<WAMessage>;
    key: WAMessageKey;
};
export type WAMessageCursor = {
    before: WAMessageKey | undefined;
} | {
    after: WAMessageKey | undefined;
};
export type MessageUserReceiptUpdate = {
    key: WAMessageKey;
    receipt: MessageUserReceipt;
};
export type MediaDecryptionKeyInfo = {
    iv: Uint8Array;
    cipherKey: Uint8Array;
    macKey?: Uint8Array;
};
export type MinimalMessage = Pick<WAMessage, 'key' | 'messageTimestamp'>;
//# sourceMappingURL=Message.d.ts.map