import { Boom } from '@hapi/boom';
import type { Contact } from './Contact.js';
export declare enum SyncState {
    /** The socket is connecting, but we haven't received pending notifications yet. */
    Connecting = 0,
    /** Pending notifications received. Buffering events until we decide whether to sync or not. */
    AwaitingInitialSync = 1,
    /** The initial app state sync (history, etc.) is in progress. Buffering continues. */
    Syncing = 2,
    /** Initial sync is complete, or was skipped. The socket is fully operational and events are processed in real-time. */
    Online = 3
}
export type WAConnectionState = 'open' | 'connecting' | 'close';
export type ConnectionState = {
    /** connection is now open, connecting or closed */
    connection: WAConnectionState;
    /** the error that caused the connection to close */
    lastDisconnect?: {
        error: Boom | Error | undefined;
        date: Date;
    };
    /** is this a new login */
    isNewLogin?: boolean;
    /** the current QR code */
    qr?: string;
    /** has the device received all pending notifications while it was offline */
    receivedPendingNotifications?: boolean;
    /** legacy connection options */
    legacy?: {
        phoneConnected: boolean;
        user?: Contact;
    };
    /**
     * if the client is shown as an active, online client.
     * If this is false, the primary phone and other devices will receive notifs
     * */
    isOnline?: boolean;
    /**
     * When you are in this state, WhatsApp prevents outgoing messages and calls.
     */
    reachoutTimeLock?: ReachoutTimelockState;
    /**
     * Set when WhatsApp sends a passkey companion-linking notification
     * (passkey_prologue_request or crsc_continuation) during pairing.
     * Source: PR #2696 (frndchagas)
     */
    passkeyRequest?: {
        type: 'passkey_prologue_request' | 'crsc_continuation';
        hasOptions: boolean;
    };
};
export type ReachoutTimelockState = {
    isActive?: boolean;
    timeEnforcementEnds?: Date;
    enforcementType?: ReachoutTimelockEnforcementType;
};
export declare enum ReachoutTimelockEnforcementType {
    BIZ_COMMERCE_VIOLATION_ALCOHOL = "BIZ_COMMERCE_VIOLATION_ALCOHOL",
    BIZ_COMMERCE_VIOLATION_ADULT = "BIZ_COMMERCE_VIOLATION_ADULT",
    BIZ_COMMERCE_VIOLATION_ANIMALS = "BIZ_COMMERCE_VIOLATION_ANIMALS",
    BIZ_COMMERCE_VIOLATION_BODY_PARTS_FLUIDS = "BIZ_COMMERCE_VIOLATION_BODY_PARTS_FLUIDS",
    BIZ_COMMERCE_VIOLATION_DATING = "BIZ_COMMERCE_VIOLATION_DATING",
    BIZ_COMMERCE_VIOLATION_DIGITAL_SERVICES_PRODUCTS = "BIZ_COMMERCE_VIOLATION_DIGITAL_SERVICES_PRODUCTS",
    BIZ_COMMERCE_VIOLATION_DRUGS = "BIZ_COMMERCE_VIOLATION_DRUGS",
    BIZ_COMMERCE_VIOLATION_DRUGS_ONLY_OTC = "BIZ_COMMERCE_VIOLATION_DRUGS_ONLY_OTC",
    BIZ_COMMERCE_VIOLATION_GAMBLING = "BIZ_COMMERCE_VIOLATION_GAMBLING",
    BIZ_COMMERCE_VIOLATION_HEALTHCARE = "BIZ_COMMERCE_VIOLATION_HEALTHCARE",
    BIZ_COMMERCE_VIOLATION_REAL_FAKE_CURRENCY = "BIZ_COMMERCE_VIOLATION_REAL_FAKE_CURRENCY",
    BIZ_COMMERCE_VIOLATION_SUPPLEMENTS = "BIZ_COMMERCE_VIOLATION_SUPPLEMENTS",
    BIZ_COMMERCE_VIOLATION_TOBACCO = "BIZ_COMMERCE_VIOLATION_TOBACCO",
    BIZ_COMMERCE_VIOLATION_VIOLENT_CONTENT = "BIZ_COMMERCE_VIOLATION_VIOLENT_CONTENT",
    BIZ_COMMERCE_VIOLATION_WEAPONS = "BIZ_COMMERCE_VIOLATION_WEAPONS",
    BIZ_QUALITY = "BIZ_QUALITY",
    /** This means there is no restriction */
    DEFAULT = "DEFAULT",
    WEB_COMPANION_ONLY = "WEB_COMPANION_ONLY"
}
export declare enum NewChatMessageCappingStatusType {
    NONE = "NONE",
    FIRST_WARNING = "FIRST_WARNING",
    SECOND_WARNING = "SECOND_WARNING",
    CAPPED = "CAPPED"
}
export declare enum NewChatMessageCappingMVStatusType {
    NOT_ELIGIBLE = "NOT_ELIGIBLE",
    NOT_ACTIVE = "NOT_ACTIVE",
    ACTIVE = "ACTIVE",
    ACTIVE_UPGRADE_AVAILABLE = "ACTIVE_UPGRADE_AVAILABLE"
}
export declare enum NewChatMessageCappingOTEStatusType {
    NOT_ELIGIBLE = "NOT_ELIGIBLE",
    ELIGIBLE = "ELIGIBLE",
    ACTIVE_IN_CURRENT_CYCLE = "ACTIVE_IN_CURRENT_CYCLE",
    EXHAUSTED = "EXHAUSTED"
}
export type NewChatMessageCapInfo = {
    total_quota?: number;
    used_quota?: number;
    cycle_start_timestamp?: string;
    cycle_end_timestamp?: string;
    server_sent_timestamp?: string;
    ote_status?: NewChatMessageCappingOTEStatusType;
    mv_status?: NewChatMessageCappingMVStatusType;
    capping_status?: NewChatMessageCappingStatusType;
    subscription_status?: string;
    /** set when the event comes from a rejected send (ack error 475) instead of a server push */
    jid?: string;
    /** the id of the message that was rejected with ack error 475 */
    messageId?: string;
};
/** Normalised result of `sock.fetchNewChatMessageCap()` (the raw reply is kept in `response`). */
export type NewChatMessageCap = {
    status: NewChatMessageCappingStatusType | string;
    /** `true` once `status` is `CAPPED`: new chats are refused */
    capped: boolean;
    /** `true` on `FIRST_WARNING` and `SECOND_WARNING` */
    warned: boolean;
    /** `true` when the server sent no quota (or a negative one), i.e. there is no limit to count down */
    unlimited: boolean;
    totalQuota?: number;
    usedQuota?: number;
    /** `totalQuota - usedQuota`, never negative; `null` when `unlimited` */
    remaining: number | null;
    /** cycle start / end, unix **seconds** */
    cycleStart?: number;
    cycleEnd?: number;
    /** server clock (unix seconds) when it answered */
    serverTime?: number;
    oteStatus?: NewChatMessageCappingOTEStatusType;
    mvStatus?: NewChatMessageCappingMVStatusType;
    subscriptionStatus?: string;
    response?: NewChatMessageCapInfo;
};
//# sourceMappingURL=State.d.ts.map