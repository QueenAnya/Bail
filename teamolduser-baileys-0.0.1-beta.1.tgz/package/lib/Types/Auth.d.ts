import type { proto } from '../../WAProto/index.js';
import type { Contact } from './Contact.js';
import type { MinimalMessage } from './Message.js';
export type KeyPair = {
    public: Uint8Array;
    private: Uint8Array;
};
export type SignedKeyPair = {
    keyPair: KeyPair;
    signature: Uint8Array;
    keyId: number;
    timestampS?: number;
};
export type ProtocolAddress = {
    name: string;
    deviceId: number;
};
export type SignalIdentity = {
    identifier: ProtocolAddress;
    identifierKey: Uint8Array;
};
export type LIDMapping = {
    pn: string;
    lid: string;
};
export type LTHashState = {
    version: number;
    hash: Buffer;
    indexValueMap: {
        [indexMacBase64: string]: {
            valueMac: Uint8Array | Buffer;
        };
    };
};
export type SignalCreds = {
    readonly signedIdentityKey: KeyPair;
    readonly signedPreKey: SignedKeyPair;
    readonly registrationId: number;
};
export type AccountSettings = {
    /** unarchive chats when a new message is received */
    unarchiveChats: boolean;
    /** the default mode to start new conversations with */
    defaultDisappearingMode?: Pick<proto.IConversation, 'ephemeralExpiration' | 'ephemeralSettingTimestamp'>;
};
export type AuthenticationCreds = SignalCreds & {
    readonly noiseKey: KeyPair;
    readonly pairingEphemeralKeyPair: KeyPair;
    advSecretKey: string;
    me?: Contact;
    account?: proto.IADVSignedDeviceIdentity;
    signalIdentities?: SignalIdentity[];
    myAppStateKeyId?: string;
    firstUnuploadedPreKeyId: number;
    nextPreKeyId: number;
    lastAccountSyncTimestamp?: number;
    platform?: string;
    processedHistoryMessages: MinimalMessage[];
    /** number of times history & app state has been synced */
    accountSyncCounter: number;
    accountSettings: AccountSettings;
    registered: boolean;
    pairingCode: string | undefined;
    lastPropHash: string | undefined;
    routingInfo: Buffer | undefined;
    additionalData?: any | undefined;
};
export type SignalDataTypeMap = {
    'pre-key': KeyPair;
    session: Uint8Array;
    'sender-key': Uint8Array;
    'sender-key-memory': {
        [jid: string]: boolean;
    };
    'app-state-sync-key': proto.Message.IAppStateSyncKeyData;
    'app-state-sync-version': LTHashState;
    'lid-mapping': string;
    'device-list': string[];
    tctoken: {
        token: Buffer;
        timestamp?: string;
        senderTimestamp?: number;
    };
    'identity-key': Uint8Array;
};
export type SignalDataSet = {
    [T in keyof SignalDataTypeMap]?: {
        [id: string]: SignalDataTypeMap[T] | null;
    };
};
type Awaitable<T> = T | Promise<T>;
export type SignalKeyStore = {
    get<T extends keyof SignalDataTypeMap>(type: T, ids: string[]): Awaitable<{
        [id: string]: SignalDataTypeMap[T];
    }>;
    set(data: SignalDataSet): Awaitable<void>;
    /** clear all the data in the store */
    clear?(): Awaitable<void>;
    /**
     * Enumerate every (id, value) pair for a type. Optional — required by
     * `migrateAuthState` and bulk operations. Stream rather than buffer.
     */
    list?<T extends keyof SignalDataTypeMap>(type: T): AsyncIterable<readonly [id: string, value: SignalDataTypeMap[T]]>;
    /**
     * Ids-only fast path. Optional. Adapters that can satisfy this without
     * reading values (e.g. SQL `SELECT id`) should implement it.
     */
    listIds?<T extends keyof SignalDataTypeMap>(type: T): AsyncIterable<string>;
};
/**
 * A store that can enumerate its records.
 *
 * `list` is optional on {@link SignalKeyStore} because a third-party store may not be able to enumerate. Every adapter
 * in this package implements it, so they return this narrower type — which makes the compiler, not a runtime check,
 * the thing that stops a non-enumerable store being used as a migration source.
 */
export type SignalKeyStoreWithListing = SignalKeyStore & {
    list<T extends keyof SignalDataTypeMap>(type: T): AsyncIterable<readonly [id: string, value: SignalDataTypeMap[T]]>;
};
/** An {@link AuthenticationState} whose keys can be enumerated — the source side of `migrateAuthState`. */
export type AuthenticationStateWithListing = Omit<AuthenticationState, 'keys'> & {
    keys: SignalKeyStoreWithListing;
};
export type SignalKeyStoreWithTransaction = SignalKeyStore & {
    isInTransaction: () => boolean;
    transaction<T>(exec: () => Promise<T>, key: string): Promise<T>;
};
/** Names of the typed records a {@link SignalKeyStore} holds. */
export type SignalDataType = keyof SignalDataTypeMap;
/** Identifies one (type, id) record in the key store — the unit of locking. */
export type RecordRef = {
    type: SignalDataType;
    id: string;
};
export type TransactionCapabilityOptions = {
    maxCommitRetries: number;
    delayBetweenTriesMs: number;
};
export type SignalAuthState = {
    creds: SignalCreds;
    keys: SignalKeyStore | SignalKeyStoreWithTransaction;
};
export type AuthenticationState = {
    creds: AuthenticationCreds;
    keys: SignalKeyStore;
};
export {};
//# sourceMappingURL=Auth.d.ts.map