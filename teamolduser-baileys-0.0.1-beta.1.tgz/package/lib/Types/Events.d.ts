import type { Boom } from '@hapi/boom';
import { proto } from '../../WAProto/index.js';
import type { ActiveCall } from '../Voip/voip-engine.js';
import type { AuthenticationCreds, LIDMapping } from './Auth.js';
import type { WACallEvent } from './Call.js';
import type { Chat, ChatUpdate, PresenceData } from './Chat.js';
import type { Contact } from './Contact.js';
import type { GroupMetadata, GroupParticipant, ParticipantAction, RequestJoinAction, RequestJoinMethod } from './GroupMetadata.js';
import type { Label } from './Label.js';
import type { LabelAssociation } from './LabelAssociation.js';
import type { MessageUpsertType, MessageUserReceiptUpdate, WAMessage, WAMessageKey, WAMessageUpdate } from './Message.js';
import type { ConnectionState, NewChatMessageCapInfo } from './State.js';
export type BaileysEventMap = {
    /** connection state has been updated -- WS closed, opened, connecting etc. */
    'connection.update': Partial<ConnectionState>;
    /** Emitted when the phone returns a link preview via PDO response. PR #2701 */
    'link-preview.update': {
        /** The request stanza ID that correlates to the requestPhoneLinkPreview call */
        requestId: string;
        /** URL for which the preview was generated */
        url: string;
        urlInfo: import('./Message.js').WAUrlInfo;
    };
    /** credentials updated -- some metadata, keys or something */
    'creds.update': Partial<AuthenticationCreds>;
    /** set chats (history sync), everything is reverse chronologically sorted */
    'messaging-history.set': {
        chats: Chat[];
        contacts: Contact[];
        messages: WAMessage[];
        lidPnMappings?: LIDMapping[];
        isLatest?: boolean;
        progress?: number | null;
        syncType?: proto.HistorySync.HistorySyncType | null;
        pastParticipants?: proto.IPastParticipants[] | null;
        chunkOrder?: number | null;
        peerDataRequestSessionId?: string | null;
    };
    /** signals history sync milestones (completion or stall) per sync type */
    'messaging-history.status': {
        /** which sync phase this status refers to */
        syncType: proto.HistorySync.HistorySyncType;
        /** the status of this sync phase */
        status: 'complete' | 'paused';
        /**
         * progress === 100 was received from the server.
         * when false, completion was inferred via timeout (no more chunks arriving).
         */
        explicit: boolean;
    };
    /** upsert chats */
    'chats.upsert': Chat[];
    /** update the given chats */
    'chats.update': ChatUpdate[];
    'lid-mapping.update': LIDMapping;
    /** delete chats with given ID */
    'chats.delete': string[];
    /** presence of contact in a chat updated */
    'presence.update': {
        id: string;
        presences: {
            [participant: string]: PresenceData;
        };
    };
    'contacts.upsert': Contact[];
    'contacts.update': Partial<Contact>[];
    'messages.delete': {
        keys: WAMessageKey[];
    } | {
        jid: string;
        all: true;
    };
    'messages.update': WAMessageUpdate[];
    'messages.media-update': {
        key: WAMessageKey;
        media?: {
            ciphertext: Uint8Array;
            iv: Uint8Array;
        };
        error?: Boom;
    }[];
    /**
     * add/update the given messages. If they were received while the connection was online,
     * the update will have type: "notify"
     * if requestId is provided, then the messages was received from the phone due to it being unavailable
     *  */
    'messages.upsert': {
        messages: WAMessage[];
        type: MessageUpsertType;
        requestId?: string;
    };
    /**
     * PR #2748: a contact's Signal identity key changed (e.g. they reinstalled
     * WhatsApp or switched devices) and Baileys refreshed the session for
     * future messages. `me` is always `false` here — self identity changes on
     * the primary device are filtered out before this event would fire.
     */
    'identity-change': {
        jid: string;
        me: boolean;
    };
    /** message was reacted to. If reaction was removed -- then "reaction.text" will be falsey */
    'messages.reaction': {
        key: WAMessageKey;
        reaction: proto.IReaction;
    }[];
    'message-receipt.update': MessageUserReceiptUpdate[];
    'groups.upsert': GroupMetadata[];
    'groups.update': Partial<GroupMetadata>[];
    /** "Limit sharing" (forwarding limit) was switched on/off in a group */
    'limit-sharing.update': {
        id: string;
        author: string;
        action: 'on' | 'off';
        trigger?: proto.LimitSharing.TriggerType | null;
        update_time?: number | null;
    };
    /** A community owner / super-admin role change */
    'community-owner.update': {
        id: string;
        author: string;
        user: string;
        new_role: string;
        update_time?: number | null;
    };
    /** apply an action to participants in a group */
    'group-participants.update': {
        id: string;
        author: string;
        authorPn?: string;
        authorUsername?: string;
        participants: GroupParticipant[];
        action: ParticipantAction;
    };
    'group.join-request': {
        id: string;
        author: string;
        authorPn?: string;
        authorUsername?: string;
        participant: string;
        participantPn?: string;
        action: RequestJoinAction;
        method: RequestJoinMethod;
    };
    'group.member-tag.update': {
        groupId: string;
        participant: string;
        participantAlt?: string;
        label: string;
        messageTimestamp?: number;
    };
    'blocklist.set': {
        blocklist: string[];
    };
    'blocklist.update': {
        blocklist: string[];
        type: 'add' | 'remove';
    };
    /** Receive an update on a call, including when the call was received, rejected, accepted */
    call: WACallEvent[];
    /** An incoming call is ringing (needs `voip` in the socket config) — `call.accept({ audioSource })` / `call.reject()` */
    'call.incoming': ActiveCall;
    'labels.edit': Label;
    'labels.association': {
        association: LabelAssociation;
        type: 'add' | 'remove';
    };
    /** Newsletter-related events */
    'newsletter.reaction': {
        id: string;
        server_id: string;
        reaction: {
            code?: string;
            count?: number;
            removed?: boolean;
        };
    };
    'newsletter.view': {
        id: string;
        server_id: string;
        count: number;
    };
    'newsletter-participants.update': {
        id: string;
        author: string;
        user: string;
        new_role: string;
        action: string;
    };
    'newsletter-settings.update': {
        id: string;
        update: any;
    };
    /** Raw mex notification for an operation this library does not model */
    'mex.notification': {
        operation: string;
        data: any;
    };
    'newsletter-admin-profile.update': {
        id: string;
        adminProfile: {
            id?: string;
            name: string;
            pictureId?: string;
            pictureDirectPath?: string;
        } | null;
    };
    'message-capping.update': NewChatMessageCapInfo;
    /** Settings and actions sync events */
    'chats.lock': {
        id: string;
        locked: boolean;
    };
    'settings.update': {
        setting: 'unarchiveChats';
        value: boolean;
    } | {
        setting: 'locale';
        value: string;
    } | {
        setting: 'disableLinkPreviews';
        value: proto.SyncActionValue.IPrivacySettingDisableLinkPreviewsAction;
    } | {
        setting: 'timeFormat';
        value: proto.SyncActionValue.ITimeFormatAction;
    } | {
        setting: 'privacySettingRelayAllCalls';
        value: proto.SyncActionValue.IPrivacySettingRelayAllCalls;
    } | {
        setting: 'statusPrivacy';
        value: proto.SyncActionValue.IStatusPrivacyAction;
    } | {
        setting: 'notificationActivitySetting';
        value: proto.SyncActionValue.NotificationActivitySettingAction.NotificationActivitySetting;
    } | {
        setting: 'channelsPersonalisedRecommendation';
        value: proto.SyncActionValue.IPrivacySettingChannelsPersonalisedRecommendationAction;
    };
};
export type BufferedEventData = {
    historySets: {
        chats: {
            [jid: string]: Chat;
        };
        contacts: {
            [jid: string]: Contact;
        };
        messages: {
            [uqId: string]: WAMessage;
        };
        empty: boolean;
        isLatest: boolean;
        progress?: number | null;
        syncType?: proto.HistorySync.HistorySyncType;
        chunkOrder?: number | null;
        peerDataRequestSessionId?: string;
        pastParticipants?: proto.IPastParticipants[];
    };
    chatUpserts: {
        [jid: string]: Chat;
    };
    chatUpdates: {
        [jid: string]: ChatUpdate;
    };
    chatDeletes: Set<string>;
    contactUpserts: {
        [jid: string]: Contact;
    };
    contactUpdates: {
        [jid: string]: Partial<Contact>;
    };
    messageUpserts: {
        [key: string]: {
            type: MessageUpsertType;
            message: WAMessage;
        };
    };
    messageUpdates: {
        [key: string]: WAMessageUpdate;
    };
    messageDeletes: {
        [key: string]: WAMessageKey;
    };
    messageReactions: {
        [key: string]: {
            key: WAMessageKey;
            reactions: proto.IReaction[];
        };
    };
    messageReceipts: {
        [key: string]: {
            key: WAMessageKey;
            userReceipt: proto.IUserReceipt[];
        };
    };
    groupUpdates: {
        [jid: string]: Partial<GroupMetadata>;
    };
};
export type BaileysEvent = keyof BaileysEventMap;
export interface BaileysEventEmitter {
    on<T extends keyof BaileysEventMap>(event: T, listener: (arg: BaileysEventMap[T]) => void): void;
    off<T extends keyof BaileysEventMap>(event: T, listener: (arg: BaileysEventMap[T]) => void): void;
    removeAllListeners<T extends keyof BaileysEventMap>(event: T): void;
    emit<T extends keyof BaileysEventMap>(event: T, arg: BaileysEventMap[T]): boolean;
}
//# sourceMappingURL=Events.d.ts.map