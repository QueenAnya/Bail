import type { Agent } from 'https';
import type { URL } from 'url';
import { proto } from '../../WAProto/index.js';
import type { ILogger } from '../Utils/logger.js';
import type { AuthenticationState, LIDMapping, SignalAuthState, TransactionCapabilityOptions } from './Auth.js';
import type { GroupMetadata } from './GroupMetadata.js';
import { type MediaConnInfo, type WAMessageKey } from './Message.js';
import type { SignalRepositoryWithLIDStore } from './Signal.js';
export type WAVersion = [number, number, number];
export type WABrowserDescription = [string, string, string];
export type CacheStore = {
    /** get a cached key and change the stats */
    get<T>(key: string): Promise<T> | T | undefined;
    /** set a key in the cache */
    set<T>(key: string, value: T): Promise<void> | void | number | boolean;
    /** delete a key from the cache */
    del(key: string): void | Promise<void> | number | boolean;
    /** flush all data */
    flushAll(): void | Promise<void>;
    close?: () => void;
};
export type PossiblyExtendedCacheStore = CacheStore & {
    mget?: <T>(keys: string[]) => Promise<Record<string, T | undefined>>;
    mset?: <T>(entries: {
        key: string;
        value: T;
    }[]) => Promise<void> | void | number | boolean;
    mdel?: (keys: string[]) => void | Promise<void> | number | boolean;
};
export type PatchedMessageWithRecipientJID = proto.IMessage & {
    recipientJid?: string;
};
export type WAUsernameQuery = string | {
    username: string;
    usernameKey?: string;
    lid?: string;
};
export type WAUsernameLookupResult = {
    username: string;
    jid: string;
    exists: boolean;
    /** Populated when the resolved user has a LID (only via the
     *  `resolveUsername`-backed lookup — the raw USync-only path doesn't
     *  carry this). */
    lid?: string;
    /** Populated alongside `lid` when a PN↔LID mapping is known. */
    pn?: string;
};
export type WAUsernameInfo = {
    jid: string;
    username?: string;
};
export type SocketConfig = {
    /** the WS url to connect to WA */
    waWebSocketUrl: string | URL;
    /**
     * Permit a `waWebSocketUrl` that is not a WhatsApp host.
     *
     * Off by default: the socket refuses any endpoint other than WhatsApp's own hosts (and localhost, for local
     * test servers). A library that will happily connect anywhere is indistinguishable from one that phones home,
     * so the exception has to be asked for explicitly. Turn it on only for a proxy or a mock server you control.
     */
    allowCustomEndpoint?: boolean;
    /**
     * Send `passive: true` in the login node, as upstream WhiskeySockets does.
     *
     * Off by default: this package sends `passive: false` because real reconnect/import testing reported WhatsApp
     * terminating existing-companion logins with a 428 when they arrive as passive (upstream PR #2682, closed as
     * stale rather than merged). Registration always uses `false` in both designs.
     *
     * Flip it to `true` to reproduce upstream behaviour on your own account, e.g. while comparing the two.
     */
    passiveLogin?: boolean;
    /** Fails the connection if the socket times out in this interval */
    connectTimeoutMs: number;
    /** Default timeout for queries, undefined for no timeout */
    defaultQueryTimeoutMs: number | undefined;
    /** ping-pong interval for WS connection */
    keepAliveIntervalMs: number;
    /** should baileys use the mobile api instead of the multi device api
     * @deprecated This feature has been removed
     */
    mobile?: boolean;
    /** proxy agent */
    agent?: Agent;
    /** logger */
    logger: ILogger;
    /** version to connect with */
    version: WAVersion;
    /** override browser config */
    browser: WABrowserDescription;
    /**
     * Overrides the human-readable client description sent as
     * `companion_platform_display` when pairing by code.
     *
     * WhatsApp validates this field: an unrecognised value makes the server
     * answer `400 bad-request` to `companion_hello`. By default it is derived
     * from `browser`, which breaks pairing by code for any integrator that puts
     * a product name in `browser[0]` -- even though that same value is accepted
     * for QR pairing and is precisely what the user then sees under "Linked
     * devices".
     *
     * The failure is silent: `requestPairingCode()` returns a locally generated
     * code the server never accepted, so the code simply does not work when
     * typed, with nothing in the logs to say why.
     */
    companionPlatformDisplay?: string;
    /**
     * VoIP options. Passing this (even `true`) turns on incoming-call handling: offers are answered
     * with a `preaccept` and emitted as `call.incoming` so you can `call.accept({ audioSource })`
     * or `call.reject()`. Outgoing calls (`sock.initiateCall`) work without it.
     *
     *   makeWASocket({ voip: { maxConcurrentCalls: 3, onLimit: 'reject' } })
     */
    voip?: boolean | {
        maxConcurrentCalls?: number;
        onLimit?: 'reject' | 'queue';
    };
    /** Initial pushName carried in the registration ClientPayload (used by mock servers for deterministic phone assignment). */
    pushName?: string;
    /** agent used for fetch requests -- uploading/downloading media */
    fetchAgent?: Agent;
    /** should the QR be printed in the terminal
     * @deprecated This feature has been removed
     */
    printQRInTerminal?: boolean;
    /** should events be emitted for actions done by this socket connection */
    emitOwnEvents: boolean;
    /** custom upload hosts to upload media to */
    customUploadHosts: MediaConnInfo['hosts'];
    /** time to wait between sending new retry requests */
    retryRequestDelayMs: number;
    /** enable the optional anti-crash guard (needs `@rexxhayanasi/elaina-anchorguard`); exposed as `sock.anchorGuard` */
    AnchorGuard?: boolean;
    /** options passed to the anti-crash guard */
    AnchorGuardConfig?: Record<string, any>;
    /** opt-in voice-note transcription: `{ enabled, transcribe(ctx), allowFromMe?, pttOnly?, maxDuration? ... }` */
    voiceRecognition?: Record<string, any>;
    /** max listeners allowed on the socket's event emitter before Node warns (default 64) */
    maxEventListeners?: number;
    /** max retry count */
    maxMsgRetryCount: number;
    /** max undecryptable messages waiting for a retry request at once; beyond this they are acked without retry (default 64) */
    maxRetryQueueSize: number;
    /** embed the sender key distribution message in group messages when we already hold a sender key (default true) */
    inlineSenderKeyDistribution?: boolean;
    /** base delay between resends after a retryable server nack (multiplied by the attempt number) */
    ackRetryDelayMs: number;
    /** max number of resends of one message after retryable server nacks */
    maxAckRetryCount: number;
    /** how long a requested pairing code stays valid before the pairing attempt is abandoned (ms) */
    pairingCodeTimeoutMs: number;
    /** time to wait for the generation of the next QR in ms */
    qrTimeout?: number;
    /** provide an auth state object to maintain the auth state */
    auth: AuthenticationState;
    /** manage history processing with this control; by default will sync up everything */
    shouldSyncHistoryMessage: (msg: proto.Message.IHistorySyncNotification) => boolean;
    /** transaction capability options for SignalKeyStore */
    transactionOpts: TransactionCapabilityOptions;
    /** marks the client as online whenever the socket successfully connects */
    markOnlineOnConnect: boolean;
    /** alphanumeric country code (USA -> US) for the number used */
    countryCode: string;
    /** cache to store username resolution mappings */
    usernameCache?: PossiblyExtendedCacheStore;
    /** provide a cache to store media, so does not have to be re-uploaded */
    mediaCache?: CacheStore;
    /**
     * map to store the retry counts for failed messages;
     * used to determine whether to retry a message or not */
    msgRetryCounterCache?: CacheStore;
    /** provide a cache to store a user's device list */
    userDevicesCache?: PossiblyExtendedCacheStore;
    /** cache of recently sent messages, used to resend after a retryable server nack */
    outboundResendCache?: PossiblyExtendedCacheStore;
    /** cache to store call offers */
    callOfferCache?: CacheStore;
    /** cache to track placeholder resends */
    placeholderResendCache?: CacheStore;
    /** width for link preview images */
    linkPreviewImageThumbnailWidth: number;
    /** Should Baileys ask the phone for full history, will be received async */
    syncFullHistory: boolean;
    /** Should baileys fire init queries automatically, default true */
    fireInitQueries: boolean;
    /**
     * generate a high quality link preview,
     * entails uploading the jpegThumbnail to WA
     * */
    generateHighQualityLinkPreview: boolean;
    /**
     * Optional callback for Shortcake (CRSC) passkey companion-linking.
     * When provided, the client can complete headless WebAuthn assertions
     * during the passkey pairing flow initiated by `passkey_prologue_request`.
     *
     * Receives a `challenge` bytes and must return a signed assertion
     * (FIDO2/WebAuthn AuthenticatorAssertionResponse.signature).
     *
     * Without this callback, the `passkeyRequest` connection.update is still
     * emitted but the handshake is not completed automatically.
     * Source: PR #2689 (vinikjkkj — WB collaborator)
     */
    signPasskeyAssertion?: (challenge: Uint8Array) => Promise<Uint8Array>;
    /** Enable automatic session recreation for failed messages */
    enableAutoSessionRecreation: boolean;
    /** Enable recent message caching for retry handling */
    enableRecentMessageCache: boolean;
    /**
     * Returns if a jid should be ignored,
     * no event for that jid will be triggered.
     * Messages from that jid will also not be decrypted
     * */
    shouldIgnoreJid: (jid: string) => boolean | undefined;
    /**
     * Optionally patch the message before sending out
     * */
    patchMessageBeforeSending: (msg: proto.IMessage, recipientJids?: string[]) => Promise<PatchedMessageWithRecipientJID[] | PatchedMessageWithRecipientJID> | PatchedMessageWithRecipientJID[] | PatchedMessageWithRecipientJID;
    /** verify app state MACs */
    appStateMacVerification: {
        patch: boolean;
        snapshot: boolean;
    };
    /** options for HTTP fetch requests */
    options: RequestInit;
    /**
     * fetch a message from your store
     * implement this so that messages failed to send
     * (solves the "this message can take a while" issue) can be retried
     * */
    getMessage: (key: WAMessageKey) => Promise<proto.IMessage | undefined>;
    /** cached group metadata, use to prevent redundant requests to WA & speed up msg sending */
    cachedGroupMetadata: (jid: string) => Promise<GroupMetadata | undefined>;
    makeSignalRepository: (auth: SignalAuthState, logger: ILogger, pnToLIDFunc?: (jids: string[]) => Promise<LIDMapping[] | undefined>) => SignalRepositoryWithLIDStore;
};
//# sourceMappingURL=Socket.d.ts.map