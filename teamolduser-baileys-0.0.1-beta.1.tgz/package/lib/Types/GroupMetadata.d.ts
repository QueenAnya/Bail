import type { Contact } from './Contact.js';
import type { WAMessageAddressingMode } from './Message.js';
export type GroupParticipant = Contact & {
    isAdmin?: boolean;
    isSuperAdmin?: boolean;
    admin?: 'admin' | 'superadmin' | null;
};
export type ParticipantAction = 'add' | 'remove' | 'promote' | 'demote' | 'modify';
export type RequestJoinAction = 'created' | 'revoked' | 'rejected';
export type RequestJoinMethod = 'invite_link' | 'linked_group_join' | 'non_admin_add' | undefined;
export interface GroupMetadata {
    id: string;
    notify?: string;
    /** group uses 'lid' or 'pn' to send messages */
    addressingMode?: WAMessageAddressingMode;
    /** whether new members can see earlier history (see GroupHistoryToggleMode) */
    groupHistoryToggleMode?: number;
    owner: string | undefined;
    ownerPn?: string | undefined;
    ownerLid?: string | undefined;
    ownerUsername?: string | undefined;
    owner_country_code?: string | undefined;
    ownerCountry?: string | undefined;
    subject: string;
    /** group subject owner */
    subjectOwner?: string;
    subjectOwnerPn?: string;
    subjectOwnerLid?: string;
    subjectOwnerUsername?: string;
    /** group subject modification date */
    subjectTime?: number;
    creation?: number;
    desc?: string;
    descOwner?: string;
    descOwnerPn?: string;
    descOwnerLid?: string;
    descOwnerUsername?: string;
    descId?: string;
    descTime?: number;
    /** if this group is part of a community, it returns the jid of the community to which it belongs */
    linkedParent?: string;
    /** is set when the group only allows admins to change group settings */
    restrict?: boolean;
    /** is set when the group only allows admins to write messages */
    announce?: boolean;
    /** is set when the group also allows members to add participants */
    memberAddMode?: boolean;
    /** Request approval to join the group */
    joinApprovalMode?: boolean;
    /** is this a community */
    isCommunity?: boolean;
    /** is this the announce of a community */
    isCommunityAnnounce?: boolean;
    /** number of group participants */
    size?: number;
    participants: GroupParticipant[];
    ephemeralDuration?: number;
    inviteCode?: string;
    /** the person who added you to group or changed some setting in group */
    author?: string;
    /** who may share the group link (set by `NotificationGroupMemberLinkPropertyUpdate`) */
    member_link_mode?: string;
    authorPn?: string;
    authorUsername?: string;
}
export interface WAGroupCreateResponse {
    status: number;
    gid?: string;
    participants?: [{
        [key: string]: {};
    }];
}
export interface GroupModificationResponse {
    status: number;
    participants?: {
        [key: string]: {};
    };
}
/** Whether new members of a group can see the group's earlier message history */
export declare enum GroupHistoryToggleMode {
    DEFAULT = 0,
    ON = 1,
    OFF = 2
}
//# sourceMappingURL=GroupMetadata.d.ts.map