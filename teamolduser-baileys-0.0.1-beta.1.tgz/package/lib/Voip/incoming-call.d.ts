export type OfferRelayEndpoint = {
    ip: string;
    port: number;
    token: string;
    authToken?: string;
    key: string;
    relayId: number;
    protocol: number;
    c2rRtt?: number;
    relayName: string;
    isFna: boolean;
    addressBytes: Uint8Array;
};
export type ParsedOfferRelays = {
    relays: OfferRelayEndpoint[];
    participantJids: string[];
};
/** Stanza id in the same shape the other call stanzas use. */
export declare const generateCallStanzaId: () => string;
/**
 * Parses the `<relay>` block(s) and participant list out of an incoming
 * `<call><offer>` stanza. Relays are returned fastest-first, FNA last.
 */
export declare const parseOfferRelays: (node: any) => ParsedOfferRelays;
/** True when the `<call>` stanza carries an `<offer>` child. */
export declare const getOfferNode: (callNode: any) => any | undefined;
export declare const buildPreacceptStanza: (callId: string, callCreator: string, to: string, isVideo: boolean) => {
    tag: string;
    attrs: {
        to: string;
        id: string;
    };
    content: any[];
};
export declare const buildRelayLatencyStanza: (callId: string, callCreator: string, to: string, relays: OfferRelayEndpoint[], destinationJids: string[]) => {
    tag: string;
    attrs: {
        to: string;
        id: string;
    };
    content: any[];
};
export declare const buildMuteV2Stanza: (callId: string, callCreator: string, to: string) => {
    tag: string;
    attrs: {
        to: string;
        id: string;
    };
    content: any[];
};
export declare const buildTransportStanza: (callId: string, callCreator: string, to: string) => {
    tag: string;
    attrs: {
        to: string;
        id: string;
    };
    content: any[];
};
/**
 * `<accept>` carrying the re-encrypted call key. `to` must be the caller's
 * DEVICE jid — a bare address never registers on the caller's phone.
 */
export declare const buildAcceptStanza: (callId: string, callCreator: string, to: string, isVideo: boolean, encNode: any, deviceIdentity?: any) => {
    tag: string;
    attrs: {
        to: string;
        id: string;
    };
    content: any[];
};
export declare const buildRejectStanza: (callId: string, callCreator: string, to: string, reason?: string) => {
    tag: string;
    attrs: {
        to: string;
        id: string;
    };
    content: any[];
};
//# sourceMappingURL=incoming-call.d.ts.map