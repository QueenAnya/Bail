export type VoipMemoryStatsInput = {
    activeWorkers?: number;
    relayConnections?: number;
    relayConnectionCount?: number;
    ffmpegProcesses?: number;
    ffmpegProcessCount?: number;
    activeCalls?: number;
    activeCallCount?: number;
    waitingCalls?: number;
    totalManagedCalls?: number;
};
export declare class VoipResourceManager {
    private static wasmModuleCache;
    private static assetPaths;
    private static workers;
    private static relays;
    private static ffmpeg;
    static get activeWorkers(): number;
    static get relayConnections(): number;
    static get ffmpegProcesses(): number;
    static registerWorker(): void;
    static unregisterWorker(): void;
    static registerRelayConnection(): void;
    static unregisterRelayConnection(): void;
    static registerFfmpegProcess(): void;
    static unregisterFfmpegProcess(): void;
    /** Compile a WASM binary once and reuse the module for later engines. */
    static compileOrGetModule(wasmBinary: BufferSource, cacheKey?: string): Promise<WebAssembly.Module>;
    static getCachedModule(cacheKey?: string): WebAssembly.Module | undefined;
    static setCachedModule(cacheKey: string, wasmModule: WebAssembly.Module): void;
    static clearModuleCache(): void;
    /** Absolute path of a bundled WASM asset (`whatsapp.wasm`, `loader.js`, `worker-modules.js`). */
    static getAssetPath(filename: string): string;
    static getMemoryStats(additional?: VoipMemoryStatsInput): {
        rss: number;
        heapUsed: number;
        heapTotal: number;
        external: number;
        arrayBuffers: number;
        activeWorkers: number;
        relayConnections: number;
        ffmpegProcesses: number;
        cachedModules: number;
        activeCalls: number;
        waitingCalls: number;
        totalManagedCalls: number;
        process: {
            rss: number;
            rssMb: number;
            heapUsed: number;
            heapUsedMb: number;
            heapTotal: number;
            heapTotalMb: number;
            external: number;
            externalMb: number;
            arrayBuffers: number;
            arrayBuffersMb: number;
        };
        calls: {
            activeCalls: number;
            waitingCalls: number;
            totalManagedCalls: number;
        };
        resourceManager: {
            activeWorkers: number;
            activeRelayConnections: number;
            activeFfmpegProcesses: number;
            compiledModulesCached: number;
        };
    };
    /**
     * Normalise a pthread-pool size option: `'auto'` → half the CPU cores (2–6),
     * a number → clamped to 2–16, anything else → 4.
     */
    static resolvePthreadPoolSize(value?: number | 'auto' | null): number;
}
export declare const resolvePthreadPoolSize: (value?: number | "auto" | null) => number;
//# sourceMappingURL=resource-manager.d.ts.map