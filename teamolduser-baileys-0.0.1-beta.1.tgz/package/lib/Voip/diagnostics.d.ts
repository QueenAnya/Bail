/** Strips anything that is not a plain JID component, so a token pasted into a JID cannot leak. */
export declare const sanitizeJid: (jid: unknown) => string;
/** Keeps primitive, non-sensitive attributes and replaces the rest. */
export declare const summarizeAttrs: (attrs?: Record<string, unknown>) => Record<string, unknown>;
export type NodeSummary = {
    tag: string;
    attrs: Record<string, unknown>;
    children: string[];
    childCount: number;
    hasContent: boolean;
    contentType: string;
    contentLength?: number;
};
/** Summarises a binary node without dumping buffers or sensitive attributes. */
export declare const summarizeNode: (node: any) => NodeSummary | null;
export type TimelineEntry = {
    time: number;
    iso: string;
    event: string;
    elapsedMs: number;
    details: Record<string, unknown>;
};
type TimelineOptions = {
    /** entries kept per call, default 120 */
    maxEntriesPerCall?: number;
    /** calls tracked before stale ones are dropped, default 300 */
    maxCalls?: number;
    /** how long a finished call's timeline is kept, default 5 minutes */
    ttlMs?: number;
};
/** Bounded per-call event log. Old entries fall off; stale calls are swept when the map grows. */
export declare class CallTimelineStore {
    private readonly timelines;
    private readonly startTimes;
    private readonly maxEntriesPerCall;
    private readonly maxCalls;
    private readonly ttlMs;
    constructor(options?: TimelineOptions);
    record(callId: string, event: string, details?: Record<string, unknown>): void;
    get(callId: string): TimelineEntry[];
    format(callId: string): string;
    clear(callId: string): void;
    get size(): number;
    private cleanupStale;
}
export type VoipLogInput = {
    level?: 'trace' | 'debug' | 'info' | 'warn' | 'error';
    component?: string;
    event?: string;
    direction?: string;
    callId?: string;
    correlationId?: string;
    jid?: string;
    tags?: string[] | null;
    state?: string;
    durationMs?: number;
    error?: Error | string | null;
    data?: Record<string, unknown>;
};
export type VoipDiagnosticsOptions = {
    /** elevate `debug` lines to `info` so they surface in production logs */
    diagnostic?: boolean;
    /** alias for `diagnostic` */
    debugVoip?: boolean;
    /** append every formatted line to this file; off by default — a library must not write into the caller's cwd */
    logFile?: string;
    maxEntriesPerCall?: number;
    maxCalls?: number;
    ttlMs?: number;
};
/** Structured logging plus a per-call timeline. One instance is usually enough — see `voipDiagnostics`. */
export declare class VoipDiagnostics {
    private logger;
    private diagnosticMode;
    private readonly timeline;
    private readonly logFile?;
    constructor(logger?: any, options?: VoipDiagnosticsOptions);
    setLogger(logger: any): void;
    getLogger(): any;
    setDiagnosticMode(enabled: boolean): void;
    isDiagnosticMode(): boolean;
    /** Formats and logs one event, and records it on the call's timeline when a call id is known. */
    log(input?: VoipLogInput): void;
    recordTimeline(callId: string, step: string, details?: Record<string, unknown>): void;
    getTimeline(callId: string): TimelineEntry[];
    formatTimeline(callId: string): string;
    dumpTimeline(callId: string, level?: VoipLogInput['level']): string;
    clearTimeline(callId: string): void;
    private appendToFile;
}
export declare const voipDiagnostics: VoipDiagnostics;
export {};
//# sourceMappingURL=diagnostics.d.ts.map