/**
 * CallManager — concurrency limit + optional waiting queue on top of `sock.initiateCall()`.
 *
 * Counterpart of @innovatorssoft/baileys' `CallManager` (`maxConcurrentCalls`, `onLimit: 'queue' | 'reject'`,
 * active/waiting call lists, memory stats). That fork ships its own signaling engine; this fork already has a
 * socket-integrated engine (`Voip/voip-engine.ts`), so this class is a thin, engine-agnostic layer over it and
 * never touches call stanzas itself — no double handling of `<call>` nodes.
 *
 * @example
 * const calls = new CallManager({ sock, maxConcurrentCalls: 2, onLimit: 'queue' })
 * calls.on('call.queued', ({ jid, position }) => console.log(jid, 'waits at', position))
 * const call = await calls.startCall('12345678901', { audioSource: './hello.mp3' }) // resolves once it really starts
 */
import { EventEmitter } from 'events';
import type { CallSummary } from './types.js';
import type { ActiveCall, InitiateCallOptions } from './voip-engine.js';
/** The only thing CallManager needs from a socket. */
export type CallManagerSocket = {
    initiateCall: (jidOrPhoneNumber: string, opts?: InitiateCallOptions) => Promise<ActiveCall>;
};
export type CallManagerConfig = {
    sock: CallManagerSocket;
    /** Calls allowed at the same time (default `1`). */
    maxConcurrentCalls?: number;
    /** What to do when the limit is hit: throw (`'reject'`, default) or wait (`'queue'`). */
    onLimit?: 'reject' | 'queue';
    logger?: {
        warn?: (obj: unknown, msg?: string) => void;
        debug?: (obj: unknown, msg?: string) => void;
    };
};
export type WaitingCallSummary = {
    jid: string;
    position: number;
    queuedAt: number;
    options?: InitiateCallOptions;
};
export declare class CallManager extends EventEmitter {
    #private;
    readonly sock: CallManagerSocket;
    maxConcurrentCalls: number;
    onLimit: 'reject' | 'queue';
    constructor(config: CallManagerConfig);
    /** Calls that are running (or being set up) right now. */
    get activeCallCount(): number;
    get waitingCallCount(): number;
    getCall: (callId: string) => ActiveCall | undefined;
    getActiveCalls: () => CallSummary[];
    getWaitingCalls: () => WaitingCallSummary[];
    getMemoryStats: () => {
        rss: number;
        heapUsed: number;
        heapTotal: number;
        external: number;
        arrayBuffers: number;
        activeWorkers: number;
        relayConnections: number;
        ffmpegProcesses: number;
        cachedModules: number;
        activeCalls: number;
        waitingCalls: number;
        totalManagedCalls: number;
        process: {
            rss: number;
            rssMb: number;
            heapUsed: number;
            heapUsedMb: number;
            heapTotal: number;
            heapTotalMb: number;
            external: number;
            externalMb: number;
            arrayBuffers: number;
            arrayBuffersMb: number;
        };
        calls: {
            activeCalls: number;
            waitingCalls: number;
            totalManagedCalls: number;
        };
        resourceManager: {
            activeWorkers: number;
            activeRelayConnections: number;
            activeFfmpegProcesses: number;
            compiledModulesCached: number;
        };
    };
    /**
     * Place a call. Under the limit it starts immediately; at the limit it either throws
     * (`onLimit: 'reject'`) or waits and resolves as soon as a slot frees up (`onLimit: 'queue'`).
     */
    startCall: (jid: string, options?: InitiateCallOptions) => Promise<ActiveCall>;
    /** Ends one call; a waiting call with that `jid`-less id is simply ignored. */
    endCall: (callId: string, reason?: string) => void;
    /** Ends every running call and rejects everything still waiting. */
    endAllCalls: (reason?: string) => void;
    /** Stop accepting calls, end running ones and reject the queue. Safe to call more than once. */
    cleanup: () => void;
}
//# sourceMappingURL=call-manager.d.ts.map