/**
 * Makes sure the VoIP WASM assets (`whatsapp.wasm`, `loader.js`, `worker-modules.js`) exist.
 *
 * - without `targetDir` it just checks the bundled `assets/wasm` directory;
 * - with `targetDir` (absolute, or relative to `process.cwd()`) it creates the directory and
 *   copies any missing asset there — handy for bundlers/containers where `node_modules` is read-only
 *   or stripped, then pass the same folder as `resourcesPath` to your engine config.
 *
 * Ported from @innovatorssoft/baileys. Returns the directory the assets live in, or `null` if the
 * assets could not be found/copied.
 */
export declare const ensureWasmAssets: (targetDir?: string) => string | null;
//# sourceMappingURL=wasm-assets.d.ts.map