import { EventEmitter } from 'node:events';
import type { MergedVoipClientOptions } from './types.js';
export declare class ActiveCall extends EventEmitter {
    constructor(callId: any, engine: any, durationMs: any);
    get state(): any;
}
export declare class MergedVoipClient {
    connect: () => Promise<void>;
    attach: (socket: any) => Promise<void>;
    call: (phoneNumber: string, options?: Record<string, any>) => Promise<ActiveCall>;
    callGroup: (groupJid: string, options?: Record<string, any>) => Promise<ActiveCall>;
    joinGroupCall: (invite: Record<string, any>, options?: Record<string, any>) => Promise<ActiveCall>;
    acceptCall: (...args: any[]) => any;
    initiateCall: (jidOrPhoneNumber: string, options?: Record<string, any>) => Promise<any>;
    initiateCalls: (requests: Array<{
        jid: string;
        options?: Record<string, any>;
    }>) => Promise<any[]>;
    callMany: (requests: Array<{
        jid: string;
        options?: Record<string, any>;
    }>) => Promise<any[]>;
    rejectCall: (...args: any[]) => Promise<any>;
    getActiveCalls: () => Promise<any[]>;
    getCall: (callId: string) => Promise<any>;
    getActiveCallCount: () => Promise<number>;
    endCall: (callId: string) => Promise<any>;
    endAllCalls: () => Promise<any>;
    setOptions: (options: Record<string, any>) => Promise<any>;
    disconnect: () => void;
    resetCallState: () => void;
    constructor(config?: MergedVoipClientOptions);
}
/** Create the unified VoIP facade over an already-authenticated socket.
 * The method invoked selects the needed internal signaling engine automatically;
 * callers do not provide an engine selector. */
export declare const makeVoipClient: (socket: any, config?: MergedVoipClientOptions) => Promise<MergedVoipClient>;
//# sourceMappingURL=socket-client.d.ts.map