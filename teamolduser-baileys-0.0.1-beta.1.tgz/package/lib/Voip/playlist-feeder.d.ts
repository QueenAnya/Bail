/**
 * Playlist layer for `AudioFeeder`.
 *
 * Elaina's `AudioFeeder.start([tracks])` plays a queue and reports track transitions through hooks.
 * This fork's `AudioFeeder` is deliberately single-source, so the queue lives here instead of being
 * grafted onto the audio path: this class owns one `AudioFeeder` at a time and moves to the next
 * track when the current one ends. Nothing in `audio-feeder.ts` changed, so call behaviour is
 * untouched.
 */
import { AudioFeeder } from './audio-feeder.js';
export interface PlaylistFeederHooks {
    onTrackStart?: (track: string) => void;
    onTrackEnd?: (track: string) => void;
    onIdle?: () => void;
    onChunk?: (chunk: Float32Array) => void;
}
export interface PlaylistFeederOptions extends PlaylistFeederHooks {
    sampleRate?: number;
    channels?: number;
    framesPerChunk?: number;
    /** swap the feeder for a stub in tests; defaults to a real `AudioFeeder` per track */
    createFeeder?: (track: string, onEnd: () => void) => AudioFeeder;
}
export declare class PlaylistAudioFeeder {
    #private;
    private readonly options;
    constructor(options?: PlaylistFeederOptions);
    /** the track being fed right now, or null between tracks and while idle */
    get currentTrack(): string | null;
    /** nothing playing and nothing queued */
    get idle(): boolean;
    /** tracks waiting behind the current one */
    get playlistLength(): number;
    get isRunning(): boolean;
    /** internals, read by the node tests only */
    get _feederForTest(): {
        end?: () => void;
        stop?: () => void;
    } | null;
    /** Replace the queue and start playing immediately. An empty list leaves the feeder idle. */
    start: (tracks?: string[] | string) => void;
    /** Queue a track. If nothing is playing, this starts it. */
    enqueue: (track: string) => number;
    /** Drop everything queued; the current track keeps playing. */
    clearPlaylist: () => void;
    /** Drop the current track and move on. Returns false when there was nothing to skip. */
    skip: () => boolean;
    stop: () => void;
}
//# sourceMappingURL=playlist-feeder.d.ts.map