export type AudioFeederOptions = {
    /** stop after this much audio has been emitted (0 / unset = unlimited) */
    durationMs?: number;
    /** called once when the feeder finishes (duration reached, or non-silence source exhausted) */
    onEnd?: () => void;
};
export declare class AudioFeeder {
    #private;
    private readonly sampleRate;
    private readonly channels;
    private readonly framesPerChunk;
    private readonly onChunk;
    private readonly source;
    private readonly repeat;
    private readonly options;
    droppedChunks: number;
    underflowChunks: number;
    bytesProduced: number;
    chunksEmitted: number;
    emittedDurationMs: number;
    constructor(sampleRate: number, channels: number, framesPerChunk: number, onChunk: (chunk: Float32Array) => void, source?: string, repeat?: boolean, options?: AudioFeederOptions);
    /** chunks waiting for the 20 ms emit timer */
    get queuedChunks(): number;
    /** internals, read by the node tests only */
    get _queue(): Float32Array[];
    get _pendingBytes(): number;
    get _pendingParts(): Buffer[];
    /** takes raw f32le bytes from ffmpeg and queues every complete chunk (public so it can be fed directly) */
    _absorb(chunk: Buffer): void;
    start: () => void;
    stop: () => void;
}
//# sourceMappingURL=audio-feeder.d.ts.map