import { EventEmitter } from 'events';
import { type BaileysSocket } from './signaling.js';
import { CallMediaType, CallState, type CallStatus, type CallSummary, type VoipConfigOptions } from './types.js';
import { VideoFeeder } from './video-feeder.js';
import { WasmEngine } from './wasm-engine.js';
export type { VoipSdkConfig, CallOptions, CallEvents, AudioConfig, CallStatus, CallSummary, CallRequest, VoipConfigOptions } from './types.js';
export { CallState } from './types.js';
/** A live or recently-ended call. */
export declare class ActiveCall extends EventEmitter {
    #private;
    readonly callId: string;
    readonly peerJid: string;
    private readonly engine;
    readonly phoneNumber: string;
    readonly startedAt: number;
    connectedAt: number | null;
    endedAt: number | null;
    /** @internal mirrors the source path for the audio feeder */
    _audioSource: string;
    /** @internal whether the audio source should loop for the life of the call */
    _repeatAudio: boolean;
    /** @internal auto-hangup duration, also reported via getSummary() */
    _durationMs: number;
    /** @internal video source path/options, set by initiateCall when isVideo is requested */
    _videoSource: string | null;
    _videoWidth: number;
    _videoHeight: number;
    _videoFps: number;
    _videoLoop: boolean;
    /** @internal true = horizontal/landscape, false = vertical/portrait */
    isHorizontal: boolean;
    /** @internal raw orientation flag passed to sendVideoFrame (0 = portrait, 2 = landscape, etc.) */
    _videoOrientation: number;
    /** @internal whether this is a video call */
    isVideo: boolean;
    /** @internal set by voip-engine once the video feeder is actually running */
    videoFeeder: VideoFeeder | null;
    /** true for calls received from a peer (see `call.incoming`), false for calls we placed */
    isIncoming: boolean;
    /** `'incoming'` for received calls, `'outgoing'` for calls we placed */
    direction: 'incoming' | 'outgoing';
    /** JID that created the call (incoming calls) */
    callCreator: string;
    /** caller's phone-number JID when WhatsApp provides one (incoming calls) */
    callerPn: string;
    /** incoming calls are never queued by this engine; kept for innovatorssoft API parity */
    isWaiting: boolean;
    /** @internal true once `accept()` was called on an incoming call */
    _accepted: boolean;
    /** @internal wired by attachVoipToSocket for incoming calls */
    _acceptHandler: ((options: AcceptCallOptions) => Promise<ActiveCall>) | null;
    /** @internal wired by attachVoipToSocket for incoming calls */
    _rejectHandler: ((reason?: string) => Promise<void>) | null;
    constructor(callId: string, peerJid: string, engine: WasmEngine, durationMs: number, phoneNumber?: string, preRingingTimeoutMs?: number);
    /**
     * Start streaming a video source into this call. `ptr` must be a
     * pre-allocated WASM heap buffer at least `width * height * 1.5` bytes
     * (YUV420p frame size) — see `handleAudioCaptureStart` in
     * `attachVoipToSocket`, which allocates and passes this in.
     */
    startVideo: (ptr: number) => void;
    stopVideo: () => void;
    /** True while an incoming call can still be answered. */
    get canAccept(): boolean;
    /**
     * Answers an incoming call and starts streaming `audioSource` to the caller.
     *
     *   sock.ev.on('call.incoming', async call => {
     *     await call.accept({ audioSource: './audio.mp3', repeatAudio: false })
     *   })
     */
    accept: (options?: AcceptCallOptions) => Promise<ActiveCall>;
    /** Declines an incoming call (`reason`: `'declined'` | `'busy'` …). */
    reject: (reason?: string) => Promise<void>;
    unmute: () => void;
    get state(): CallState;
    get status(): CallStatus;
    get ended(): boolean;
    /** `true` for calls we placed (opposite of {@link isIncoming}). */
    get isOutgoing(): boolean;
    /** `'video'` for video calls, otherwise `'audio'`. */
    get mediaType(): CallMediaType;
    /** Snapshot of this call's current config/state, mirroring upstream's CallSummary. */
    getSummary: () => CallSummary;
    /** Ends the call. `reason` defaults to `'completed'`; for `'remote_end'`
     *  or `'rejected'` we skip re-signaling `endCall` to the WASM since the
     *  remote side already tore it down. */
    end: (reason?: string) => void;
    mute: (muted: boolean) => void;
    waitForEnd: () => Promise<string>;
    /** @internal — call once the audio feeder actually starts pushing frames. */
    _confirmAudioReady: () => void;
    /** @internal — call on the first real audio chunk sent. */
    _confirmStreaming: () => void;
    /** @internal — called by the engine wiring below on WASM call-state change */
    _updateState: (state: number) => void;
    /** @internal — incoming call: mark as ringing (caller's phone shows "ringing") */
    _markRinging: () => void;
    /** @internal — incoming call: mark as answered */
    _beginAccepted: () => void;
    /** @internal — incoming call: start the auto-hangup timer once answered (0 = no limit) */
    _startDurationTimer: (durationMs: number) => void;
    /** @internal — called on raw signaling tags (terminate/reject/preaccept/accept/receipt),
     *  which typically reach us faster than a WASM call-state round trip. */
    _handleSignalingEvent: (tag: string, reason?: string) => void;
    /** @internal — called on signaling-layer errors (ack timeout, 404/480, etc.) */
    _handleSignalingError: (_signalingTag: string, errorType: string) => void;
    /** @internal */
    _handleUnreachable: () => void;
    /** @internal */
    _handleRejected: () => void;
    /** @internal */
    _handleTimeout: () => void;
    /** @internal */
    _forceFail: (reason: string) => void;
    /** @internal */
    _emitAudio: (pcm: Float32Array) => void;
    /** @internal */
    _forceEnd: (reason: string) => void;
}
export type AcceptCallOptions = {
    /** Audio streamed to the caller: file path to MP3/WAV, or `'silence'` (default). */
    audioSource?: string;
    audio?: string;
    /** Loop `audioSource` for the life of the call instead of playing it once. */
    repeatAudio?: boolean;
    repeat?: boolean;
    /** Video source for incoming video calls (file path, streamed via ffmpeg). */
    videoSource?: string;
    video?: string;
    /** Auto-hangup after N ms (default: 120000, `0` = no limit). */
    durationMs?: number;
    durationMS?: number;
    isMicEnabled?: boolean;
    isCameraEnabled?: boolean;
};
export type InitiateCallOptions = {
    /** Phone number or JID — optional here since it's normally the first arg to initiateCall(). */
    to?: string;
    /** Audio source: file path to MP3/WAV, or 'silence' for an empty uplink. */
    audioSource?: string;
    /** Auto-hangup after N ms (default: 120000). */
    durationMs?: number;
    durationMS?: number;
    /** Whether this is a video call (default: false). Requires videoSource. */
    isVideo?: boolean;
    /** Video source: file path to MP4/MKV/MOV/AVI, streamed via ffmpeg. */
    videoSource?: string;
    /** Video frame width (default: 640). Rounded up to an even number. */
    videoWidth?: number;
    width?: number;
    /** Video frame height (default: 480). Rounded up to an even number. */
    videoHeight?: number;
    height?: number;
    /** Video frame rate, 1-60 (default: 15). */
    videoFps?: number;
    fps?: number;
    /** Loop the video source continuously until durationMs is reached. */
    videoLoop?: boolean;
    repeatVideo?: boolean;
    loop?: boolean;
    /** Stream video in horizontal (landscape) orientation if true. (default: false / portrait) */
    isHorizontal?: boolean;
    horizontal?: boolean;
    /** Explicit raw device/video orientation (0 = vertical/portrait, 2 = horizontal/landscape, etc.). */
    orientation?: number;
    videoOrientation?: number;
    /** Loop audioSource for the life of the call instead of playing it once. */
    repeatAudio?: boolean;
    repeat?: boolean;
    /** Timeout waiting for remote device to confirm ringing, in ms (default: 20000). */
    preRingingTimeoutMs?: number;
};
export declare const attachVoipToSocket: (sock: BaileysSocket & {
    presenceSubscribe: (jid: string) => Promise<void>;
}, voipConfig?: boolean | VoipConfigOptions) => {
    initiateCall: (jidOrPhoneNumber: string, opts?: InitiateCallOptions) => Promise<ActiveCall>;
    initiateCalls: (requests: Array<{
        jid: string;
        options?: InitiateCallOptions;
    }>) => Promise<ActiveCall[]>;
    getActiveCalls: () => Promise<CallSummary[]>;
    getCall: (callId: string) => Promise<ActiveCall | undefined>;
    getActiveCallCount: () => Promise<number>;
    endCall: (callId: string) => Promise<void>;
    endAllCalls: () => Promise<void>;
    setVoipOptions: (options: VoipConfigOptions) => Promise<void>;
    getVoipMemoryStats: () => Promise<{
        process: {
            rssMb: number;
            heapUsedMb: number;
            heapTotalMb: number;
            externalMb: number;
        };
        calls: {
            activeCalls: number;
            waitingCalls: number;
            totalManagedCalls: number;
            maxConcurrentCalls: number | null;
        };
        resourceManager: {
            activeWorkers: number;
            activeRelayConnections: number;
            activeFfmpegProcesses: number;
            compiledModulesCached: number;
        };
    }>;
    getVoipClient: () => Promise<{
        readonly calls: Map<string, ActiveCall>;
        getCall: (callId: string) => ActiveCall | undefined;
        getActiveCalls: () => Promise<CallSummary[]>;
        getActiveCallCount: () => Promise<number>;
        endCall: (callId: string) => Promise<void>;
        endAllCalls: () => Promise<void>;
        setOptions: (options: VoipConfigOptions) => Promise<void>;
        getMemoryStats: () => Promise<{
            process: {
                rssMb: number;
                heapUsedMb: number;
                heapTotalMb: number;
                externalMb: number;
            };
            calls: {
                activeCalls: number;
                waitingCalls: number;
                totalManagedCalls: number;
                maxConcurrentCalls: number | null;
            };
            resourceManager: {
                activeWorkers: number;
                activeRelayConnections: number;
                activeFfmpegProcesses: number;
                compiledModulesCached: number;
            };
        }>;
    }>;
    disconnectVoip: () => void;
};
//# sourceMappingURL=voip-engine.d.ts.map