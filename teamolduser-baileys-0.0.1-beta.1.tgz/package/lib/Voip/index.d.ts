/**
 * Unified public VoIP API.
 *
 * All Anya and Elaina methods are exposed by one client. The required internal
 * signaling engine is selected automatically by the invoked method; callers do not select an engine explicitly.
 * Original source snapshots live under repository-root
 * were dropped from this tree; this module is the merged Anya + Elaina implementation.
 */
export { ActiveCall, MergedVoipClient, makeVoipClient } from './socket-client.js';
export { VoipClient } from './voip-client.js';
export { AudioFeeder } from './audio-feeder.js';
export { PlaylistAudioFeeder } from './playlist-feeder.js';
export type { PlaylistFeederHooks, PlaylistFeederOptions } from './playlist-feeder.js';
export { VIDEO_FORMAT_I420, VideoFeeder } from './video-feeder.js';
export { CallState } from './types.js';
export { CallTimelineStore, VoipDiagnostics, voipDiagnostics, sanitizeJid, summarizeAttrs, summarizeNode } from './diagnostics.js';
export type { TimelineEntry, VoipDiagnosticsOptions, VoipLogInput, NodeSummary } from './diagnostics.js';
export type { CallOptions, CallEvents, CallRequest, CallSummary, CallStatus, VoipConfigOptions, MergedVoipClientOptions } from './types.js';
//# sourceMappingURL=index.d.ts.map